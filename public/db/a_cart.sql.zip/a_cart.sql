-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Feb 26, 2024 at 04:55 PM
-- Server version: 10.4.25-MariaDB
-- PHP Version: 8.1.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `a_cart`
--

-- --------------------------------------------------------

--
-- Table structure for table `config_app_menus`
--

CREATE TABLE `config_app_menus` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `type` enum('side','user','cart') COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `postion` int(11) NOT NULL DEFAULT 0,
  `is_active` int(11) NOT NULL DEFAULT 1,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `config_app_menus`
--

INSERT INTO `config_app_menus` (`id`, `type`, `postion`, `is_active`, `deleted_at`) VALUES
(1, 'user', 0, 1, NULL),
(2, 'cart', 0, 1, NULL),
(3, 'side', 3, 1, NULL),
(4, 'side', 2, 1, NULL),
(5, 'side', 1, 1, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `config_app_menu_translations`
--

CREATE TABLE `config_app_menu_translations` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `menu_id` bigint(20) UNSIGNED NOT NULL,
  `locale` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `url` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `label` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `icon` int(11) DEFAULT NULL,
  `title` int(11) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `config_app_menu_translations`
--

INSERT INTO `config_app_menu_translations` (`id`, `menu_id`, `locale`, `url`, `label`, `icon`, `title`) VALUES
(1, 2, 'ar', 'https://freestyle4u.net/et8/public/EtmanShop/CartView/?mobile=1', 'السلة', 60562, 1),
(2, 1, 'ar', 'https://freestyle4u.net/et8/public/EtmanShop/profile/?mobile=1', 'الملف الشخصي', 58519, 1),
(3, 3, 'ar', 'https://freestyle4u.net/et8/public/اتصل-بنا/?mobile=1', 'اتصل بنا', 57738, 1),
(4, 4, 'ar', 'https://freestyle4u.net/et8/public/EtmanShop/عروض-تجار-الجملة/?mobile=1', 'عروض الجمله', 61828, 1),
(5, 5, 'ar', 'https://freestyle4u.net/et8/public/EtmanShop//?mobile=1', 'الرئيسية', 58519, 1),
(6, 1, 'en', 'https://freestyle4u.net/et8/public/EtmanShop/profile/?mobile=1', 'Profile', 58519, 1),
(7, 2, 'en', 'https://freestyle4u.net/et8/public/EtmanShop/CartView/?mobile=1', 'Cart', 60562, 1),
(8, 5, 'en', 'https://freestyle4u.net/et8/public/EtmanShop//?mobile=1', 'Home', 58519, 1),
(9, 4, 'en', 'https://freestyle4u.net/et8/public/EtmanShop/عروض-تجار-الجملة/?mobile=1', 'Offers', 61828, 1),
(10, 3, 'en', 'https://freestyle4u.net/et8/public/اتصل-بنا/?mobile=1', 'Contact Us', 57738, 1);

-- --------------------------------------------------------

--
-- Table structure for table `config_app_settings`
--

CREATE TABLE `config_app_settings` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `status` int(11) NOT NULL DEFAULT 1,
  `baseUrl` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `mobilePrefix` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `prefix` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `logo` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `SideLogo` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ColorDark` bigint(20) DEFAULT NULL,
  `ColorLight` bigint(20) DEFAULT NULL,
  `AppBarIconColor` bigint(20) DEFAULT NULL,
  `BackGroundColor` bigint(20) DEFAULT NULL,
  `SplashColor` bigint(20) DEFAULT NULL,
  `PreloadingColor` bigint(20) DEFAULT NULL,
  `StatueBArColor` bigint(20) DEFAULT NULL,
  `AppBarColor` bigint(20) DEFAULT NULL,
  `AppBarColorText` bigint(20) DEFAULT NULL,
  `sideMenuText` bigint(20) DEFAULT NULL,
  `sideMenuColor` bigint(20) DEFAULT NULL,
  `mainScreenScale` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sideMenuAngle` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sideMenuStyle` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `AppTheme` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `facebook` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `twitter` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `youtube` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `instagram` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `linkedin` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `whatsAppNumber` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `whatsAppKey` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `telegram_key` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `telegram_group` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `telegram_phone` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `config_app_settings`
--

INSERT INTO `config_app_settings` (`id`, `status`, `baseUrl`, `mobilePrefix`, `prefix`, `logo`, `SideLogo`, `ColorDark`, `ColorLight`, `AppBarIconColor`, `BackGroundColor`, `SplashColor`, `PreloadingColor`, `StatueBArColor`, `AppBarColor`, `AppBarColorText`, `sideMenuText`, `sideMenuColor`, `mainScreenScale`, `sideMenuAngle`, `sideMenuStyle`, `AppTheme`, `facebook`, `twitter`, `youtube`, `instagram`, `linkedin`, `whatsAppNumber`, `whatsAppKey`, `telegram_key`, `telegram_group`, `telegram_phone`, `created_at`, `updated_at`) VALUES
(1, 1, 'https://freestyle4u.net/et8/public/', 'EtmanShop/', '?mobile=1', 'images/app-photo/logo-gcm4YkOQps.webp', 'images/app-photo/sidelogo-x8N4Ol0Coz.webp', 4292621637, 4293283920, 4278190080, 4294967295, 4278190080, 4293283920, 4293283920, 4278190080, 4278190080, 4278190080, 4293283920, '-0.1', '0', 'style3', 'home', 'https://www.facebook.com/Etman.Group', NULL, 'https://www.youtube.com/channel/UC8GkiBf6L9bogsUtx0PEgTg', 'https://www.instagram.com/etmangroup.eg/', 'https://www.linkedin.com/company/etman-group/', '201154905424', NULL, NULL, NULL, NULL, NULL, '2023-10-10 06:13:37');

-- --------------------------------------------------------

--
-- Table structure for table `config_app_setting_translations`
--

CREATE TABLE `config_app_setting_translations` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `setting_id` bigint(20) UNSIGNED NOT NULL,
  `locale` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `AppName` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `whatsAppMessage` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `config_app_setting_translations`
--

INSERT INTO `config_app_setting_translations` (`id`, `setting_id`, `locale`, `AppName`, `whatsAppMessage`) VALUES
(1, 1, 'ar', 'عتمان جروب', 'مساء الخير'),
(2, 1, 'en', 'Etman Group', 'Good evening');

-- --------------------------------------------------------

--
-- Table structure for table `config_branches`
--

CREATE TABLE `config_branches` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `whatsapp` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `lat` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `long` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `direction` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_active` int(11) NOT NULL DEFAULT 1,
  `postion` int(11) NOT NULL DEFAULT 0,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `config_branches`
--

INSERT INTO `config_branches` (`id`, `whatsapp`, `lat`, `long`, `direction`, `is_active`, `postion`, `deleted_at`) VALUES
(1, '01223129660', '24.7778893', '46.629138', 'https://goo.gl/maps/GTWAx3WN26qAXofy7', 1, 0, NULL),
(2, '01006180117', '24.777903', '43534534', 'https://goo.gl/maps/hjDuzdSQEWuu4tpd8', 1, 0, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `config_branch_translations`
--

CREATE TABLE `config_branch_translations` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `branch_id` bigint(20) UNSIGNED NOT NULL,
  `locale` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `phone` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `work_hours` text COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `config_branch_translations`
--

INSERT INTO `config_branch_translations` (`id`, `branch_id`, `locale`, `title`, `address`, `phone`, `work_hours`) VALUES
(1, 1, 'ar', 'المقر الرئيسي', '14 ش خليل بك متفرع من شارع\r\nاسماعيل صبري - الجمرك\r\nالاسكندرية - مصر', '+2 0100 618 0117\r\n+203 48 67 311\r\n+203 48 15 941', 'طول ايام الاسبوع\r\nمن 9 صباحا وحتى 9 مساءا'),
(2, 1, 'en', 'Head Office', '14 Khalil Bek St., from Ismail Sabry El Gommork\r\nAlexandria - Egypt', '+2 0100 618 0117\r\n+203 48 67 311\r\n+203 48 15 941', 'All week days\r\nFrom 9:00 AM To 8:00 PM'),
(3, 2, 'ar', 'المقر الادارى', '336 طريق الجيش امام نادي التجاريين\r\nعمارات رويال بلازا - سابا باشا\r\nالاسكندرية - مصر', '+203 58 68 324\r\n+203 58 68 325', 'من السبت الى الخميس\r\n9 صباحا وحتى 5 مساءا'),
(4, 2, 'en', 'Managerial Office', '336 El Geish Road in front of Al Tegareen Club\r\nRoyal Plaza Buildings - Saba Basha\r\nAlexandria - Egypt', '+203 58 68 324\r\n+203 58 68 325', 'From Saturday to Thursday\r\n9:00 AM To 5:00 PM');

-- --------------------------------------------------------

--
-- Table structure for table `config_def_photos`
--

CREATE TABLE `config_def_photos` (
  `id` int(10) UNSIGNED NOT NULL,
  `cat_id` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `photo` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `photo_thum_1` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `photo_thum_2` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `postion` int(11) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `config_def_photos`
--

INSERT INTO `config_def_photos` (`id`, `cat_id`, `photo`, `photo_thum_1`, `photo_thum_2`, `postion`, `created_at`, `updated_at`) VALUES
(1, 'dark_logo', 'images/def-photo/dark-logo-eh5ttAQPSH.webp', NULL, NULL, 2, '2023-08-16 09:18:40', '2024-01-23 05:54:35'),
(3, 'project', 'images/def-photo/project-nvG40dODkH.webp', 'images/def-photo/project-mc4bebeaXL.webp', NULL, 6, '2023-08-16 09:18:40', '2024-01-23 13:02:24'),
(4, 'blog', 'images/def-photo/blog-h9LR5xx5WF.webp', 'images/def-photo/blog-IU0k9z7vQA.webp', NULL, 4, '2023-08-16 09:18:40', '2024-01-23 08:00:46'),
(6, 'units', 'images/def-photo/units-pUYkExfD17.webp', 'images/def-photo/units-Dz6Sc6w7C3.webp', NULL, 7, '2023-08-16 09:18:40', '2024-01-23 13:06:42'),
(7, 'developer', 'images/def-photo/developer-mPN1fhwSWk.webp', 'images/def-photo/developer-iffTkggl7G.webp', NULL, 3, '2023-08-16 11:28:03', '2024-01-23 07:54:15'),
(8, 'light_logo', 'images/def-photo/light-logo-DNJrdvlgdZ.webp', NULL, NULL, 1, '2023-10-15 07:03:47', '2024-01-23 05:54:35'),
(9, 'video_photo', 'images/def-photo/video-photo-eRtOLIqyh5.webp', NULL, NULL, 9, '2023-10-17 06:11:28', '2024-01-24 08:02:52'),
(10, 'location', 'images/def-photo/location-sxtuFwdWTp.webp', 'images/def-photo/location-0V240kMLWP.webp', NULL, 5, '2023-10-17 15:36:15', '2024-01-23 08:37:04'),
(11, 'google_map', 'images/def-photo/google-map-YECvqHwhYi.webp', NULL, NULL, 8, '2024-01-24 08:02:39', '2024-01-24 08:02:52'),
(12, 'err_404', 'images/def-photo/err-404-GyYn77ncLv.webp', NULL, NULL, 10, '2024-01-25 09:48:47', '2024-01-28 16:32:58'),
(13, 'thanks', 'images/def-photo/thanks-kc7RWwQE9g.webp', NULL, NULL, 11, '2024-01-28 16:23:45', '2024-01-30 16:37:36'),
(14, 'no_data', 'images/def-photo/no-data-fk1XLeMYcF.webp', NULL, NULL, 12, '2024-01-30 16:37:25', '2024-01-30 16:37:36'),
(15, 'logo', 'images/def-photo/logo-0dNaY7pzJd.webp', 'images/def-photo/logo-FhNg8hHcJv.webp', NULL, 0, '2024-02-21 14:53:44', '2024-02-21 14:53:44');

-- --------------------------------------------------------

--
-- Table structure for table `config_meta_tags`
--

CREATE TABLE `config_meta_tags` (
  `id` int(10) UNSIGNED NOT NULL,
  `cat_id` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `photo` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `photo_thum_1` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `config_meta_tags`
--

INSERT INTO `config_meta_tags` (`id`, `cat_id`, `photo`, `photo_thum_1`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 'home', NULL, NULL, '2023-08-16 09:18:40', '2023-08-16 09:18:40', NULL),
(2, 'developer', NULL, NULL, '2023-08-16 11:16:16', '2023-08-16 11:16:16', NULL),
(3, 'blog', NULL, NULL, '2023-08-16 11:30:42', '2023-08-16 11:30:42', NULL),
(4, 'contact-us', NULL, NULL, '2023-08-16 11:32:36', '2023-08-16 11:32:36', NULL),
(5, 'compounds', NULL, NULL, '2023-10-29 08:05:33', '2023-10-29 08:05:33', NULL),
(6, 'for-sale', NULL, NULL, '2023-10-29 08:38:58', '2023-10-29 08:38:58', NULL),
(7, 'err_404', NULL, NULL, '2024-01-25 13:35:18', '2024-01-25 13:35:18', NULL),
(8, 'favorite_list', NULL, NULL, '2024-01-30 16:23:20', '2024-01-30 16:23:35', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `config_meta_tag_translations`
--

CREATE TABLE `config_meta_tag_translations` (
  `id` int(10) UNSIGNED NOT NULL,
  `meta_tag_id` int(10) UNSIGNED NOT NULL,
  `locale` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `g_title` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `g_des` text COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `config_meta_tag_translations`
--

INSERT INTO `config_meta_tag_translations` (`id`, `meta_tag_id`, `locale`, `g_title`, `g_des`) VALUES
(1, 1, 'ar', 'موقع عقارات مصر | وجهتك العقارية الأولى في مصر', 'موقع عقارات مصر الموقع العقاري الأول للكمبوندات والمنتجعات والمشاريع العقارية في مصر'),
(2, 1, 'en', 'Real Estate Egypt | Egypt\'s #1 Real Estate Destination', 'Real Estate Egypt is the biggest real estate website in Egypt for compounds, resorts and commercial projects'),
(3, 2, 'ar', 'المطورين العقاريين | موقع عقارات مصر', 'المطورين العقاريين  موقع عقارات مصر'),
(4, 2, 'en', 'Developers | Real Estate Egypt', 'Developers Real Estate Egypt'),
(5, 3, 'ar', 'المدونة | موقع عقارات مصر', 'موقع عقارات مصر الموقع العقاري الأول للكمبوندات والمنتجعات والمشاريع العقارية في مصر'),
(6, 3, 'en', 'Blog | Real Estate Egypt', 'Blog Real Estate Egypt'),
(7, 4, 'ar', 'اتصل بنا | موقع عقارات مصر | وجهتك العقارية الأولى في مصر', 'اتصل بنا موقع عقارات مصر الموقع العقاري الأول للكمبوندات والمنتجعات والمشاريع العقارية في مصر'),
(8, 4, 'en', 'Contact Us | Real Estate Egypt | Egypt\'s #1 Real Estate Destination', 'Contact Us Real Estate Egypt is the biggest real estate website in Egypt for compounds, resorts and commercial projects'),
(9, 5, 'ar', 'كمبوندات مصر', 'كمبوندات مصر'),
(10, 5, 'en', 'Compounds', 'Compounds'),
(11, 6, 'ar', 'وحدات للبيع', 'وحدات للبيع'),
(12, 6, 'en', 'For Sale', 'For Sale'),
(13, 7, 'ar', 'عذرًا !! الصفحة التي تبحث عنها غير موجودة.', 'عذرًا !! الصفحة التي تبحث عنها غير موجودة.'),
(14, 7, 'en', 'Oops !! Page Not Found', 'Oops !! Page Not Found'),
(15, 8, 'ar', 'المشاريع والوحدات المفضلة', 'المشاريع والوحدات المفضلة'),
(16, 8, 'en', 'Favorite List', 'Favorite List');

-- --------------------------------------------------------

--
-- Table structure for table `config_settings`
--

CREATE TABLE `config_settings` (
  `id` int(10) UNSIGNED NOT NULL,
  `web_url` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `web_status` int(11) NOT NULL DEFAULT 1,
  `fav_view` int(11) NOT NULL DEFAULT 1,
  `phone_num` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `whatsapp_num` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `phone_call` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `whatsapp_send` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `facebook` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `youtube` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `twitter` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `instagram` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `google_api` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `project_update` datetime DEFAULT NULL,
  `location_update` datetime DEFAULT NULL,
  `developer_update` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `config_settings`
--

INSERT INTO `config_settings` (`id`, `web_url`, `web_status`, `fav_view`, `phone_num`, `whatsapp_num`, `phone_call`, `whatsapp_send`, `email`, `facebook`, `youtube`, `twitter`, `instagram`, `google_api`, `project_update`, `location_update`, `developer_update`) VALUES
(1, '#', 0, 1, '0100-9808-986', '0100-9808-986', '01009808986', '201009808986', 'sales@realestate.eg.com', 'https://www.facebook.com/', 'https://www.youtube.com', 'https://www.twitter.com/', 'https://www.Instagram.com/', NULL, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `config_setting_translations`
--

CREATE TABLE `config_setting_translations` (
  `id` int(10) UNSIGNED NOT NULL,
  `setting_id` int(10) UNSIGNED NOT NULL,
  `locale` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `closed_mass` text COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `config_setting_translations`
--

INSERT INTO `config_setting_translations` (`id`, `setting_id`, `locale`, `name`, `closed_mass`) VALUES
(1, 1, 'ar', 'موقع عقارات مصر', 'عذرا جارى اجراء بعض التحديثات \r\nسنعود قريبا'),
(2, 1, 'en', 'Real Estate Egypt', 'Sorry, some updates are being made\r\nWe will be back soon');

-- --------------------------------------------------------

--
-- Table structure for table `config_site_maps`
--

CREATE TABLE `config_site_maps` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `cat_id` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `config_upload_filters`
--

CREATE TABLE `config_upload_filters` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` int(11) NOT NULL DEFAULT 1,
  `convert_state` int(11) NOT NULL DEFAULT 1,
  `quality_val` int(11) NOT NULL DEFAULT 85,
  `new_w` int(11) NOT NULL,
  `new_h` int(11) NOT NULL,
  `canvas_back` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '#ffffff',
  `greyscale` int(11) NOT NULL DEFAULT 0,
  `flip_state` int(11) NOT NULL DEFAULT 0,
  `flip_v` int(11) NOT NULL DEFAULT 0,
  `blur` int(11) NOT NULL DEFAULT 0,
  `blur_size` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `pixelate` int(11) NOT NULL DEFAULT 0,
  `pixelate_size` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '5',
  `text_state` int(11) NOT NULL DEFAULT 0,
  `text_print` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `font_size` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `font_path` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `font_color` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `font_opacity` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `text_position` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `watermark_state` int(11) NOT NULL DEFAULT 0,
  `watermark_img` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `watermark_position` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `state` int(11) NOT NULL DEFAULT 0,
  `notes_ar` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `notes_en` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `config_upload_filters`
--

INSERT INTO `config_upload_filters` (`id`, `name`, `type`, `convert_state`, `quality_val`, `new_w`, `new_h`, `canvas_back`, `greyscale`, `flip_state`, `flip_v`, `blur`, `blur_size`, `pixelate`, `pixelate_size`, `text_state`, `text_print`, `font_size`, `font_path`, `font_color`, `font_opacity`, `text_position`, `watermark_state`, `watermark_img`, `watermark_position`, `state`, `notes_ar`, `notes_en`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 'NoEdit', 1, 1, 85, 100, 100, '#ffffff', 0, 0, 0, 0, '0', 0, '5', 0, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, 0, NULL, NULL, '2023-10-15 07:42:57', '2023-10-15 07:42:57', NULL),
(2, 'DefPhoto', 4, 1, 85, 800, 420, '#ffffff', 0, 0, 0, 0, '0', 0, '5', 0, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, 0, NULL, NULL, '2023-10-15 07:42:57', '2023-10-15 07:42:57', NULL),
(3, 'FavIcon', 4, 1, 85, 40, 40, '#ffffff', 0, 0, 0, 0, '0', 0, '5', 0, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, 0, NULL, NULL, '2023-10-15 07:42:57', '2023-10-15 07:42:57', NULL),
(4, 'المطورين', 5, 1, 85, 500, 500, '#FFFFFF', 0, 0, 0, 0, '0', 0, '5', 0, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, 0, 'برجاء مراعاة ان تكون الصورة مربعة اقل عرض 500 اقل ارتفاع 500 سيتم اعادة ضبط ابعاد الصورة على خلفيه بيضاء فى حالة عدم تساوى النسب', NULL, '2023-10-15 07:42:57', '2024-01-23 14:01:24', NULL),
(5, 'المطورين المزيد من الصور', 4, 1, 85, 1024, 768, '#FFFFFF', 0, 0, 0, 0, '0', 0, '5', 0, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, 0, 'برجاء مراعاة ان تكون الصورة مستطيلة  اقل عرض  1024 سيتم ضبط ابعاد الصور وفقا لحجم العرض', NULL, '2023-10-15 07:42:57', '2024-01-23 14:06:00', NULL),
(6, 'المناطق', 4, 1, 85, 670, 800, '#FFFFFF', 0, 0, 0, 0, '0', 0, '5', 0, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, 0, 'برجاء مراعاة ان تكون الصورة مستطيلة  اقل عرض 420 اقل ارتفاع 500 سيتم قص الصورة وفقا للابعاد المحددة', NULL, '2023-11-16 06:54:14', '2024-01-23 14:07:06', NULL),
(7, 'المقالات', 4, 1, 85, 800, 420, '#FFFFFF', 0, 0, 0, 0, '0', 0, '5', 0, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, 0, 'برجاء مراعاة ان تكون الصورة مستطيلة  اقل عرض 800 اقل ارتفاع 420 سيتم قص الصورة وفقا للابعاد المحددة', NULL, '2024-01-22 17:51:06', '2024-01-23 14:07:22', NULL),
(8, 'المقالات المزيد من الصور', 4, 1, 85, 1024, 768, '#FFFFFF', 0, 0, 0, 0, '0', 0, '5', 0, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, 0, 'برجاء مراعاة ان تكون الصورة مستطيلة  اقل عرض  1024 سيتم ضبط ابعاد الصور وفقا لحجم العرض', NULL, '2024-01-22 19:39:31', '2024-01-23 14:06:23', NULL),
(9, 'المشاريع', 4, 1, 85, 800, 527, '#FFFFFF', 0, 0, 0, 0, '0', 0, '5', 0, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, 0, 'برجاء مراعاة ان تكون الصورة مستطيلة  اقل عرض 800 اقل ارتفاع 527 سيتم قص الصورة وفقا للابعاد المحددة', NULL, '2024-01-23 09:19:58', '2024-01-23 14:07:39', NULL),
(10, 'المشاريع المزيد من الصور', 4, 1, 85, 1024, 768, '#FFFFFF', 0, 0, 0, 0, '0', 0, '5', 0, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, 0, 'برجاء مراعاة ان تكون الصورة مستطيلة  اقل عرض  1024 سيتم ضبط ابعاد الصور وفقا لحجم العرض', NULL, '2024-01-23 12:22:09', '2024-01-23 14:06:32', NULL),
(11, 'الوحدات', 4, 1, 85, 800, 600, '#FFFFFF', 0, 0, 0, 0, '0', 0, '5', 0, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, 0, 'برجاء مراعاة ان تكون الصورة مستطيلة  اقل عرض 800 اقل ارتفاع 600 سيتم قص الصورة وفقا للابعاد المحددة', NULL, '2024-01-23 13:04:27', '2024-01-23 14:07:53', NULL),
(12, 'الوحدات المزيد من الصور', 4, 1, 85, 1024, 678, '#FFFFFF', 0, 0, 0, 0, '0', 0, '5', 0, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, 0, 'برجاء مراعاة ان تكون الصورة مستطيلة  اقل عرض  1024 سيتم ضبط ابعاد الصور وفقا لحجم العرض', NULL, '2024-01-23 13:31:52', '2024-01-23 14:06:41', NULL),
(13, 'البوم صور مع علامة مائية', 4, 1, 85, 1024, 768, '#FFFFFF', 0, 0, 0, 0, '0', 0, '5', 0, 'https://realestate.eg/', '20', 'assets/admin/intervention/font/Cairo-Regular.ttf', '#ED4F4F', '20', 'center', 1, 'assets/admin/intervention/watermark/logo.png', 'bottom', 0, NULL, NULL, '2024-01-23 14:08:50', '2024-01-23 14:58:19', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `config_upload_filter_sizes`
--

CREATE TABLE `config_upload_filter_sizes` (
  `id` int(10) UNSIGNED NOT NULL,
  `filter_id` int(10) UNSIGNED NOT NULL,
  `type` int(11) NOT NULL DEFAULT 1,
  `new_w` int(11) NOT NULL,
  `new_h` int(11) NOT NULL,
  `canvas_back` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `get_more_option` int(11) NOT NULL DEFAULT 0,
  `get_add_text` int(11) NOT NULL DEFAULT 0,
  `get_watermark` int(11) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `config_upload_filter_sizes`
--

INSERT INTO `config_upload_filter_sizes` (`id`, `filter_id`, `type`, `new_w`, `new_h`, `canvas_back`, `get_more_option`, `get_add_text`, `get_watermark`) VALUES
(1, 2, 4, 500, 335, NULL, 0, 0, 0),
(2, 4, 5, 300, 300, '#FFFFFF', 0, 0, 0),
(3, 5, 4, 640, 450, '#FFFFFF', 0, 0, 0),
(5, 6, 4, 420, 500, '#FFFFFF', 0, 0, 0),
(6, 7, 4, 500, 300, '#FFFFFF', 0, 0, 0),
(7, 8, 4, 600, 450, '#FFFFFF', 0, 0, 0),
(8, 9, 4, 425, 280, '#FFFFFF', 0, 0, 0),
(9, 10, 4, 600, 450, '#FFFFFF', 0, 0, 0),
(10, 11, 4, 400, 300, '#FFFFFF', 0, 0, 0),
(11, 12, 4, 640, 450, '#FFFFFF', 0, 0, 0),
(12, 13, 4, 640, 450, '#FFFFFF', 0, 0, 1);

-- --------------------------------------------------------

--
-- Table structure for table `config_web_privacies`
--

CREATE TABLE `config_web_privacies` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `postion` int(11) NOT NULL DEFAULT 0,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `config_web_privacies`
--

INSERT INTO `config_web_privacies` (`id`, `name`, `postion`, `is_active`, `created_at`, `updated_at`, `deleted_at`) VALUES
(2, 'شروط وسياسة الخصوصية', 2, 1, '2023-08-24 12:42:57', '2023-08-24 12:42:57', NULL),
(3, 'جمع المعلومات واستخدامها', 3, 1, '2023-08-24 12:42:57', '2023-08-24 12:42:57', NULL),
(4, 'أنواع البيانات المجمعة', 4, 1, '2023-08-24 12:42:57', '2023-08-24 12:42:57', NULL),
(5, 'بيانات الاستخدام', 5, 1, '2023-08-24 12:42:57', '2023-08-24 12:42:57', NULL),
(6, 'تتبع و ملفات تعريف الارتباط', 6, 1, '2023-08-24 12:42:57', '2023-08-24 12:42:57', NULL),
(7, 'استخدام البيانات', 7, 1, '2023-08-24 12:42:57', '2023-08-24 12:42:57', NULL),
(8, 'نقل البيانات', 8, 1, '2023-08-24 12:42:57', '2023-08-24 12:42:57', NULL),
(9, 'الكشف عن البيانات', 9, 1, '2023-08-24 12:42:57', '2023-08-24 12:42:57', NULL),
(10, 'أمن البيانات', 10, 1, '2023-08-24 12:42:57', '2023-08-24 12:42:57', NULL),
(11, 'مقدمي الخدمة', 11, 1, '2023-08-24 12:42:57', '2023-08-24 12:42:57', NULL),
(12, 'تحليلات', 12, 1, '2023-08-24 12:42:57', '2023-08-24 12:42:57', NULL),
(13, 'روابط لمواقع أخرى', 13, 1, '2023-08-24 12:42:57', '2023-08-24 12:42:57', NULL),
(14, 'خصوصية الأطفال', 14, 1, '2023-08-24 12:42:57', '2023-08-24 12:42:57', NULL),
(15, 'تغييرات سياسة الخصوصية', 15, 1, '2023-08-24 12:42:57', '2023-08-24 12:42:57', NULL),
(16, 'اتصل بنا', 16, 1, '2023-08-24 12:42:57', '2023-08-24 12:42:57', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `config_web_privacy_translations`
--

CREATE TABLE `config_web_privacy_translations` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `privacy_id` bigint(20) UNSIGNED NOT NULL,
  `locale` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `h1` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `h2` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `des` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `lists` text COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `config_web_privacy_translations`
--

INSERT INTO `config_web_privacy_translations` (`id`, `privacy_id`, `locale`, `h1`, `h2`, `des`, `lists`) VALUES
(3, 2, 'ar', 'شروط وسياسة الخصوصية', '', 'تقوم شركة [CompanyName] (\"نحن\" أو \"نحن\" أو \"موقعنا\") بتشغيل [WebSiteName]  (\"الموقع الالكترونى\").\r\nتُعرفك هذه الصفحة بسياساتنا المتعلقة بجمع البيانات الشخصية واستخدامها والكشف عنها عند استخدامك للخدمة والأختيارات المرتبطة بهذه البيانات. \r\nسياسة الخصوصية لشركة [CompanyName]\r\nنستخدم بياناتك لتوفير الخدمة وتحسينها. باستخدام الخدمة، فإنك توافق على جمع واستخدام المعلومات وفقًا لهذه السياسة. ما لم يتم تحديد خلاف ذلك في سياسة الخصوصية، فإن المصطلحات المستخدمة في سياسة الخصوصية لها نفس المعاني كما في الشروط والأحكام الخاصة بنا، والتي يمكن الوصول إليها من [WebSiteName]', ''),
(4, 2, 'en', 'Privacy Policy', '', ' [CompanyName] (\"us\", \"we\", or \"our\") operates the [WebSiteName] website (the \"Service\").\r\nThis page informs you of our policies regarding the collection, use, and disclosure of personal data when you use our Service and the choices you have associated with that data. Our Privacy Policy for [CompanyName]\r\nWe use your data to provide and improve the Service. By using the Service, you agree to the collection and use of information in accordance with this policy. Unless otherwise defined in this Privacy Policy, terms used in this Privacy Policy have the same meanings as in our Terms and Conditions, accessible from  [WebSiteName]', ''),
(5, 3, 'ar', 'جمع المعلومات واستخدامها', '', 'نقوم بتجميع أنواع مختلفة من المعلومات لأغراض متنوعة لتوفير وتحسين خدماتنا لك.', ''),
(6, 3, 'en', 'Information Collection And Use', '', 'We collect several different types of information for various purposes to provide and improve our Service to you.', ''),
(7, 4, 'ar', 'أنواع البيانات المجمعة', 'بيانات شخصية', 'أثناء استخدام خدماتنا ، قد نطلب منك تزويدنا بمعلومات تعريف شخصية معينة يمكن استخدامها للاتصال أو التعرف عليك (&quot;البيانات الشخصية&quot;). قد تتضمن معلومات \r\nالتعريف الشخصية ، على سبيل المثال لا الحصر ، ما يلي:', 'عنوان بريد الكتروني\r\nالاسم الأول واسم العائلة\r\nرقم الهاتف\r\nالعنوان ، الولاية ، المقاطعة ، الرمز البريدي / المدينة ، المدينة\r\nملفات تعريف الارتباط وبيانات الاستخدام'),
(8, 4, 'en', 'Types of Data Collected', 'Personal Data', 'While using our Service, we may ask you to provide us with certain personally identifiable information that can be used to contact or identify you (&quot;Personal Data&quot;). Personally identifiable information may include, but is not limited to :', 'Email address\r\nFirst name and last name\r\nPhone number\r\nAddress, State, Province, ZIP/Postal code, City\r\nCookies and Usage Data'),
(9, 5, 'ar', 'بيانات الاستخدام', '', 'يجوز لنا أيضًا جمع المعلومات حول كيفية الوصول إلى الخدمة واستخدامها (&quot;بيانات الاستخدام&quot;). قد تتضمن بيانات الاستخدام هذه معلومات مثل عنوان بروتوكول الإنترنت الخاص بجهاز الكمبيوتر (مثل عنوان IP) ، ونوع المتصفح، وإصدار المتصفح، وصفحات الخدمة التي تزورها، ووقت وتاريخ زيارتك، والوقت الذي يقضيه في تلك الصفحات، ومعرفات الجهاز وغيرها من البيانات التشخيصية.', ''),
(10, 5, 'en', 'Usage Data', '', 'We may also collect information how the Service is accessed and used (&quot;Usage Data&quot;). This Usage Data may include information such as your computer\'s Internet Protocol address (e.g. IP address), browser type, browser version, the pages of our Service that you visit, the time and date of your visit, the time spent on those pages, unique device identifiers and other diagnostic data.', ''),
(11, 6, 'ar', 'تتبع و ملفات تعريف الارتباط', '', 'نحن نستخدم ملفات تعريف الارتباط وتقنيات التتبع المماثلة لتتبع النشاط على الخدمة لدينا مع الاحتفاظ بمعلومات معينة.\r\nملفات تعريف الارتباط عبارة عن ملفات تحتوي على كمية صغيرة من البيانات التي قد تتضمن معرفًا فريدًا مجهول الهوية. يتم إرسال ملفات تعريف الارتباط إلى متصفحك من موقع الويب وتخزينها على جهازك. تقنيات التتبع المستخدمة هي منارات وعلامات ونصوص لجمع المعلومات وتتبعها ولتحسين خدمتنا وتحليلها.\r\nيمكنك إرشاد المتصفح الخاص بك لرفض جميع ملفات تعريف الارتباط أو للإشارة إلى إرسال ملف تعريف الارتباط. ومع ذلك، إذا كنت لا تقبل ملفات تعريف الارتباط، فقد لا تتمكن من استخدام بعض أجزاء من خدمتنا.\r\n\r\nأمثلة على ملفات تعريف الارتباط التي نستخدمها:', 'نحن نستخدم ملفات تعريف الارتباط الخاصة بالجلسات لتشغيل الخدمة الخاصة بنا.\r\nنحن نستخدم ملفات تعريف الارتباط التفضيلية لتذكر تفضيلاتك والإعدادات المختلفة.\r\nنحن نستخدم ملفات تعريف الارتباط للأمان لأغراض أمنية.'),
(12, 6, 'en', 'Tracking &amp; Cookies Data', '', 'We use cookies and similar tracking technologies to track the activity on our Service and hold certain information.\r\nCookies are files with small amount of data which may include an anonymous unique identifier. Cookies are sent to your browser from a website and stored on your device. Tracking technologies also used are beacons, tags, and scripts to collect and track information and to improve and analyze our Service.\r\nYou can instruct your browser to refuse all cookies or to indicate when a cookie is being sent. However, if you do not accept cookies, you may not be able to use some portions of our Service.\r\n\r\nExamples of Cookies we use:', 'Session Cookies. We use Session Cookies to operate our Service.\r\nPreference Cookies. We use Preference Cookies to remember your preferences and various settings.\r\nSecurity Cookies. We use Security Cookies for security purposes.'),
(13, 7, 'ar', 'استخدام البيانات', '', 'تستخدم [CompanyName] البيانات التي تم جمعها لأغراض مختلفة :', 'لإعلامك عن تغييرات لخدمتنا.\r\nللسماح لك بالمشاركة في الميزات التفاعلية في خدمتنا عندما تختار القيام بذلك.\r\nلتوفير رعاية العملاء والدعم.\r\nلتقديم تحليل أو معلومات قيمة حتى نتمكن من تحسين الخدمة.\r\nلمراقبة استخدام الخدمة.\r\nللكشف عن المشكلات الفنية ومنعها ومعالجتها.'),
(14, 7, 'en', 'Use of Data', '', '[CompanyName] uses the collected data for various purposes:', 'To provide and maintain the Service.\r\nTo notify you about changes to our Service.\r\nTo allow you to participate in interactive features of our Service when you choose to do so.\r\nTo provide customer care and support.\r\nTo provide analysis or valuable information so that we can improve the Service.\r\nTo monitor the usage of the Service.\r\nTo detect, prevent and address technical issues.'),
(15, 8, 'ar', 'نقل البيانات', '', 'قد يتم نقل معلوماتك - بما في ذلك البيانات الشخصية - إلى أجهزة الكمبيوتر الموجودة خارج الولاية أو المقاطعة أو الدولة أو الولاية الحكومية الأخرى التي قد تختلف فيها قوانين حماية البيانات عن تلك الخاصة باختصاصك القضائي.\r\nإذا كنت متواجدًا خارج مصر واخترت تقديم معلومات لنا، يرجى ملاحظة أننا نقوم بنقل البيانات، بما في ذلك البيانات الشخصية، إلى مصر ومعالجتها هناك.\r\nإن موافقتك على سياسة الخصوصية هذه والتي يتبعها تقديمك لهذه المعلومات تمثل موافقتك على هذا النقل \r\nسوف تتخذ [CompanyName] جميع الخطوات الضرورية بشكل معقول لضمان التعامل مع بياناتك بشكل آمن ووفقًا لسياسة الخصوصية هذه ولن يتم نقل بياناتك الشخصية إلى منظمة أو دولة ما لم تكن هناك ضوابط كافية في مكان بما في ذلك أمن البيانات الخاصة بك وغيرها من المعلومات الشخصية.', ''),
(16, 8, 'en', 'Transfer Of Data', '', 'Your information, including Personal Data, may be transferred to — and maintained on — computers located outside of your state, province, country or other governmental jurisdiction where the data protection laws may differ than those from your jurisdiction.\r\nIf you are located outside Egypt and choose to provide information to us, please note that we transfer the data, including Personal Data, to Egypt and process it there.\r\nYour consent to this Privacy Policy followed by your submission of such information represents your agreement to that transfer.\r\n[CompanyName] will take all steps reasonably necessary to ensure that your data is treated securely and in accordance with this Privacy Policy and no transfer of your Personal Data will take place to an organization or a country unless there are adequate controls in place including the security of your data and other personal information.', ''),
(17, 9, 'ar', 'الكشف عن البيانات', 'المتطلبات القانونية', 'يحق لـ [CompanyName] الإفصاح عن بياناتك الشخصية بحسن نية من أن هذا الإجراء ضروري من أجل:', 'للامتثال لالتزام قانوني\r\nلحماية والدفاع عن حقوق أو ملكية [CompanyName]\r\nلمنع أو التحقيق في أي مخالفات محتملة تتعلق بالخدمة.\r\nلحماية السلامة الشخصية لمستخدمي الخدمة أو الجمهور.\r\nللحماية من المسؤولية القانونية.'),
(18, 9, 'en', 'Disclosure Of Data', 'Legal Requirements', '[CompanyName] may disclose your Personal Data in the good faith belief that such action is necessary to:', 'To comply with a legal obligation.\r\nTo protect and defend the rights or property of [CompanyName]\r\nTo prevent or investigate possible wrongdoing in connection with the Service.\r\nTo protect the personal safety of users of the Service or the public.\r\nTo protect against legal liability.'),
(19, 10, 'ar', 'أمن البيانات', '', 'أمان بياناتك مهم بالنسبة لنا، ولكن تذكر أنه لا توجد طريقة للإرسال عبر الإنترنت، أو طريقة التخزين الإلكترونية آمنة ١٠٠٪. بينما نسعى جاهدين لاستخدام وسائل مقبولة تجاريًا لحماية بياناتك الشخصية، لا يمكننا ضمان أمانها المطلق.', ''),
(20, 10, 'en', 'Security Of Data', '', 'The security of your data is important to us, but remember that no method of transmission over the Internet, or method of electronic storage is 100% secure. While we strive to use commercially acceptable means to protect your Personal Data, we cannot guarantee its absolute security.', ''),
(21, 11, 'ar', 'مقدمي الخدمة', '', 'يجوز لنا أن نوظف شركات وأفراد من أطراف ثالثة لتسهيل خدمتنا (&quot;مزودي الخدمة&quot;)، أو تقديم الخدمة نيابة عنا، لأداء الخدمات المتعلقة بالخدمة أو لمساعدتنا في تحليل كيفية استخدام خدمتنا.\r\nهذه الأطراف الثالثة لديها حق الوصول إلى بياناتك الشخصية فقط لأداء هذه المهام نيابة عنا وتكون ملزمة بعدم الكشف عنها أو استخدامها لأي غرض آخر.', ''),
(22, 11, 'en', 'Service Providers', '', 'We may employ third party companies and individuals to facilitate our Service (&quot;Service Providers&quot;), to provide the Service on our behalf, to perform Service-related services or to assist us in analyzing how our Service is used.\r\nThese third parties have access to your Personal Data only to perform these tasks on our behalf and are obligated not to disclose or use it for any other purpose.', ''),
(23, 12, 'ar', 'تحليلات', '', 'قد نستخدم مزودي خدمة من جهات خارجية لمراقبة وتحليل استخدام خدماتنا.', ''),
(24, 12, 'en', 'Analytics', '', 'We may use third-party Service Providers to monitor and analyze the use of our Service.', ''),
(25, 13, 'ar', 'روابط لمواقع أخرى', '', 'قد تحتوي خدمتنا على روابط إلى مواقع أخرى لا يتم تشغيلها من قبلنا. إذا نقرت على رابط جهة خارجية، فسيتم توجيهك إلى موقع الطرف الثالث هذا. ننصحك بشدة بمراجعة سياسة الخصوصية لكل موقع تزوره.\r\n\r\nليس لدينا أي سيطرة ولا نتحمل أي مسؤولية عن المحتوى أو سياسات الخصوصية أو الممارسات الخاصة بأي مواقع أو خدمات خاصة بطرف ثالث.', ''),
(26, 13, 'en', 'Links To Other Sites', '', 'Our Service may contain links to other sites that are not operated by us. If you click on a third party link, you will be directed to that third party\'s site. We strongly advise you to review the Privacy Policy of every site you visit.\r\n\r\nWe have no control over and assume no responsibility for the content, privacy policies or practices of any third party sites or services.', ''),
(27, 14, 'ar', 'خصوصية الأطفال', '', 'لا تتناول خدمتنا أي شخص دون سن ١٨ عامًا (&quot;الأطفال&quot;).\r\nنحن لا نجمع معلومات التعريف الشخصية من أي شخص دون سن ١٨ عامًا. إذا كنت أحد الوالدين أو الوصي وكنت على علم بأن أطفالك قد زودونا ببيانات شخصية، يرجى الاتصال بنا. إذا علمنا أننا جمعنا بيانات شخصية من الأطفال دون التحقق من موافقة الوالدين، فإننا نتخذ خطوات لإزالة تلك المعلومات من خوادمنا.', ''),
(28, 14, 'en', 'Children\'s Privacy', '', 'Our Service does not address anyone under the age of 18 (&quot;Children&quot;).\r\nWe do not knowingly collect personally identifiable information from anyone under the age of 18. If you are a parent or guardian and you are aware that your Children has provided us with Personal Data, please contact us. If we become aware that we have collected Personal Data from children without verification of parental consent, we take steps to remove that information from our servers.', ''),
(29, 15, 'ar', 'تغييرات سياسة الخصوصية', '', 'يجوز لنا تحديث سياسة الخصوصية الخاصة بنا من وقت لآخر. سنعلمك بأي تغييرات عن طريق نشر سياسة الخصوصية الجديدة على هذه الصفحة.\r\nسنخبرك عبر البريد الإلكتروني و/ أو بإشعار بارز في خدمتنا، قبل أن يصبح التغيير ساريًا وتحديث &quot;تاريخ الفعالية&quot; في أعلى سياسة الخصوصية هذه.\r\nننصحك بمراجعة سياسة الخصوصية هذه بشكل دوري لأية تغييرات. تسري التغييرات التي تطرأ على سياسة الخصوصية هذه عند نشرها على هذه الصفحة.', ''),
(30, 15, 'en', 'Changes To This Privacy Policy', '', 'We may update our Privacy Policy from time to time. We will notify you of any changes by posting the new Privacy Policy on this page.\r\n\r\nWe will let you know via email and/or a prominent notice on our Service, prior to the change becoming effective and update the &quot;effective date&quot; at the top of this Privacy Policy.\r\n\r\nYou are advised to review this Privacy Policy periodically for any changes. Changes to this Privacy Policy are effective when they are posted on this page.', ''),
(31, 16, 'ar', 'اتصل بنا', '', 'إذا كان لديك أي أسئلة حول سياسة الخصوصية هذه، يرجى الاتصال بنا:', 'البريد الإلكتروني : info@etman-group.com'),
(32, 16, 'en', 'Contact Us', '', 'If you have any questions about this Privacy Policy, please contact us:', 'Email:info@etman-group.com');

-- --------------------------------------------------------

--
-- Table structure for table `data_countries`
--

CREATE TABLE `data_countries` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `iso2` varchar(2) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `iso3` varchar(3) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `fips` varchar(3) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `iso_numeric` varchar(3) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `photo` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `photo_thum_1` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `photo_thum_2` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `phone` int(11) DEFAULT NULL,
  `symbol` varchar(10) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `currency_code` varchar(3) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `continent_code` varchar(2) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `language_codes` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `top_level_domain` varchar(5) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `time_zone` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `area_km` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_active` int(11) NOT NULL DEFAULT 1,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `data_countries`
--

INSERT INTO `data_countries` (`id`, `iso2`, `iso3`, `fips`, `iso_numeric`, `photo`, `photo_thum_1`, `photo_thum_2`, `phone`, `symbol`, `currency_code`, `continent_code`, `language_codes`, `top_level_domain`, `time_zone`, `area_km`, `is_active`, `deleted_at`) VALUES
(1, 'AF', 'AFG', 'AF', '4', '256/af.webp', '120/af.webp', NULL, 93, '؋', 'AFN', 'AS', 'fa-AF,ps,uz-AF,tk', 'af', 'Asia/Kabul', '647500', 0, NULL),
(2, 'AX', NULL, NULL, NULL, '256/ax.webp', '120/ax.webp', NULL, 358, '€', 'EUR', 'EU', NULL, NULL, NULL, NULL, 0, NULL),
(3, 'AL', 'ALB', 'AL', '8', '256/al.webp', '120/al.webp', NULL, 355, 'Lek', 'ALL', 'EU', 'sq,el', 'al', 'Europe/Tirane', '28748', 0, NULL),
(4, 'DZ', 'DZA', 'AG', '12', '256/dz.webp', '120/dz.webp', NULL, 213, 'دج', 'DZD', 'AF', 'ar-DZ', 'dz', 'Africa/Algiers', '2381740', 1, NULL),
(5, 'AS', 'ASM', 'AQ', '16', '256/as.webp', '120/as.webp', NULL, 1684, '$', 'USD', 'OC', 'en-AS,sm,to', 'as', 'Pacific/Pago_Pago', '199', 0, NULL),
(6, 'AD', 'AND', 'AN', '20', '256/ad.webp', '120/ad.webp', NULL, 376, '€', 'EUR', 'EU', 'ca', 'ad', 'Europe/Andorra', '468', 0, NULL),
(7, 'AO', 'AGO', 'AO', '24', '256/ao.webp', '120/ao.webp', NULL, 244, 'Kz', 'AOA', 'AF', 'pt-AO', 'ao', 'Africa/Luanda', '1246700', 0, NULL),
(8, 'AI', 'AIA', 'AV', '660', '256/ai.webp', '120/ai.webp', NULL, 1264, '$', 'XCD', 'NA', 'en-AI', 'ai', 'America/Anguilla', '102', 0, NULL),
(9, 'AQ', 'ATA', 'AY', '10', '256/aq.webp', '120/aq.webp', NULL, 672, '$', 'AAD', 'AN', '', 'aq', 'Antarctica/Troll', '14000000', 0, NULL),
(10, 'AG', 'ATG', 'AC', '28', '256/ag.webp', '120/ag.webp', NULL, 1268, '$', 'XCD', 'NA', 'en-AG', 'ag', 'America/Antigua', '443', 0, NULL),
(11, 'AR', 'ARG', 'AR', '32', '256/ar.webp', '120/ar.webp', NULL, 54, '$', 'ARS', 'SA', 'es-AR,en,it,de,fr,gn', 'ar', 'America/Argentina/Buenos_Aires', '2766890', 1, NULL),
(12, 'AM', 'ARM', 'AM', '51', '256/am.webp', '120/am.webp', NULL, 374, '֏', 'AMD', 'AS', 'hy', 'am', 'Asia/Yerevan', '29800', 0, NULL),
(13, 'AW', 'ABW', 'AA', '533', '256/aw.webp', '120/aw.webp', NULL, 297, 'ƒ', 'AWG', 'NA', 'nl-AW,es,en', 'aw', 'America/Aruba', '193', 0, NULL),
(14, 'AU', 'AUS', 'AS', '36', '256/au.webp', '120/au.webp', NULL, 61, '$', 'AUD', 'OC', 'en-AU', 'au', 'Australia/Sydney', '7686850', 1, NULL),
(15, 'AT', 'AUT', 'AU', '40', '256/at.webp', '120/at.webp', NULL, 43, '€', 'EUR', 'EU', 'de-AT,hr,hu,sl', 'at', 'Europe/Vienna', '83858', 1, NULL),
(16, 'AZ', 'AZE', 'AJ', '31', '256/az.webp', '120/az.webp', NULL, 994, 'm', 'AZN', 'AS', 'az,ru,hy', 'az', 'Asia/Baku', '86600', 0, NULL),
(17, 'BS', 'BHS', 'BF', '44', '256/bs.webp', '120/bs.webp', NULL, 1242, 'B$', 'BSD', 'NA', 'en-BS', 'bs', 'America/Nassau', '13940', 0, NULL),
(18, 'BH', 'BHR', 'BA', '48', '256/bh.webp', '120/bh.webp', NULL, 973, '.د.ب', 'BHD', 'AS', 'ar-BH,en,fa,ur', 'bh', 'Asia/Bahrain', '665', 1, NULL),
(19, 'BD', 'BGD', 'BG', '50', '256/bd.webp', '120/bd.webp', NULL, 880, '৳', 'BDT', 'AS', 'bn-BD,en', 'bd', 'Asia/Dhaka', '144000', 0, NULL),
(20, 'BB', 'BRB', 'BB', '52', '256/bb.webp', '120/bb.webp', NULL, 1246, 'Bds$', 'BBD', 'NA', 'en-BB', 'bb', 'America/Barbados', '431', 0, NULL),
(21, 'BY', 'BLR', 'BO', '112', '256/by.webp', '120/by.webp', NULL, 375, 'Br', 'BYN', 'EU', 'be,ru', 'by', 'Europe/Minsk', '207600', 0, NULL),
(22, 'BE', 'BEL', 'BE', '56', '256/be.webp', '120/be.webp', NULL, 32, '€', 'EUR', 'EU', 'nl-BE,fr-BE,de-BE', 'be', 'Europe/Brussels', '30510', 1, NULL),
(23, 'BZ', 'BLZ', 'BH', '84', '256/bz.webp', '120/bz.webp', NULL, 501, '$', 'BZD', 'NA', 'en-BZ,es', 'bz', 'America/Belize', '22966', 0, NULL),
(24, 'BJ', 'BEN', 'BN', '204', '256/bj.webp', '120/bj.webp', NULL, 229, 'CFA', 'XOF', 'AF', 'fr-BJ', 'bj', 'Africa/Porto-Novo', '112620', 0, NULL),
(25, 'BM', 'BMU', 'BD', '60', '256/bm.webp', '120/bm.webp', NULL, 1441, '$', 'BMD', 'NA', 'en-BM,pt', 'bm', 'Atlantic/Bermuda', '53', 0, NULL),
(26, 'BT', 'BTN', 'BT', '64', '256/bt.webp', '120/bt.webp', NULL, 975, 'Nu.', 'BTN', 'AS', 'dz', 'bt', 'Asia/Thimphu', '47000', 0, NULL),
(27, 'BO', 'BOL', 'BL', '68', '256/bo.webp', '120/bo.webp', NULL, 591, 'Bs.', 'BOB', 'SA', 'es-BO,qu,ay', 'bo', 'America/La_Paz', '1098580', 0, NULL),
(28, 'BQ', NULL, NULL, NULL, '256/bq.webp', '120/bq.webp', NULL, 599, '$', 'USD', 'NA', NULL, NULL, NULL, NULL, 0, NULL),
(29, 'BA', 'BIH', 'BK', '70', '256/ba.webp', '120/ba.webp', NULL, 387, 'KM', 'BAM', 'EU', 'bs,hr-BA,sr-BA', 'ba', 'Europe/Sarajevo', '51129', 0, NULL),
(30, 'BW', 'BWA', 'BC', '72', '256/bw.webp', '120/bw.webp', NULL, 267, 'P', 'BWP', 'AF', 'en-BW,tn-BW', 'bw', 'Africa/Gaborone', '600370', 0, NULL),
(31, 'BV', NULL, NULL, NULL, '256/bv.webp', '120/bv.webp', NULL, 55, 'kr', 'NOK', 'AN', NULL, NULL, NULL, NULL, 0, NULL),
(32, 'BR', 'BRA', 'BR', '76', '256/br.webp', '120/br.webp', NULL, 55, 'R$', 'BRL', 'SA', 'pt-BR,es,en,fr', 'br', 'America/Sao_Paulo', '8511965', 1, NULL),
(33, 'IO', 'IOT', 'IO', '86', '256/io.webp', '120/io.webp', NULL, 246, '$', 'USD', 'AS', 'en-IO', 'io', 'Indian/Chagos', '60', 0, NULL),
(34, 'BN', 'BRN', 'BX', '96', '256/bn.webp', '120/bn.webp', NULL, 673, 'B$', 'BND', 'AS', 'ms-BN,en-BN', 'bn', 'Asia/Brunei', '5770', 0, NULL),
(35, 'BG', 'BGR', 'BU', '100', '256/bg.webp', '120/bg.webp', NULL, 359, 'Лв.', 'BGN', 'EU', 'bg,tr-BG', 'bg', 'Europe/Sofia', '110910', 0, NULL),
(36, 'BF', 'BFA', 'UV', '854', '256/bf.webp', '120/bf.webp', NULL, 226, 'CFA', 'XOF', 'AF', 'fr-BF', 'bf', 'Africa/Ouagadougou', '274200', 0, NULL),
(37, 'BI', 'BDI', 'BY', '108', '256/bi.webp', '120/bi.webp', NULL, 257, 'FBu', 'BIF', 'AF', 'fr-BI,rn', 'bi', 'Africa/Bujumbura', '27830', 0, NULL),
(38, 'KH', 'KHM', 'CB', '116', '256/kh.webp', '120/kh.webp', NULL, 855, 'KHR', 'KHR', 'AS', 'km,fr,en', 'kh', 'Asia/Phnom_Penh', '181040', 0, NULL),
(39, 'CM', 'CMR', 'CM', '120', '256/cm.webp', '120/cm.webp', NULL, 237, 'FCFA', 'XAF', 'AF', 'en-CM,fr-CM', 'cm', 'Africa/Douala', '475440', 0, NULL),
(40, 'CA', 'CAN', 'CA', '124', '256/ca.webp', '120/ca.webp', NULL, 1, '$', 'CAD', 'NA', 'en-CA,fr-CA,iu', 'ca', 'America/Toronto', '9984670', 1, NULL),
(41, 'CV', 'CPV', 'CV', '132', '256/cv.webp', '120/cv.webp', NULL, 238, '$', 'CVE', 'AF', 'pt-CV', 'cv', 'Atlantic/Cape_Verde', '4033', 0, NULL),
(42, 'KY', 'CYM', 'CJ', '136', '256/ky.webp', '120/ky.webp', NULL, 1345, '$', 'KYD', 'NA', 'en-KY', 'ky', 'America/Cayman', '262', 0, NULL),
(43, 'CF', 'CAF', 'CT', '140', '256/cf.webp', '120/cf.webp', NULL, 236, 'FCFA', 'XAF', 'AF', 'fr-CF,sg,ln,kg', 'cf', 'Africa/Bangui', '622984', 0, NULL),
(44, 'TD', 'TCD', 'CD', '148', '256/td.webp', '120/td.webp', NULL, 235, 'FCFA', 'XAF', 'AF', 'fr-TD,ar-TD,sre', 'td', 'Africa/Ndjamena', '1284000', 0, NULL),
(45, 'CL', 'CHL', 'CI', '152', '256/cl.webp', '120/cl.webp', NULL, 56, '$', 'CLP', 'SA', 'es-CL', 'cl', 'America/Santiago', '756950', 0, NULL),
(46, 'CN', 'CHN', 'CH', '156', '256/cn.webp', '120/cn.webp', NULL, 86, '¥', 'CNY', 'AS', 'zh-CN,yue,wuu,dta,ug,za', 'cn', 'Asia/Shanghai', '9596960', 1, NULL),
(47, 'CX', 'CXR', 'KT', '162', '256/cx.webp', '120/cx.webp', NULL, 61, '$', 'AUD', 'AS', 'en,zh,ms-CC', 'cx', 'Indian/Christmas', '135', 0, NULL),
(48, 'CC', 'CCK', 'CK', '166', '256/cc.webp', '120/cc.webp', NULL, 672, '$', 'AUD', 'AS', 'ms-CC,en', 'cc', 'Indian/Cocos', '14', 0, NULL),
(49, 'CO', 'COL', 'CO', '170', '256/co.webp', '120/co.webp', NULL, 57, '$', 'COP', 'SA', 'es-CO', 'co', 'America/Bogota', '1138910', 0, NULL),
(50, 'KM', 'COM', 'CN', '174', '256/km.webp', '120/km.webp', NULL, 269, 'CF', 'KMF', 'AF', 'ar,fr-KM', 'km', 'Indian/Comoro', '2170', 0, NULL),
(51, 'CG', 'COG', 'CF', '178', '256/cg.webp', '120/cg.webp', NULL, 242, 'FC', 'XAF', 'AF', 'fr-CG,kg,ln-CG', 'cg', 'Africa/Brazzaville', '342000', 0, NULL),
(52, 'CD', 'COD', 'CG', '180', '256/cd.webp', '120/cd.webp', NULL, 242, 'FC', 'CDF', 'AF', 'fr-CD,ln,kg', 'cd', 'Africa/Kinshasa', '2345410', 0, NULL),
(53, 'CK', 'COK', 'CW', '184', '256/ck.webp', '120/ck.webp', NULL, 682, '$', 'NZD', 'OC', 'en-CK,mi', 'ck', 'Pacific/Rarotonga', '240', 0, NULL),
(54, 'CR', 'CRI', 'CS', '188', '256/cr.webp', '120/cr.webp', NULL, 506, '₡', 'CRC', 'NA', 'es-CR,en', 'cr', 'America/Costa_Rica', '51100', 0, NULL),
(55, 'CI', 'CIV', 'IV', '384', '256/ci.webp', '120/ci.webp', NULL, 225, 'CFA', 'XOF', 'AF', 'fr-CI', 'ci', 'Africa/Abidjan', '322460', 0, NULL),
(56, 'HR', 'HRV', 'HR', '191', '256/hr.webp', '120/hr.webp', NULL, 385, 'kn', 'HRK', 'EU', 'hr-HR,sr', 'hr', 'Europe/Zagreb', '56542', 0, NULL),
(57, 'CU', 'CUB', 'CU', '192', '256/cu.webp', '120/cu.webp', NULL, 53, '$', 'CUP', 'NA', 'es-CU', 'cu', 'America/Havana', '110860', 0, NULL),
(58, 'CW', 'CUW', 'UC', '531', '256/cw.webp', '120/cw.webp', NULL, 599, 'ƒ', 'ANG', 'NA', 'nl,pap', 'cw', 'America/Curacao', '444', 0, NULL),
(59, 'CY', 'CYP', 'CY', '196', '256/cy.webp', '120/cy.webp', NULL, 357, '€', 'EUR', 'AS', 'el-CY,tr-CY,en', 'cy', 'Asia/Nicosia', '9250', 1, NULL),
(60, 'CZ', 'CZE', 'EZ', '203', '256/cz.webp', '120/cz.webp', NULL, 420, 'Kč', 'CZK', 'EU', 'cs,sk', 'cz', 'Europe/Prague', '78866', 0, NULL),
(61, 'DK', 'DNK', 'DA', '208', '256/dk.webp', '120/dk.webp', NULL, 45, 'Kr.', 'DKK', 'EU', 'da-DK,en,fo,de-DK', 'dk', 'Europe/Copenhagen', '43094', 1, NULL),
(62, 'DJ', 'DJI', 'DJ', '262', '256/dj.webp', '120/dj.webp', NULL, 253, 'Fdj', 'DJF', 'AF', 'fr-DJ,ar,so-DJ,aa', 'dj', 'Africa/Djibouti', '23000', 0, NULL),
(63, 'DM', 'DMA', 'DO', '212', '256/dm.webp', '120/dm.webp', NULL, 1767, '$', 'XCD', 'NA', 'en-DM', 'dm', 'America/Dominica', '754', 0, NULL),
(64, 'DO', 'DOM', 'DR', '214', '256/do.webp', '120/do.webp', NULL, 1809, '$', 'DOP', 'NA', 'es-DO', 'do', 'America/Santo_Domingo', '48730', 0, NULL),
(65, 'EC', 'ECU', 'EC', '218', '256/ec.webp', '120/ec.webp', NULL, 593, '$', 'USD', 'SA', 'es-EC', 'ec', 'America/Guayaquil', '283560', 0, NULL),
(66, 'EG', 'EGY', 'EG', '818', '256/eg.webp', '120/eg.webp', NULL, 20, 'ج.م', 'EGP', 'AF', 'ar-EG,en,fr', 'eg', 'Africa/Cairo', '1001450', 1, NULL),
(67, 'SV', 'SLV', 'ES', '222', '256/sv.webp', '120/sv.webp', NULL, 503, '$', 'USD', 'NA', 'es-SV', 'sv', 'America/El_Salvador', '21040', 0, NULL),
(68, 'GQ', 'GNQ', 'EK', '226', '256/gq.webp', '120/gq.webp', NULL, 240, 'FCFA', 'XAF', 'AF', 'es-GQ,fr', 'gq', 'Africa/Malabo', '28051', 0, NULL),
(69, 'ER', 'ERI', 'ER', '232', '256/er.webp', '120/er.webp', NULL, 291, 'Nfk', 'ERN', 'AF', 'aa-ER,ar,tig,kun,ti-ER', 'er', 'Africa/Asmara', '121320', 0, NULL),
(70, 'EE', 'EST', 'EN', '233', '256/ee.webp', '120/ee.webp', NULL, 372, '€', 'EUR', 'EU', 'et,ru', 'ee', 'Europe/Tallinn', '45226', 0, NULL),
(71, 'ET', 'ETH', 'ET', '231', '256/et.webp', '120/et.webp', NULL, 251, 'Nkf', 'ETB', 'AF', 'am,en-ET,om-ET,ti-ET,so-ET,sid', 'et', 'Africa/Addis_Ababa', '1127127', 0, NULL),
(72, 'FK', 'FLK', 'FK', '238', '256/fk.webp', '120/fk.webp', NULL, 500, '£', 'FKP', 'SA', 'en-FK', 'fk', 'Atlantic/Stanley', '12173', 0, NULL),
(73, 'FO', 'FRO', 'FO', '234', '256/fo.webp', '120/fo.webp', NULL, 298, 'Kr.', 'DKK', 'EU', 'fo,da-FO', 'fo', 'Atlantic/Faroe', '1399', 0, NULL),
(74, 'FJ', 'FJI', 'FJ', '242', '256/fj.webp', '120/fj.webp', NULL, 679, 'FJ$', 'FJD', 'OC', 'en-FJ,fj', 'fj', 'Pacific/Fiji', '18270', 0, NULL),
(75, 'FI', 'FIN', 'FI', '246', '256/fi.webp', '120/fi.webp', NULL, 358, '€', 'EUR', 'EU', 'fi-FI,sv-FI,smn', 'fi', 'Europe/Helsinki', '337030', 1, NULL),
(76, 'FR', 'FRA', 'FR', '250', '256/fr.webp', '120/fr.webp', NULL, 33, '€', 'EUR', 'EU', 'fr-FR,frp,br,co,ca,eu,oc', 'fr', 'Europe/Paris', '547030', 1, NULL),
(77, 'GF', NULL, NULL, NULL, '256/gf.webp', '120/gf.webp', NULL, 594, '€', 'EUR', 'SA', NULL, NULL, NULL, NULL, 0, NULL),
(78, 'PF', 'PYF', 'FP', '258', '256/pf.webp', '120/pf.webp', NULL, 689, '₣', 'XPF', 'OC', 'fr-PF,ty', 'pf', 'Pacific/Tahiti', '4167', 0, NULL),
(79, 'TF', NULL, NULL, NULL, '256/tf.webp', '120/tf.webp', NULL, 262, '€', 'EUR', 'AN', NULL, NULL, NULL, NULL, 0, NULL),
(80, 'GA', 'GAB', 'GB', '266', '256/ga.webp', '120/ga.webp', NULL, 241, 'FCFA', 'XAF', 'AF', 'fr-GA', 'ga', 'Africa/Libreville', '267667', 0, NULL),
(81, 'GM', 'GMB', 'GA', '270', '256/gm.webp', '120/gm.webp', NULL, 220, 'D', 'GMD', 'AF', 'en-GM,mnk,wof,wo,ff', 'gm', 'Africa/Banjul', '11300', 0, NULL),
(82, 'GE', 'GEO', 'GG', '268', '256/ge.webp', '120/ge.webp', NULL, 995, 'ლ', 'GEL', 'AS', 'ka,ru,hy,az', 'ge', 'Asia/Tbilisi', '69700', 0, NULL),
(83, 'DE', 'DEU', 'GM', '276', '256/de.webp', '120/de.webp', NULL, 49, '€', 'EUR', 'EU', 'de', 'de', 'Europe/Berlin', '357021', 1, NULL),
(84, 'GH', 'GHA', 'GH', '288', '256/gh.webp', '120/gh.webp', NULL, 233, 'GH₵', 'GHS', 'AF', 'en-GH,ak,ee,tw', 'gh', 'Africa/Accra', '239460', 0, NULL),
(85, 'GI', 'GIB', 'GI', '292', '256/gi.webp', '120/gi.webp', NULL, 350, '£', 'GIP', 'EU', 'en-GI,es,it,pt', 'gi', 'Europe/Gibraltar', '7', 0, NULL),
(86, 'GR', 'GRC', 'GR', '300', '256/gr.webp', '120/gr.webp', NULL, 30, '€', 'EUR', 'EU', 'el-GR,en,fr', 'gr', 'Europe/Athens', '131940', 1, NULL),
(87, 'GL', 'GRL', 'GL', '304', '256/gl.webp', '120/gl.webp', NULL, 299, 'Kr.', 'DKK', 'NA', 'kl,da-GL,en', 'gl', 'America/Godthab', '2166086', 0, NULL),
(88, 'GD', 'GRD', 'GJ', '308', '256/gd.webp', '120/gd.webp', NULL, 1473, '$', 'XCD', 'NA', 'en-GD', 'gd', 'America/Grenada', '344', 0, NULL),
(89, 'GP', NULL, NULL, NULL, '256/gp.webp', '120/gp.webp', NULL, 590, '€', 'EUR', 'NA', NULL, NULL, NULL, NULL, 0, NULL),
(90, 'GU', 'GUM', 'GQ', '316', '256/gu.webp', '120/gu.webp', NULL, 1671, '$', 'USD', 'OC', 'en-GU,ch-GU', 'gu', 'Pacific/Guam', '549', 0, NULL),
(91, 'GT', 'GTM', 'GT', '320', '256/gt.webp', '120/gt.webp', NULL, 502, 'Q', 'GTQ', 'NA', 'es-GT', 'gt', 'America/Guatemala', '108890', 0, NULL),
(92, 'GG', 'GGY', 'GK', '831', '256/gg.webp', '120/gg.webp', NULL, 44, '£', 'GBP', 'EU', 'en,fr', 'gg', 'Europe/Guernsey', '78', 0, NULL),
(93, 'GN', 'GIN', 'GV', '324', '256/gn.webp', '120/gn.webp', NULL, 224, 'FG', 'GNF', 'AF', 'fr-GN', 'gn', 'Africa/Conakry', '245857', 0, NULL),
(94, 'GW', 'GNB', 'PU', '624', '256/gw.webp', '120/gw.webp', NULL, 245, 'CFA', 'XOF', 'AF', 'pt-GW,pov', 'gw', 'Africa/Bissau', '36120', 0, NULL),
(95, 'GY', 'GUY', 'GY', '328', '256/gy.webp', '120/gy.webp', NULL, 592, '$', 'GYD', 'SA', 'en-GY', 'gy', 'America/Guyana', '214970', 0, NULL),
(96, 'HT', 'HTI', 'HA', '332', '256/ht.webp', '120/ht.webp', NULL, 509, 'G', 'HTG', 'NA', 'ht,fr-HT', 'ht', 'America/Port-au-Prince', '27750', 0, NULL),
(97, 'HM', NULL, NULL, NULL, '256/hm.webp', '120/hm.webp', NULL, 0, '$', 'AUD', 'AN', NULL, NULL, NULL, NULL, 0, NULL),
(98, 'VA', 'VAT', 'VT', '336', '256/va.webp', '120/va.webp', NULL, 39, '€', 'EUR', 'EU', 'la,it,fr', 'va', 'Europe/Vatican', '0', 0, NULL),
(99, 'HN', 'HND', 'HO', '340', '256/hn.webp', '120/hn.webp', NULL, 504, 'L', 'HNL', 'NA', 'es-HN', 'hn', 'America/Tegucigalpa', '112090', 0, NULL),
(100, 'HK', 'HKG', 'HK', '344', '256/hk.webp', '120/hk.webp', NULL, 852, '$', 'HKD', 'AS', 'zh-HK,yue,zh,en', 'hk', 'Asia/Hong_Kong', '1092', 1, NULL),
(101, 'HU', 'HUN', 'HU', '348', '256/hu.webp', '120/hu.webp', NULL, 36, 'Ft', 'HUF', 'EU', 'hu-HU', 'hu', 'Europe/Budapest', '93030', 0, NULL),
(102, 'IS', 'ISL', 'IC', '352', '256/is.webp', '120/is.webp', NULL, 354, 'kr', 'ISK', 'EU', 'is,en,de,da,sv,no', 'is', 'Atlantic/Reykjavik', '103000', 0, NULL),
(103, 'IN', 'IND', 'IN', '356', '256/in.webp', '120/in.webp', NULL, 91, '₹', 'INR', 'AS', 'en-IN,hi,bn,te,mr,ta,ur,gu,kn,ml,or,pa,as,bh,sat,ks,ne,sd,kok,doi,mni,sit,sa,fr,lus,inc', 'in', 'Asia/Kolkata', '3287590', 1, NULL),
(104, 'ID', 'IDN', 'ID', '360', '256/id.webp', '120/id.webp', NULL, 62, 'Rp', 'IDR', 'AS', 'id,en,nl,jv', 'id', 'Asia/Jakarta', '1919440', 1, NULL),
(105, 'IR', 'IRN', 'IR', '364', '256/ir.webp', '120/ir.webp', NULL, 98, '﷼', 'IRR', 'AS', 'fa-IR,ku', 'ir', 'Asia/Tehran', '1648000', 1, NULL),
(106, 'IQ', 'IRQ', 'IZ', '368', '256/iq.webp', '120/iq.webp', NULL, 964, 'د.ع', 'IQD', 'AS', 'ar-IQ,ku,hy', 'iq', 'Asia/Baghdad', '437072', 1, NULL),
(107, 'IE', 'IRL', 'EI', '372', '256/ie.webp', '120/ie.webp', NULL, 353, '€', 'EUR', 'EU', 'en-IE,ga-IE', 'ie', 'Europe/Dublin', '70280', 1, NULL),
(108, 'IM', 'IMN', 'IM', '833', '256/im.webp', '120/im.webp', NULL, 44, '£', 'GBP', 'EU', 'en,gv', 'im', 'Europe/Isle_of_Man', '572', 0, NULL),
(109, 'IL', 'ISR', 'IS', '376', '256/il.webp', '120/il.webp', NULL, 972, '₪', 'ILS', 'AS', 'he,ar-IL,en-IL,', 'il', 'Asia/Jerusalem', '20770', 0, NULL),
(110, 'IT', 'ITA', 'IT', '380', '256/it.webp', '120/it.webp', NULL, 39, '€', 'EUR', 'EU', 'it-IT,de-IT,fr-IT,sc,ca,co,sl', 'it', 'Europe/Rome', '301230', 1, NULL),
(111, 'JM', 'JAM', 'JM', '388', '256/jm.webp', '120/jm.webp', NULL, 1876, 'J$', 'JMD', 'NA', 'en-JM', 'jm', 'America/Jamaica', '10991', 0, NULL),
(112, 'JP', 'JPN', 'JA', '392', '256/jp.webp', '120/jp.webp', NULL, 81, '¥', 'JPY', 'AS', 'ja', 'jp', 'Asia/Tokyo', '377835', 1, NULL),
(113, 'JE', 'JEY', 'JE', '832', '256/je.webp', '120/je.webp', NULL, 44, '£', 'GBP', 'EU', 'en,pt', 'je', 'Europe/Jersey', '116', 0, NULL),
(114, 'JO', 'JOR', 'JO', '400', '256/jo.webp', '120/jo.webp', NULL, 962, 'ا.د', 'JOD', 'AS', 'ar-JO,en', 'jo', 'Asia/Amman', '92300', 1, NULL),
(115, 'KZ', 'KAZ', 'KZ', '398', '256/kz.webp', '120/kz.webp', NULL, 7, 'лв', 'KZT', 'AS', 'kk,ru', 'kz', 'Asia/Almaty', '2717300', 0, NULL),
(116, 'KE', 'KEN', 'KE', '404', '256/ke.webp', '120/ke.webp', NULL, 254, 'KSh', 'KES', 'AF', 'en-KE,sw-KE', 'ke', 'Africa/Nairobi', '582650', 0, NULL),
(117, 'KI', 'KIR', 'KR', '296', '256/ki.webp', '120/ki.webp', NULL, 686, '$', 'AUD', 'OC', 'en-KI,gil', 'ki', 'Pacific/Tarawa', '811', 0, NULL),
(118, 'KP', 'PRK', 'KN', '408', '256/kp.webp', '120/kp.webp', NULL, 850, '₩', 'KPW', 'AS', 'ko-KP', 'kp', 'Asia/Pyongyang', '120540', 0, NULL),
(119, 'KR', 'KOR', 'KS', '410', '256/kr.webp', '120/kr.webp', NULL, 82, '₩', 'KRW', 'AS', 'ko-KR,en', 'kr', 'Asia/Seoul', '98480', 0, NULL),
(120, 'XK', 'XKX', 'KV', '0', '256/xk.webp', '120/xk.webp', NULL, 383, '€', 'EUR', 'EU', 'sq,sr', '', 'Europe/Podgorica', '10887', 0, NULL),
(121, 'KW', 'KWT', 'KU', '414', '256/kw.webp', '120/kw.webp', NULL, 965, 'ك.د', 'KWD', 'AS', 'ar-KW,en', 'kw', 'Asia/Kuwait', '17820', 1, NULL),
(122, 'KG', 'KGZ', 'KG', '417', '256/kg.webp', '120/kg.webp', NULL, 996, 'лв', 'KGS', 'AS', 'ky,uz,ru', 'kg', 'Asia/Bishkek', '198500', 0, NULL),
(123, 'LA', 'LAO', 'LA', '418', '256/la.webp', '120/la.webp', NULL, 856, '₭', 'LAK', 'AS', 'lo,fr,en', 'la', 'Asia/Vientiane', '236800', 0, NULL),
(124, 'LV', 'LVA', 'LG', '428', '256/lv.webp', '120/lv.webp', NULL, 371, '€', 'EUR', 'EU', 'lv,ru,lt', 'lv', 'Europe/Riga', '64589', 0, NULL),
(125, 'LB', 'LBN', 'LE', '422', '256/lb.webp', '120/lb.webp', NULL, 961, '£', 'LBP', 'AS', 'ar-LB,fr-LB,en,hy', 'lb', 'Asia/Beirut', '10400', 1, NULL),
(126, 'LS', 'LSO', 'LT', '426', '256/ls.webp', '120/ls.webp', NULL, 266, 'L', 'LSL', 'AF', 'en-LS,st,zu,xh', 'ls', 'Africa/Maseru', '30355', 0, NULL),
(127, 'LR', 'LBR', 'LI', '430', '256/lr.webp', '120/lr.webp', NULL, 231, '$', 'LRD', 'AF', 'en-LR', 'lr', 'Africa/Monrovia', '111370', 0, NULL),
(128, 'LY', 'LBY', 'LY', '434', '256/ly.webp', '120/ly.webp', NULL, 218, 'د.ل', 'LYD', 'AF', 'ar-LY,it,en', 'ly', 'Africa/Tripoli', '1759540', 1, NULL),
(129, 'LI', 'LIE', 'LS', '438', '256/li.webp', '120/li.webp', NULL, 423, 'CHf', 'CHF', 'EU', 'de-LI', 'li', 'Europe/Vaduz', '160', 0, NULL),
(130, 'LT', 'LTU', 'LH', '440', '256/lt.webp', '120/lt.webp', NULL, 370, '€', 'EUR', 'EU', 'lt,ru,pl', 'lt', 'Europe/Vilnius', '65200', 0, NULL),
(131, 'LU', 'LUX', 'LU', '442', '256/lu.webp', '120/lu.webp', NULL, 352, '€', 'EUR', 'EU', 'lb,de-LU,fr-LU', 'lu', 'Europe/Luxembourg', '2586', 0, NULL),
(132, 'MO', 'MAC', 'MC', '446', '256/mo.webp', '120/mo.webp', NULL, 853, '$', 'MOP', 'AS', 'zh,zh-MO,pt', 'mo', 'Asia/Macau', '254', 0, NULL),
(133, 'MK', 'MKD', 'MK', '807', '256/mk.webp', '120/mk.webp', NULL, 389, 'ден', 'MKD', 'EU', 'mk,sq,tr,rmm,sr', 'mk', 'Europe/Skopje', '25333', 0, NULL),
(134, 'MG', 'MDG', 'MA', '450', '256/mg.webp', '120/mg.webp', NULL, 261, 'Ar', 'MGA', 'AF', 'fr-MG,mg', 'mg', 'Indian/Antananarivo', '587040', 0, NULL),
(135, 'MW', 'MWI', 'MI', '454', '256/mw.webp', '120/mw.webp', NULL, 265, 'MK', 'MWK', 'AF', 'ny,yao,tum,swk', 'mw', 'Africa/Blantyre', '118480', 0, NULL),
(136, 'MY', 'MYS', 'MY', '458', '256/my.webp', '120/my.webp', NULL, 60, 'RM', 'MYR', 'AS', 'ms-MY,en,zh,ta,te,ml,pa,th', 'my', 'Asia/Kuala_Lumpur', '329750', 1, NULL),
(137, 'MV', 'MDV', 'MV', '462', '256/mv.webp', '120/mv.webp', NULL, 960, 'Rf', 'MVR', 'AS', 'dv,en', 'mv', 'Indian/Maldives', '300', 1, NULL),
(138, 'ML', 'MLI', 'ML', '466', '256/ml.webp', '120/ml.webp', NULL, 223, 'CFA', 'XOF', 'AF', 'fr-ML,bm', 'ml', 'Africa/Bamako', '1240000', 0, NULL),
(139, 'MT', 'MLT', 'MT', '470', '256/mt.webp', '120/mt.webp', NULL, 356, '€', 'EUR', 'EU', 'mt,en-MT', 'mt', 'Europe/Malta', '316', 1, NULL),
(140, 'MH', 'MHL', 'RM', '584', '256/mh.webp', '120/mh.webp', NULL, 692, '$', 'USD', 'OC', 'mh,en-MH', 'mh', 'Pacific/Majuro', '181', 0, NULL),
(141, 'MQ', NULL, NULL, NULL, '256/mq.webp', '120/mq.webp', NULL, 596, '€', 'EUR', 'NA', NULL, NULL, NULL, NULL, 0, NULL),
(142, 'MR', 'MRT', 'MR', '478', '256/mr.webp', '120/mr.webp', NULL, 222, 'MRU', 'MRO', 'AF', 'ar-MR,fuc,snk,fr,mey,wo', 'mr', 'Africa/Nouakchott', '1030700', 0, NULL),
(143, 'MU', 'MUS', 'MP', '480', '256/mu.webp', '120/mu.webp', NULL, 230, '₨', 'MUR', 'AF', 'en-MU,bho,fr', 'mu', 'Indian/Mauritius', '2040', 0, NULL),
(144, 'YT', 'MYT', 'MF', '175', '256/yt.webp', '120/yt.webp', NULL, 262, '€', 'EUR', 'AF', 'fr-YT', 'yt', 'Indian/Mayotte', '374', 0, NULL),
(145, 'MX', 'MEX', 'MX', '484', '256/mx.webp', '120/mx.webp', NULL, 52, '$', 'MXN', 'NA', 'es-MX', 'mx', 'America/Mexico_City', '1972550', 1, NULL),
(146, 'FM', 'FSM', 'FM', '583', '256/fm.webp', '120/fm.webp', NULL, 691, '$', 'USD', 'OC', 'en-FM,chk,pon,yap,kos,uli,woe,nkr,kpg', 'fm', 'Pacific/Pohnpei', '702', 0, NULL),
(147, 'MD', 'MDA', 'MD', '498', '256/md.webp', '120/md.webp', NULL, 373, 'L', 'MDL', 'EU', 'ro,ru,gag,tr', 'md', 'Europe/Chisinau', '33843', 0, NULL),
(148, 'MC', 'MCO', 'MN', '492', '256/mc.webp', '120/mc.webp', NULL, 377, '€', 'EUR', 'EU', 'fr-MC,en,it', 'mc', 'Europe/Monaco', '2', 1, NULL),
(149, 'MN', 'MNG', 'MG', '496', '256/mn.webp', '120/mn.webp', NULL, 976, '₮', 'MNT', 'AS', 'mn,ru', 'mn', 'Asia/Ulaanbaatar', '1565000', 0, NULL),
(150, 'ME', 'MNE', 'MJ', '499', '256/me.webp', '120/me.webp', NULL, 382, '€', 'EUR', 'EU', 'sr,hu,bs,sq,hr,rom', 'me', 'Europe/Podgorica', '14026', 0, NULL),
(151, 'MS', 'MSR', 'MH', '500', '256/ms.webp', '120/ms.webp', NULL, 1664, '$', 'XCD', 'NA', 'en-MS', 'ms', 'America/Montserrat', '102', 0, NULL),
(152, 'MA', 'MAR', 'MO', '504', '256/ma.webp', '120/ma.webp', NULL, 212, 'DH', 'MAD', 'AF', 'ar-MA,fr', 'ma', 'Africa/Casablanca', '446550', 1, NULL),
(153, 'MZ', 'MOZ', 'MZ', '508', '256/mz.webp', '120/mz.webp', NULL, 258, 'MT', 'MZN', 'AF', 'pt-MZ,vmw', 'mz', 'Africa/Maputo', '801590', 0, NULL),
(154, 'MM', 'MMR', 'BM', '104', '256/mm.webp', '120/mm.webp', NULL, 95, 'K', 'MMK', 'AS', 'my', 'mm', 'Asia/Rangoon', '678500', 0, NULL),
(155, 'NA', 'NAM', 'WA', '516', '256/na.webp', '120/na.webp', NULL, 264, '$', 'NAD', 'AF', 'en-NA,af,de,hz,naq', 'na', 'Africa/Windhoek', '825418', 0, NULL),
(156, 'NR', 'NRU', 'NR', '520', '256/nr.webp', '120/nr.webp', NULL, 674, '$', 'AUD', 'OC', 'na,en-NR', 'nr', 'Pacific/Nauru', '21', 0, NULL),
(157, 'NP', 'NPL', 'NP', '524', '256/np.webp', '120/np.webp', NULL, 977, '₨', 'NPR', 'AS', 'ne,en', 'np', 'Asia/Kathmandu', '140800', 0, NULL),
(158, 'NL', 'NLD', 'NL', '528', '256/nl.webp', '120/nl.webp', NULL, 31, '€', 'EUR', 'EU', 'nl-NL,fy-NL', 'nl', 'Europe/Amsterdam', '41526', 1, NULL),
(159, 'AN', 'ANT', 'NT', '530', NULL, NULL, NULL, 599, 'NAf', 'ANG', 'NA', 'nl-AN,en,es', 'an', 'America/Curacao', '960', 0, NULL),
(160, 'NC', 'NCL', 'NC', '540', '256/nc.webp', '120/nc.webp', NULL, 687, '₣', 'XPF', 'OC', 'fr-NC', 'nc', 'Pacific/Noumea', '19060', 0, NULL),
(161, 'NZ', 'NZL', 'NZ', '554', '256/nz.webp', '120/nz.webp', NULL, 64, '$', 'NZD', 'OC', 'en-NZ,mi', 'nz', 'Pacific/Auckland', '268680', 0, NULL),
(162, 'NI', 'NIC', 'NU', '558', '256/ni.webp', '120/ni.webp', NULL, 505, 'C$', 'NIO', 'NA', 'es-NI,en', 'ni', 'America/Managua', '129494', 0, NULL),
(163, 'NE', 'NER', 'NG', '562', '256/ne.webp', '120/ne.webp', NULL, 227, 'CFA', 'XOF', 'AF', 'fr-NE,ha,kr,dje', 'ne', 'Africa/Niamey', '1267000', 0, NULL),
(164, 'NG', 'NGA', 'NI', '566', '256/ng.webp', '120/ng.webp', NULL, 234, '₦', 'NGN', 'AF', 'en-NG,ha,yo,ig,ff', 'ng', 'Africa/Lagos', '923768', 0, NULL),
(165, 'NU', 'NIU', 'NE', '570', '256/nu.webp', '120/nu.webp', NULL, 683, '$', 'NZD', 'OC', 'niu,en-NU', 'nu', 'Pacific/Niue', '260', 0, NULL),
(166, 'NF', NULL, NULL, NULL, '256/nf.webp', '120/nf.webp', NULL, 672, '$', 'AUD', 'OC', NULL, NULL, NULL, NULL, 0, NULL),
(167, 'MP', 'MNP', 'CQ', '580', '256/mp.webp', '120/mp.webp', NULL, 1670, '$', 'USD', 'OC', 'fil,tl,zh,ch-MP,en-MP', 'mp', 'Pacific/Saipan', '477', 0, NULL),
(168, 'NO', 'NOR', 'NO', '578', '256/no.webp', '120/no.webp', NULL, 47, 'kr', 'NOK', 'EU', 'no,nb,nn,se,fi', 'no', 'Europe/Oslo', '324220', 1, NULL),
(169, 'OM', 'OMN', 'MU', '512', '256/om.webp', '120/om.webp', NULL, 968, '.ع.ر', 'OMR', 'AS', 'ar-OM,en,bal,ur', 'om', 'Asia/Muscat', '212460', 1, NULL),
(170, 'PK', 'PAK', 'PK', '586', '256/pk.webp', '120/pk.webp', NULL, 92, '₨', 'PKR', 'AS', 'ur-PK,en-PK,pa,sd,ps,brh', 'pk', 'Asia/Karachi', '803940', 0, NULL),
(171, 'PW', 'PLW', 'PS', '585', '256/pw.webp', '120/pw.webp', NULL, 680, '$', 'USD', 'OC', 'pau,sov,en-PW,tox,ja,fil,zh', 'pw', 'Pacific/Palau', '458', 0, NULL),
(172, 'PS', 'PSE', 'WE', '275', '256/ps.webp', '120/ps.webp', NULL, 970, '₪', 'ILS', 'AS', 'ar-PS', 'ps', 'Asia/Hebron', '5970', 1, NULL),
(173, 'PA', 'PAN', 'PM', '591', '256/pa.webp', '120/pa.webp', NULL, 507, 'B/.', 'PAB', 'NA', 'es-PA,en', 'pa', 'America/Panama', '78200', 1, NULL),
(174, 'PG', 'PNG', 'PP', '598', '256/pg.webp', '120/pg.webp', NULL, 675, 'K', 'PGK', 'OC', 'en-PG,ho,meu,tpi', 'pg', 'Pacific/Port_Moresby', '462840', 0, NULL),
(175, 'PY', 'PRY', 'PA', '600', '256/py.webp', '120/py.webp', NULL, 595, '₲', 'PYG', 'SA', 'es-PY,gn', 'py', 'America/Asuncion', '406750', 0, NULL),
(176, 'PE', 'PER', 'PE', '604', '256/pe.webp', '120/pe.webp', NULL, 51, 'S/.', 'PEN', 'SA', 'es-PE,qu,ay', 'pe', 'America/Lima', '1285220', 0, NULL),
(177, 'PH', 'PHL', 'RP', '608', '256/ph.webp', '120/ph.webp', NULL, 63, '₱', 'PHP', 'AS', 'tl,en-PH,fil', 'ph', 'Asia/Manila', '300000', 0, NULL),
(178, 'PN', 'PCN', 'PC', '612', '256/pn.webp', '120/pn.webp', NULL, 64, '$', 'NZD', 'OC', 'en-PN', 'pn', 'Pacific/Pitcairn', '47', 0, NULL),
(179, 'PL', 'POL', 'PL', '616', '256/pl.webp', '120/pl.webp', NULL, 48, 'zł', 'PLN', 'EU', 'pl', 'pl', 'Europe/Warsaw', '312685', 1, NULL),
(180, 'PT', 'PRT', 'PO', '620', '256/pt.webp', '120/pt.webp', NULL, 351, '€', 'EUR', 'EU', 'pt-PT,mwl', 'pt', 'Europe/Lisbon', '92391', 1, NULL),
(181, 'PR', 'PRI', 'RQ', '630', '256/pr.webp', '120/pr.webp', NULL, 1787, '$', 'USD', 'NA', 'en-PR,es-PR', 'pr', 'America/Puerto_Rico', '9104', 0, NULL),
(182, 'QA', 'QAT', 'QA', '634', '256/qa.webp', '120/qa.webp', NULL, 974, 'ق.ر', 'QAR', 'AS', 'ar-QA,es', 'qa', 'Asia/Qatar', '11437', 1, NULL),
(183, 'RE', 'REU', 'RE', '638', '256/re.webp', '120/re.webp', NULL, 262, '€', 'EUR', 'AF', 'fr-RE', 're', 'Indian/Reunion', '2517', 0, NULL),
(184, 'RO', 'ROU', 'RO', '642', '256/ro.webp', '120/ro.webp', NULL, 40, 'lei', 'RON', 'EU', 'ro,hu,rom', 'ro', 'Europe/Bucharest', '237500', 1, NULL),
(185, 'RU', 'RUS', 'RS', '643', '256/ru.webp', '120/ru.webp', NULL, 7, '₽', 'RUB', 'AS', 'ru,tt,xal,cau,ady,kv,ce,tyv,cv,udm,tut,mns,bua,myv,mdf,chm,ba,inh,tut,kbd,krc,ava,sah,nog', 'ru', 'Europe/Moscow', '17100000', 1, NULL),
(186, 'RW', 'RWA', 'RW', '646', '256/rw.webp', '120/rw.webp', NULL, 250, 'FRw', 'RWF', 'AF', 'rw,en-RW,fr-RW,sw', 'rw', 'Africa/Kigali', '26338', 0, NULL),
(187, 'BL', 'BLM', 'TB', '652', '256/bl.webp', '120/bl.webp', NULL, 590, '€', 'EUR', 'NA', 'fr', 'gp', 'America/St_Barthelemy', '21', 0, NULL),
(188, 'SH', 'SHN', 'SH', '654', '256/sh.webp', '120/sh.webp', NULL, 290, '£', 'SHP', 'AF', 'en-SH', 'sh', 'Atlantic/St_Helena', '410', 0, NULL),
(189, 'KN', 'KNA', 'SC', '659', '256/kn.webp', '120/kn.webp', NULL, 1869, '$', 'XCD', 'NA', 'en-KN', 'kn', 'America/St_Kitts', '261', 0, NULL),
(190, 'LC', 'LCA', 'ST', '662', '256/lc.webp', '120/lc.webp', NULL, 1758, '$', 'XCD', 'NA', 'en-LC', 'lc', 'America/St_Lucia', '616', 0, NULL),
(191, 'MF', 'MAF', 'RN', '663', '256/mf.webp', '120/mf.webp', NULL, 590, '€', 'EUR', 'NA', 'fr', 'gp', 'America/Marigot', '53', 0, NULL),
(192, 'PM', 'SPM', 'SB', '666', '256/pm.webp', '120/pm.webp', NULL, 508, '€', 'EUR', 'NA', 'fr-PM', 'pm', 'America/Miquelon', '242', 0, NULL),
(193, 'VC', 'VCT', 'VC', '670', '256/vc.webp', '120/vc.webp', NULL, 1784, '$', 'XCD', 'NA', 'en-VC,fr', 'vc', 'America/St_Vincent', '389', 0, NULL),
(194, 'WS', 'WSM', 'WS', '882', '256/ws.webp', '120/ws.webp', NULL, 684, 'SAT', 'WST', 'OC', 'sm,en-WS', 'ws', 'Pacific/Apia', '2944', 0, NULL),
(195, 'SM', 'SMR', 'SM', '674', '256/sm.webp', '120/sm.webp', NULL, 378, '€', 'EUR', 'EU', 'it-SM', 'sm', 'Europe/San_Marino', '61', 0, NULL),
(196, 'ST', 'STP', 'TP', '678', '256/st.webp', '120/st.webp', NULL, 239, 'Db', 'STD', 'AF', 'pt-ST', 'st', 'Africa/Sao_Tome', '1001', 0, NULL),
(197, 'SA', 'SAU', 'SA', '682', '256/sa.webp', '120/sa.webp', NULL, 966, '﷼', 'SAR', 'AS', 'ar-SA', 'sa', 'Asia/Riyadh', '1960582', 1, NULL),
(198, 'SN', 'SEN', 'SG', '686', '256/sn.webp', '120/sn.webp', NULL, 221, 'CFA', 'XOF', 'AF', 'fr-SN,wo,fuc,mnk', 'sn', 'Africa/Dakar', '196190', 0, NULL),
(199, 'RS', 'SRB', 'RI', '688', '256/rs.webp', '120/rs.webp', NULL, 381, 'din', 'RSD', 'EU', 'sr,hu,bs,rom', 'rs', 'Europe/Belgrade', '88361', 0, NULL),
(200, 'CS', NULL, NULL, NULL, NULL, NULL, NULL, 381, 'din', 'RSD', 'EU', NULL, NULL, NULL, NULL, 1, NULL),
(201, 'SC', 'SYC', 'SE', '690', '256/sc.webp', '120/sc.webp', NULL, 248, 'SRe', 'SCR', 'AF', 'en-SC,fr-SC', 'sc', 'Indian/Mahe', '455', 0, NULL),
(202, 'SL', 'SLE', 'SL', '694', '256/sl.webp', '120/sl.webp', NULL, 232, 'Le', 'SLL', 'AF', 'en-SL,men,tem', 'sl', 'Africa/Freetown', '71740', 0, NULL),
(203, 'SG', 'SGP', 'SN', '702', '256/sg.webp', '120/sg.webp', NULL, 65, '$', 'SGD', 'AS', 'cmn,en-SG,ms-SG,ta-SG,zh-SG', 'sg', 'Asia/Singapore', '693', 1, NULL),
(204, 'SX', 'SXM', 'NN', '534', '256/sx.webp', '120/sx.webp', NULL, 721, 'ƒ', 'ANG', 'NA', 'nl,en', 'sx', 'America/Lower_Princes', '34', 0, NULL),
(205, 'SK', 'SVK', 'LO', '703', '256/sk.webp', '120/sk.webp', NULL, 421, '€', 'EUR', 'EU', 'sk,hu', 'sk', 'Europe/Bratislava', '48845', 0, NULL),
(206, 'SI', 'SVN', 'SI', '705', '256/si.webp', '120/si.webp', NULL, 386, '€', 'EUR', 'EU', 'sl,sh', 'si', 'Europe/Ljubljana', '20273', 0, NULL),
(207, 'SB', 'SLB', 'BP', '90', '256/sb.webp', '120/sb.webp', NULL, 677, 'Si$', 'SBD', 'OC', 'en-SB,tpi', 'sb', 'Pacific/Guadalcanal', '28450', 0, NULL),
(208, 'SO', 'SOM', 'SO', '706', '256/so.webp', '120/so.webp', NULL, 252, 'Sh.so.', 'SOS', 'AF', 'so-SO,ar-SO,it,en-SO', 'so', 'Africa/Mogadishu', '637657', 0, NULL),
(209, 'ZA', 'ZAF', 'SF', '710', '256/za.webp', '120/za.webp', NULL, 27, 'R', 'ZAR', 'AF', 'zu,xh,af,nso,en-ZA,tn,st,ts,ss,ve,nr', 'za', 'Africa/Johannesburg', '1219912', 0, NULL),
(210, 'GS', NULL, NULL, NULL, '256/gs.webp', '120/gs.webp', NULL, 500, '£', 'GBP', 'AN', NULL, NULL, NULL, NULL, 0, NULL),
(211, 'SS', 'SSD', 'OD', '728', '256/ss.webp', '120/ss.webp', NULL, 211, '£', 'SSP', 'AF', 'en', 'ss', 'Africa/Juba', '644329', 0, NULL),
(212, 'ES', 'ESP', 'SP', '724', '256/es.webp', '120/es.webp', NULL, 34, '€', 'EUR', 'EU', 'es-ES,ca,gl,eu,oc', 'es', 'Europe/Madrid', '504782', 1, NULL),
(213, 'LK', 'LKA', 'CE', '144', '256/lk.webp', '120/lk.webp', NULL, 94, 'Rs', 'LKR', 'AS', 'si,ta,en', 'lk', 'Asia/Colombo', '65610', 1, NULL),
(214, 'SD', 'SDN', 'SU', '729', '256/sd.webp', '120/sd.webp', NULL, 249, '.س.ج', 'SDG', 'AF', 'ar-SD,en,fia', 'sd', 'Africa/Khartoum', '1861484', 1, NULL),
(215, 'SR', 'SUR', 'NS', '740', '256/sr.webp', '120/sr.webp', NULL, 597, '$', 'SRD', 'SA', 'nl-SR,en,srn,hns,jv', 'sr', 'America/Paramaribo', '163270', 0, NULL),
(216, 'SJ', 'SJM', 'SV', '744', '256/sj.webp', '120/sj.webp', NULL, 47, 'kr', 'NOK', 'EU', 'no,ru', 'sj', 'Arctic/Longyearbyen', '62049', 0, NULL),
(217, 'SZ', 'SWZ', 'WZ', '748', '256/sz.webp', '120/sz.webp', NULL, 268, 'E', 'SZL', 'AF', 'en-SZ,ss-SZ', 'sz', 'Africa/Mbabane', '17363', 0, NULL),
(218, 'SE', 'SWE', 'SW', '752', '256/se.webp', '120/se.webp', NULL, 46, 'kr', 'SEK', 'EU', 'sv-SE,se,sma,fi-SE', 'se', 'Europe/Stockholm', '449964', 1, NULL),
(219, 'CH', 'CHE', 'SZ', '756', '256/ch.webp', '120/ch.webp', NULL, 41, 'CHf', 'CHF', 'EU', 'de-CH,fr-CH,it-CH,rm', 'ch', 'Europe/Zurich', '41290', 1, NULL),
(220, 'SY', 'SYR', 'SY', '760', '256/sy.webp', '120/sy.webp', NULL, 963, 'LS', 'SYP', 'AS', 'ar-SY,ku,hy,arc,fr,en', 'sy', 'Asia/Damascus', '185180', 1, NULL),
(221, 'TW', 'TWN', 'TW', '158', '256/tw.webp', '120/tw.webp', NULL, 886, '$', 'TWD', 'AS', 'zh-TW,zh,nan,hak', 'tw', 'Asia/Taipei', '35980', 1, NULL),
(222, 'TJ', 'TJK', 'TI', '762', '256/tj.webp', '120/tj.webp', NULL, 992, 'SM', 'TJS', 'AS', 'tg,ru', 'tj', 'Asia/Dushanbe', '143100', 0, NULL),
(223, 'TZ', 'TZA', 'TZ', '834', '256/tz.webp', '120/tz.webp', NULL, 255, 'TSh', 'TZS', 'AF', 'sw-TZ,en,ar', 'tz', 'Africa/Dar_es_Salaam', '945087', 0, NULL),
(224, 'TH', 'THA', 'TH', '764', '256/th.webp', '120/th.webp', NULL, 66, '฿', 'THB', 'AS', 'th,en', 'th', 'Asia/Bangkok', '514000', 1, NULL),
(225, 'TL', 'TLS', 'TT', '626', '256/tl.webp', '120/tl.webp', NULL, 670, '$', 'USD', 'AS', 'tet,pt-TL,id,en', 'tl', 'Asia/Dili', '15007', 0, NULL),
(226, 'TG', 'TGO', 'TO', '768', '256/tg.webp', '120/tg.webp', NULL, 228, 'CFA', 'XOF', 'AF', 'fr-TG,ee,hna,kbp,dag,ha', 'tg', 'Africa/Lome', '56785', 0, NULL),
(227, 'TK', 'TKL', 'TL', '772', '256/tk.webp', '120/tk.webp', NULL, 690, '$', 'NZD', 'OC', 'tkl,en-TK', 'tk', 'Pacific/Fakaofo', '10', 0, NULL),
(228, 'TO', 'TON', 'TN', '776', '256/to.webp', '120/to.webp', NULL, 676, '$', 'TOP', 'OC', 'to,en-TO', 'to', 'Pacific/Tongatapu', '748', 0, NULL),
(229, 'TT', 'TTO', 'TD', '780', '256/tt.webp', '120/tt.webp', NULL, 1868, '$', 'TTD', 'NA', 'en-TT,hns,fr,es,zh', 'tt', 'America/Port_of_Spain', '5128', 0, NULL),
(230, 'TN', 'TUN', 'TS', '788', '256/tn.webp', '120/tn.webp', NULL, 216, 'ت.د', 'TND', 'AF', 'ar-TN,fr', 'tn', 'Africa/Tunis', '163610', 1, NULL),
(231, 'TR', 'TUR', 'TU', '792', '256/tr.webp', '120/tr.webp', NULL, 90, '₺', 'TRY', 'AS', 'tr-TR,ku,diq,az,av', 'tr', 'Europe/Istanbul', '780580', 0, NULL),
(232, 'TM', 'TKM', 'TX', '795', '256/tm.webp', '120/tm.webp', NULL, 7370, 'T', 'TMT', 'AS', 'tk,ru,uz', 'tm', 'Asia/Ashgabat', '488100', 0, NULL),
(233, 'TC', 'TCA', 'TK', '796', '256/tc.webp', '120/tc.webp', NULL, 1649, '$', 'USD', 'NA', 'en-TC', 'tc', 'America/Grand_Turk', '430', 0, NULL),
(234, 'TV', 'TUV', 'TV', '798', '256/tv.webp', '120/tv.webp', NULL, 688, '$', 'AUD', 'OC', 'tvl,en,sm,gil', 'tv', 'Pacific/Funafuti', '26', 0, NULL),
(235, 'UG', 'UGA', 'UG', '800', '256/ug.webp', '120/ug.webp', NULL, 256, 'USh', 'UGX', 'AF', 'en-UG,lg,sw,ar', 'ug', 'Africa/Kampala', '236040', 0, NULL),
(236, 'UA', 'UKR', 'UP', '804', '256/ua.webp', '120/ua.webp', NULL, 380, '₴', 'UAH', 'EU', 'uk,ru-UA,rom,pl,hu', 'ua', 'Europe/Kiev', '603700', 1, NULL),
(237, 'AE', 'ARE', 'AE', '784', '256/ae.webp', '120/ae.webp', NULL, 971, 'إ.د', 'AED', 'AS', 'ar-AE,fa,en,hi,ur', 'ae', 'Asia/Dubai', '82880', 1, NULL),
(238, 'GB', 'GBR', 'UK', '826', '256/gb.webp', '120/gb.webp', NULL, 44, '£', 'GBP', 'EU', 'en-GB,cy-GB,gd', 'uk', 'Europe/London', '244820', 1, NULL),
(239, 'US', 'USA', 'US', '840', '256/us.webp', '120/us.webp', NULL, 1, '$', 'USD', 'NA', 'en-US,es-US,haw,fr', 'us', 'America/New_York', '9629091', 1, NULL),
(240, 'UM', NULL, NULL, NULL, '256/um.webp', '120/um.webp', NULL, 1, '$', 'USD', 'NA', NULL, NULL, NULL, NULL, 0, NULL),
(241, 'UY', 'URY', 'UY', '858', '256/uy.webp', '120/uy.webp', NULL, 598, '$', 'UYU', 'SA', 'es-UY', 'uy', 'America/Montevideo', '176220', 0, NULL),
(242, 'UZ', 'UZB', 'UZ', '860', '256/uz.webp', '120/uz.webp', NULL, 998, 'лв', 'UZS', 'AS', 'uz,ru,tg', 'uz', 'Asia/Tashkent', '447400', 0, NULL),
(243, 'VU', 'VUT', 'NH', '548', '256/vu.webp', '120/vu.webp', NULL, 678, 'VT', 'VUV', 'OC', 'bi,en-VU,fr-VU', 'vu', 'Pacific/Efate', '12200', 0, NULL),
(244, 'VE', 'VEN', 'VE', '862', '256/ve.webp', '120/ve.webp', NULL, 58, 'Bs', 'VEF', 'SA', 'es-VE', 've', 'America/Caracas', '912050', 0, NULL),
(245, 'VN', 'VNM', 'VM', '704', '256/vn.webp', '120/vn.webp', NULL, 84, '₫', 'VND', 'AS', 'vi,en,fr,zh,km', 'vn', 'Asia/Ho_Chi_Minh', '329560', 0, NULL),
(246, 'VG', 'VGB', 'VI', '92', '256/vg.webp', '120/vg.webp', NULL, 1284, '$', 'USD', 'NA', 'en-VG', 'vg', 'America/Tortola', '153', 0, NULL),
(247, 'VI', 'VIR', 'VQ', '850', '256/vi.webp', '120/vi.webp', NULL, 1340, '$', 'USD', 'NA', 'en-VI', 'vi', 'America/St_Thomas', '352', 0, NULL),
(248, 'WF', 'WLF', 'WF', '876', '256/wf.webp', '120/wf.webp', NULL, 681, '₣', 'XPF', 'OC', 'wls,fud,fr-WF', 'wf', 'Pacific/Wallis', '274', 0, NULL),
(249, 'EH', 'ESH', 'WI', '732', '256/eh.webp', '120/eh.webp', NULL, 212, 'MAD', 'MAD', 'AF', 'ar,mey', 'eh', 'Africa/El_Aaiun', '266000', 0, NULL),
(250, 'YE', 'YEM', 'YM', '887', '256/ye.webp', '120/ye.webp', NULL, 967, '﷼', 'YER', 'AS', 'ar-YE', 'ye', 'Asia/Aden', '527970', 1, NULL),
(251, 'ZM', 'ZMB', 'ZA', '894', '256/zm.webp', '120/zm.webp', NULL, 260, 'ZK', 'ZMW', 'AF', 'en-ZM,bem,loz,lun,lue,ny,toi', 'zm', 'Africa/Lusaka', '752614', 0, NULL),
(252, 'ZW', 'ZWE', 'ZI', '716', '256/zw.webp', '120/zw.webp', NULL, 263, '$', 'ZWL', 'AF', 'en-ZW,sn,nr,nd', 'zw', 'Africa/Harare', '390580', 0, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `data_country_translations`
--

CREATE TABLE `data_country_translations` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `country_id` bigint(20) UNSIGNED NOT NULL,
  `locale` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `capital` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `currency` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `continent` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `nationality` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `data_country_translations`
--

INSERT INTO `data_country_translations` (`id`, `country_id`, `locale`, `name`, `capital`, `currency`, `continent`, `nationality`) VALUES
(1, 1, 'ar', 'أفغانستان', 'Kabul', 'Afghani', 'آسيا', 'أفغانستاني'),
(2, 1, 'en', 'Afghanistan', 'Kabul', 'Afghani', 'Asia', 'Afghan'),
(3, 2, 'ar', 'جزر آلاند', 'Mariehamn', NULL, 'أوروبا', 'آلاندي'),
(4, 2, 'en', 'Aland Islands', 'Mariehamn', NULL, 'Europe', 'Aland Islander'),
(5, 3, 'ar', 'ألبانيا', 'Tirana', 'ليك', 'أوروبا', 'ألباني'),
(6, 3, 'en', 'Albania', 'Tirana', 'Lek', 'Europe', 'Albanian'),
(7, 4, 'ar', 'الجزائر', 'Algiers', 'دينار', 'أفريقيا', 'جزائري'),
(8, 4, 'en', 'Algeria', 'Algiers', 'Dinar', 'Africa', 'Algerian'),
(9, 5, 'ar', 'ساموا الأمريكية', 'Pago Pago', 'دولار', 'استراليا', 'أمريكي سامواني'),
(10, 5, 'en', 'American Samoa', 'Pago Pago', 'Dollar', 'Oceania', 'American Samoan'),
(11, 6, 'ar', 'أندورا', 'Andorra la Vella', 'اليورو', 'أوروبا', 'أندوري'),
(12, 6, 'en', 'Andorra', 'Andorra la Vella', 'Euro', 'Europe', 'Andorran'),
(13, 7, 'ar', 'أنغولا', 'Luanda', 'Kwanza', 'أفريقيا', 'أنقولي'),
(14, 7, 'en', 'Angola', 'Luanda', 'Kwanza', 'Africa', 'Angolan'),
(15, 8, 'ar', 'أنغيلا', 'The Valley', 'دولار', 'أمريكا الشمالية', 'أنغويلي'),
(16, 8, 'en', 'Anguilla', 'The Valley', 'Dollar', 'North America', 'Anguillan'),
(17, 9, 'ar', 'أنتاركتيكا', 'Antarctica', '', 'القارة القطبية الجنوبية', 'أنتاركتيكي'),
(18, 9, 'en', 'Antarctica', 'Antarctica', '', 'Antarctica', 'Antarctican'),
(19, 10, 'ar', 'أنتيغوا وبربودا', 'St. John\'s', 'دولار', 'أمريكا الشمالية', 'بربودي'),
(20, 10, 'en', 'Antigua and Barbuda', 'St. John\'s', 'Dollar', 'North America', 'Antiguan'),
(21, 11, 'ar', 'الأرجنتين', 'Buenos Aires', 'Peso', 'أمريكا الجنوبية', 'أرجنتيني'),
(22, 11, 'en', 'Argentina', 'Buenos Aires', 'Peso', 'South America', 'Argentinian'),
(23, 12, 'ar', 'أرمينيا', 'Yerevan', 'Dram', 'آسيا', 'أرميني'),
(24, 12, 'en', 'Armenia', 'Yerevan', 'Dram', 'Asia', 'Armenian'),
(25, 13, 'ar', 'أروبا', 'Oranjestad', 'Guilder', 'أمريكا الشمالية', 'أوروبهيني'),
(26, 13, 'en', 'Aruba', 'Oranjestad', 'Guilder', 'North America', 'Aruban'),
(27, 14, 'ar', 'أستراليا', 'Canberra', 'دولار', 'استراليا', 'أسترالي'),
(28, 14, 'en', 'Australia', 'Canberra', 'Dollar', 'Oceania', 'Australian'),
(29, 15, 'ar', 'النمسا', 'Vienna', 'اليورو', 'أوروبا', 'نمساوي'),
(30, 15, 'en', 'Austria', 'Vienna', 'Euro', 'Europe', 'Austrian'),
(31, 16, 'ar', 'أذربيجان', 'Baku', 'Manat', 'آسيا', 'أذربيجاني'),
(32, 16, 'en', 'Azerbaijan', 'Baku', 'Manat', 'Asia', 'Azerbaijani'),
(33, 17, 'ar', 'جزر البهاما', 'Nassau', 'دولار', 'أمريكا الشمالية', 'باهاميسي'),
(34, 17, 'en', 'Bahamas', 'Nassau', 'Dollar', 'North America', 'Bahamian'),
(35, 18, 'ar', 'البحرين', 'Manama', 'دينار', 'آسيا', 'بحريني'),
(36, 18, 'en', 'Bahrain', 'Manama', 'Dinar', 'Asia', 'Bahraini'),
(37, 19, 'ar', 'بنغلاديش', 'Dhaka', 'Taka', 'آسيا', 'بنغلاديشي'),
(38, 19, 'en', 'Bangladesh', 'Dhaka', 'Taka', 'Asia', 'Bangladeshi'),
(39, 20, 'ar', 'بربادوس', 'Bridgetown', 'دولار', 'أمريكا الشمالية', 'بربادوسي'),
(40, 20, 'en', 'Barbados', 'Bridgetown', 'Dollar', 'North America', 'Barbadian'),
(41, 21, 'ar', 'بيلاروسيا', 'Minsk', 'Ruble', 'أوروبا', 'روسي'),
(42, 21, 'en', 'Belarus', 'Minsk', 'Ruble', 'Europe', 'Belarusian'),
(43, 22, 'ar', 'بلجيكا', 'Brussels', 'اليورو', 'أوروبا', 'بلجيكي'),
(44, 22, 'en', 'Belgium', 'Brussels', 'Euro', 'Europe', 'Belgian'),
(45, 23, 'ar', 'بليز', 'Belmopan', 'دولار', 'أمريكا الشمالية', 'بيليزي'),
(46, 23, 'en', 'Belize', 'Belmopan', 'Dollar', 'North America', 'Belizean'),
(47, 24, 'ar', 'بنين', 'Porto-Novo', 'فرنك', 'أفريقيا', 'بنيني'),
(48, 24, 'en', 'Benin', 'Porto-Novo', 'Franc', 'Africa', 'Beninese'),
(49, 25, 'ar', 'برمودا', 'Hamilton', 'دولار', 'أمريكا الشمالية', 'برمودي'),
(50, 25, 'en', 'Bermuda', 'Hamilton', 'Dollar', 'North America', 'Bermudan'),
(51, 26, 'ar', 'بوتان', 'Thimphu', 'Ngultrum', 'آسيا', 'بوتاني'),
(52, 26, 'en', 'Bhutan', 'Thimphu', 'Ngultrum', 'Asia', 'Bhutanese'),
(53, 27, 'ar', 'بوليفيا', 'Sucre', 'Boliviano', 'أمريكا الجنوبية', 'بوليفي'),
(54, 27, 'en', 'Bolivia', 'Sucre', 'Boliviano', 'South America', 'Bolivian'),
(55, 28, 'ar', 'بونير وسانت يوستاتيوس وسابا', 'Kralendijk', NULL, 'أمريكا الشمالية', NULL),
(56, 28, 'en', 'بونير وسانت يوستاتيوس وسابا', 'Kralendijk', NULL, 'North America', NULL),
(57, 29, 'ar', 'البوسنة والهرسك', 'Sarajevo', 'Marka', 'أوروبا', 'بوسني/هرسكي'),
(58, 29, 'en', 'Bosnia and Herzegovina', 'Sarajevo', 'Marka', 'Europe', 'Bosnian / Herzegovinian'),
(59, 30, 'ar', 'بوتسوانا', 'Gaborone', 'Pula', 'أفريقيا', 'بوتسواني'),
(60, 30, 'en', 'Botswana', 'Gaborone', 'Pula', 'Africa', 'Botswanan'),
(61, 31, 'ar', 'جزيرة بوفيت', '', NULL, 'القارة القطبية الجنوبية', 'بوفيهي'),
(62, 31, 'en', 'Bouvet Island', '', NULL, 'Antarctica', 'Bouvetian'),
(63, 32, 'ar', 'البرازيل', 'Brasilia', 'Real', 'أمريكا الجنوبية', 'برازيلي'),
(64, 32, 'en', 'Brazil', 'Brasilia', 'Real', 'South America', 'Brazilian'),
(65, 33, 'ar', 'إقليم المحيط البريطاني الهندي', 'Diego Garcia', 'دولار', 'آسيا', 'إقليم المحيط الهندي البريطاني'),
(66, 33, 'en', 'British Indian Ocean Territory', 'Diego Garcia', 'Dollar', 'Asia', 'British Indian Ocean Territory'),
(67, 34, 'ar', 'بروناي دار السلام', 'Bandar Seri Begawan', 'دولار', 'آسيا', 'بروني'),
(68, 34, 'en', 'Brunei Darussalam', 'Bandar Seri Begawan', 'Dollar', 'Asia', 'Bruneian'),
(69, 35, 'ar', 'بلغاريا', 'Sofia', 'Lev', 'أوروبا', 'بلغاري'),
(70, 35, 'en', 'Bulgaria', 'Sofia', 'Lev', 'Europe', 'Bulgarian'),
(71, 36, 'ar', 'بوركينا فاسو', 'Ouagadougou', 'فرنك', 'أفريقيا', 'بوركيني'),
(72, 36, 'en', 'Burkina Faso', 'Ouagadougou', 'Franc', 'Africa', 'Burkinabe'),
(73, 37, 'ar', 'بوروندي', 'Bujumbura', 'فرنك', 'أفريقيا', 'بورونيدي'),
(74, 37, 'en', 'Burundi', 'Bujumbura', 'Franc', 'Africa', 'Burundian'),
(75, 38, 'ar', 'كمبوديا', 'Phnom Penh', 'Riels', 'آسيا', 'كمبودي'),
(76, 38, 'en', 'Cambodia', 'Phnom Penh', 'Riels', 'Asia', 'Cambodian'),
(77, 39, 'ar', 'الكاميرون', 'Yaounde', 'فرنك', 'أفريقيا', 'كاميروني'),
(78, 39, 'en', 'Cameroon', 'Yaounde', 'Franc', 'Africa', 'Cameroonian'),
(79, 40, 'ar', 'كندا', 'Ottawa', 'دولار', 'أمريكا الشمالية', 'كندي'),
(80, 40, 'en', 'Canada', 'Ottawa', 'Dollar', 'North America', 'Canadian'),
(81, 41, 'ar', 'الرأس الأخضر', 'Praia', 'Escudo', 'أفريقيا', 'الرأس الأخضر'),
(82, 41, 'en', 'Cape Verde', 'Praia', 'Escudo', 'Africa', 'Cape Verdean'),
(83, 42, 'ar', 'جزر كايمان', 'George Town', 'دولار', 'أمريكا الشمالية', 'كايماني'),
(84, 42, 'en', 'Cayman Islands', 'George Town', 'Dollar', 'North America', 'Caymanian'),
(85, 43, 'ar', 'جمهورية افريقيا الوسطى', 'Bangui', 'فرنك', 'أفريقيا', 'أفريقي'),
(86, 43, 'en', 'Central African Republic', 'Bangui', 'Franc', 'Africa', 'Central African'),
(87, 44, 'ar', 'تشاد', 'N\'Djamena', 'فرنك', 'أفريقيا', 'تشادي'),
(88, 44, 'en', 'Chad', 'N\'Djamena', 'Franc', 'Africa', 'Chadian'),
(89, 45, 'ar', 'تشيلي', 'Santiago', 'Peso', 'أمريكا الجنوبية', 'شيلي'),
(90, 45, 'en', 'Chile', 'Santiago', 'Peso', 'South America', 'Chilean'),
(91, 46, 'ar', 'الصين', 'Beijing', 'Yuan Renminbi', 'آسيا', 'صيني'),
(92, 46, 'en', 'China', 'Beijing', 'Yuan Renminbi', 'Asia', 'Chinese'),
(93, 47, 'ar', 'جزيرة الكريسماس', 'Flying Fish Cove', 'دولار', 'آسيا', 'جزيرة عيد الميلاد'),
(94, 47, 'en', 'Christmas Island', 'Flying Fish Cove', 'Dollar', 'Asia', 'Christmas Islander'),
(95, 48, 'ar', 'جزر كوكوس (كيلينغ)', 'West Island', 'دولار', 'آسيا', 'جزر كوكوس'),
(96, 48, 'en', 'Cocos (Keeling) Islands', 'West Island', 'Dollar', 'Asia', 'Cocos Islander'),
(97, 49, 'ar', 'كولومبيا', 'Bogota', 'Peso', 'أمريكا الجنوبية', 'كولومبي'),
(98, 49, 'en', 'Colombia', 'Bogota', 'Peso', 'South America', 'Colombian'),
(99, 50, 'ar', 'جزر القمر', 'Moroni', 'فرنك', 'أفريقيا', 'جزر القمر'),
(100, 50, 'en', 'Comoros', 'Moroni', 'Franc', 'Africa', 'Comorian'),
(101, 51, 'ar', 'الكونغو', 'Brazzaville', 'فرنك', 'أفريقيا', 'كونغي'),
(102, 51, 'en', 'Congo', 'Brazzaville', 'Franc', 'Africa', 'Congolese'),
(103, 52, 'ar', 'الكونغو ، جمهورية الكونغو الديمقراطية', 'Kinshasa', 'فرنك', 'أفريقيا', NULL),
(104, 52, 'en', 'الكونغو ، جمهورية الكونغو الديمقراطية', 'Kinshasa', 'Franc', 'Africa', NULL),
(105, 53, 'ar', 'جزر كوك', 'Avarua', 'دولار', 'استراليا', 'جزر كوك'),
(106, 53, 'en', 'Cook Islands', 'Avarua', 'Dollar', 'Oceania', 'Cook Islander'),
(107, 54, 'ar', 'كوستا ريكا', 'San Jose', 'Colon', 'أمريكا الشمالية', 'كوستاريكي'),
(108, 54, 'en', 'Costa Rica', 'San Jose', 'Colon', 'North America', 'Costa Rican'),
(109, 55, 'ar', 'ساحل العاج', 'Yamoussoukro', 'فرنك', 'أفريقيا', 'ساحل العاج'),
(110, 55, 'en', 'Ivory Coast', 'Yamoussoukro', 'Franc', 'Africa', 'Ivory Coastian'),
(111, 56, 'ar', 'كرواتيا', 'Zagreb', 'Kuna', 'أوروبا', 'كوراتي'),
(112, 56, 'en', 'Croatia', 'Zagreb', 'Kuna', 'Europe', 'Croatian'),
(113, 57, 'ar', 'كوبا', 'Havana', 'Peso', 'أمريكا الشمالية', 'كوبي'),
(114, 57, 'en', 'Cuba', 'Havana', 'Peso', 'North America', 'Cuban'),
(115, 58, 'ar', 'كوراكاو', 'Willemstad', 'Guilder', 'أمريكا الشمالية', 'كوراساوي'),
(116, 58, 'en', 'Curaçao', 'Willemstad', 'Guilder', 'North America', 'Curacian'),
(117, 59, 'ar', 'قبرص', 'Nicosia', 'اليورو', 'آسيا', 'قبرصي'),
(118, 59, 'en', 'Cyprus', 'Nicosia', 'Euro', 'Asia', 'Cypriot'),
(119, 60, 'ar', 'الجمهورية التشيكية', 'Prague', 'Koruna', 'أوروبا', 'تشيكي'),
(120, 60, 'en', 'Czech Republic', 'Prague', 'Koruna', 'Europe', 'Czech'),
(121, 61, 'ar', 'الدنمارك', 'Copenhagen', 'Krone', 'أوروبا', 'دنماركي'),
(122, 61, 'en', 'Denmark', 'Copenhagen', 'Krone', 'Europe', 'Danish'),
(123, 62, 'ar', 'جيبوتي', 'Djibouti', 'فرنك', 'أفريقيا', 'جيبوتي'),
(124, 62, 'en', 'Djibouti', 'Djibouti', 'Franc', 'Africa', 'Djiboutian'),
(125, 63, 'ar', 'دومينيكا', 'Roseau', 'دولار', 'أمريكا الشمالية', 'دومينيكي'),
(126, 63, 'en', 'Dominica', 'Roseau', 'Dollar', 'North America', 'Dominican'),
(127, 64, 'ar', 'جمهورية الدومنيكان', 'Santo Domingo', 'Peso', 'أمريكا الشمالية', 'دومينيكي'),
(128, 64, 'en', 'Dominican Republic', 'Santo Domingo', 'Peso', 'North America', 'Dominican'),
(129, 65, 'ar', 'الاكوادور', 'Quito', 'دولار', 'أمريكا الجنوبية', 'إكوادوري'),
(130, 65, 'en', 'Ecuador', 'Quito', 'Dollar', 'South America', 'Ecuadorian'),
(131, 66, 'ar', 'مصر', 'القاهرة', 'جنيه', 'أفريقيا', 'مصري'),
(132, 66, 'en', 'Egypt', 'Cairo', 'Pound', 'Africa', 'Egyptian'),
(133, 67, 'ar', 'السلفادور', 'San Salvador', 'دولار', 'أمريكا الشمالية', 'سلفادوري'),
(134, 67, 'en', 'El Salvador', 'San Salvador', 'Dollar', 'North America', 'Salvadoran'),
(135, 68, 'ar', 'غينيا الإستوائية', 'Malabo', 'فرنك', 'أفريقيا', 'غيني'),
(136, 68, 'en', 'Equatorial Guinea', 'Malabo', 'Franc', 'Africa', 'Equatorial Guinean'),
(137, 69, 'ar', 'إريتريا', 'Asmara', 'Nakfa', 'أفريقيا', 'إريتيري'),
(138, 69, 'en', 'Eritrea', 'Asmara', 'Nakfa', 'Africa', 'Eritrean'),
(139, 70, 'ar', 'إستونيا', 'Tallinn', 'اليورو', 'أوروبا', 'استوني'),
(140, 70, 'en', 'Estonia', 'Tallinn', 'Euro', 'Europe', 'Estonian'),
(141, 71, 'ar', 'أثيوبيا', 'Addis Ababa', 'Birr', 'أفريقيا', 'أثيوبي'),
(142, 71, 'en', 'Ethiopia', 'Addis Ababa', 'Birr', 'Africa', 'Ethiopian'),
(143, 72, 'ar', 'جزر فوكلاند (مالفيناس)', 'Stanley', 'جنيه', 'أمريكا الجنوبية', 'فوكلاندي'),
(144, 72, 'en', 'Falkland Islands (Malvinas)', 'Stanley', 'Pound', 'South America', 'Falkland Islander'),
(145, 73, 'ar', 'جزر فاروس', 'Torshavn', 'Krone', 'أوروبا', 'جزر فارو'),
(146, 73, 'en', 'Faroe Islands', 'Torshavn', 'Krone', 'Europe', 'Faroese'),
(147, 74, 'ar', 'فيجي', 'Suva', 'دولار', 'استراليا', 'فيجي'),
(148, 74, 'en', 'Fiji', 'Suva', 'Dollar', 'Oceania', 'Fijian'),
(149, 75, 'ar', 'فنلندا', 'Helsinki', 'اليورو', 'أوروبا', 'فنلندي'),
(150, 75, 'en', 'Finland', 'Helsinki', 'Euro', 'Europe', 'Finnish'),
(151, 76, 'ar', 'فرنسا', 'Paris', 'اليورو', 'أوروبا', 'فرنسي'),
(152, 76, 'en', 'France', 'Paris', 'Euro', 'Europe', 'French'),
(153, 77, 'ar', 'غيانا الفرنسية', 'Cayenne', NULL, 'أمريكا الجنوبية', 'غويانا الفرنسية'),
(154, 77, 'en', 'French Guiana', 'Cayenne', NULL, 'South America', 'French Guianese'),
(155, 78, 'ar', 'بولينيزيا الفرنسية', 'Papeete', 'فرنك', 'استراليا', 'بولينيزيي'),
(156, 78, 'en', 'French Polynesia', 'Papeete', 'Franc', 'Oceania', 'French Polynesian'),
(157, 79, 'ar', 'المناطق الجنوبية لفرنسا', 'Port-aux-Francais', NULL, 'القارة القطبية الجنوبية', 'أراض فرنسية جنوبية وأنتارتيكية'),
(158, 79, 'en', 'French Southern and Antarctic Lands', 'Port-aux-Francais', NULL, 'Antarctica', 'French'),
(159, 80, 'ar', 'الجابون', 'Libreville', 'فرنك', 'أفريقيا', 'غابوني'),
(160, 80, 'en', 'Gabon', 'Libreville', 'Franc', 'Africa', 'Gabonese'),
(161, 81, 'ar', 'غامبيا', 'Banjul', 'Dalasi', 'أفريقيا', 'غامبي'),
(162, 81, 'en', 'Gambia', 'Banjul', 'Dalasi', 'Africa', 'Gambian'),
(163, 82, 'ar', 'جورجيا', 'Tbilisi', 'Lari', 'آسيا', 'جيورجي'),
(164, 82, 'en', 'Georgia', 'Tbilisi', 'Lari', 'Asia', 'Georgian'),
(165, 83, 'ar', 'ألمانيا', 'Berlin', 'اليورو', 'أوروبا', 'ألماني'),
(166, 83, 'en', 'Germany', 'Berlin', 'Euro', 'Europe', 'German'),
(167, 84, 'ar', 'غانا', 'Accra', 'Cedi', 'أفريقيا', 'غاني'),
(168, 84, 'en', 'Ghana', 'Accra', 'Cedi', 'Africa', 'Ghanaian'),
(169, 85, 'ar', 'جبل طارق', 'Gibraltar', 'جنيه', 'أوروبا', 'جبل طارق'),
(170, 85, 'en', 'Gibraltar', 'Gibraltar', 'Pound', 'Europe', 'Gibraltar'),
(171, 86, 'ar', 'اليونان', 'Athens', 'اليورو', 'أوروبا', 'يوناني'),
(172, 86, 'en', 'Greece', 'Athens', 'Euro', 'Europe', 'Greek'),
(173, 87, 'ar', 'الأرض الخضراء', 'Nuuk', 'Krone', 'أمريكا الشمالية', 'جرينلاندي'),
(174, 87, 'en', 'Greenland', 'Nuuk', 'Krone', 'North America', 'Greenlandic'),
(175, 88, 'ar', 'غرينادا', 'St. George\'s', 'دولار', 'أمريكا الشمالية', 'غرينادي'),
(176, 88, 'en', 'Grenada', 'St. George\'s', 'Dollar', 'North America', 'Grenadian'),
(177, 89, 'ar', 'جوادلوب', 'Basse-Terre', NULL, 'أمريكا الشمالية', 'جزر جوادلوب'),
(178, 89, 'en', 'Guadeloupe', 'Basse-Terre', NULL, 'North America', 'Guadeloupe'),
(179, 90, 'ar', 'غوام', 'Hagatna', 'دولار', 'استراليا', 'جوامي'),
(180, 90, 'en', 'Guam', 'Hagatna', 'Dollar', 'Oceania', 'Guamanian'),
(181, 91, 'ar', 'غواتيمالا', 'Guatemala City', 'Quetzal', 'أمريكا الشمالية', 'غواتيمالي'),
(182, 91, 'en', 'Guatemala', 'Guatemala City', 'Quetzal', 'North America', 'Guatemalan'),
(183, 92, 'ar', 'غيرنسي', 'St Peter Port', 'جنيه', 'أوروبا', 'غيرنزي'),
(184, 92, 'en', 'Guernsey', 'St Peter Port', 'Pound', 'Europe', 'Guernsian'),
(185, 93, 'ar', 'غينيا', 'Conakry', 'فرنك', 'أفريقيا', 'غيني'),
(186, 93, 'en', 'Guinea', 'Conakry', 'Franc', 'Africa', 'Guinean'),
(187, 94, 'ar', 'غينيا بيساو', 'Bissau', 'فرنك', 'أفريقيا', 'غيني'),
(188, 94, 'en', 'Guinea-Bissau', 'Bissau', 'Franc', 'Africa', 'Guinea-Bissauan'),
(189, 95, 'ar', 'غيانا', 'Georgetown', 'دولار', 'أمريكا الجنوبية', 'غياني'),
(190, 95, 'en', 'Guyana', 'Georgetown', 'Dollar', 'South America', 'Guyanese'),
(191, 96, 'ar', 'هايتي', 'Port-au-Prince', 'Gourde', 'أمريكا الشمالية', 'هايتي'),
(192, 96, 'en', 'Haiti', 'Port-au-Prince', 'Gourde', 'North America', 'Haitian'),
(193, 97, 'ar', 'قلب الجزيرة وجزر ماكدونالز', '', NULL, 'القارة القطبية الجنوبية', 'جزيرة هيرد وجزر ماكدونالد'),
(194, 97, 'en', 'Heard and Mc Donald Islands', '', NULL, 'Antarctica', 'Heard and Mc Donald Islanders'),
(195, 98, 'ar', 'الكرسي الرسولي (دولة الفاتيكان)', 'Vatican City', 'اليورو', 'أوروبا', 'فاتيكاني'),
(196, 98, 'en', 'Vatican City', 'Vatican City', 'Euro', 'Europe', 'Vatican'),
(197, 99, 'ar', 'هندوراس', 'Tegucigalpa', 'Lempira', 'أمريكا الشمالية', 'هندوراسي'),
(198, 99, 'en', 'Honduras', 'Tegucigalpa', 'Lempira', 'North America', 'Honduran'),
(199, 100, 'ar', 'هونج كونج', 'Hong Kong', 'دولار', 'آسيا', 'هونغ كونغي'),
(200, 100, 'en', 'Hong Kong', 'Hong Kong', 'Dollar', 'Asia', 'Hongkongese'),
(201, 101, 'ar', 'هنغاريا', 'Budapest', 'Forint', 'أوروبا', 'مجري'),
(202, 101, 'en', 'Hungary', 'Budapest', 'Forint', 'Europe', 'Hungarian'),
(203, 102, 'ar', 'أيسلندا', 'Reykjavik', 'Krona', 'أوروبا', 'آيسلندي'),
(204, 102, 'en', 'Iceland', 'Reykjavik', 'Krona', 'Europe', 'Icelandic'),
(205, 103, 'ar', 'الهند', 'New Delhi', 'Rupee', 'آسيا', 'هندي'),
(206, 103, 'en', 'India', 'New Delhi', 'Rupee', 'Asia', 'Indian'),
(207, 104, 'ar', 'إندونيسيا', 'Jakarta', 'Rupiah', 'آسيا', 'أندونيسيي'),
(208, 104, 'en', 'Indonesia', 'Jakarta', 'Rupiah', 'Asia', 'Indonesian'),
(209, 105, 'ar', 'جمهورية إيران الإسلامية', 'Tehran', 'ريال', 'آسيا', 'إيراني'),
(210, 105, 'en', 'Iran', 'Tehran', 'Rial', 'Asia', 'Iranian'),
(211, 106, 'ar', 'العراق', 'Baghdad', 'دينار', 'آسيا', 'عراقي'),
(212, 106, 'en', 'Iraq', 'Baghdad', 'Dinar', 'Asia', 'Iraqi'),
(213, 107, 'ar', 'أيرلندا', 'Dublin', 'اليورو', 'أوروبا', 'إيرلندي'),
(214, 107, 'en', 'Ireland', 'Dublin', 'Euro', 'Europe', 'Irish'),
(215, 108, 'ar', 'جزيرة آيل أوف مان', 'Douglas, Isle of Man', 'جنيه', 'أوروبا', 'ماني'),
(216, 108, 'en', 'Isle of Man', 'Douglas, Isle of Man', 'Pound', 'Europe', 'Manx'),
(217, 109, 'ar', 'إسرائيل', 'Jerusalem', 'Shekel', 'آسيا', 'إسرائيلي'),
(218, 109, 'en', 'Israel', 'Jerusalem', 'Shekel', 'Asia', 'Israeli'),
(219, 110, 'ar', 'إيطاليا', 'Rome', 'اليورو', 'أوروبا', 'إيطالي'),
(220, 110, 'en', 'Italy', 'Rome', 'Euro', 'Europe', 'Italian'),
(221, 111, 'ar', 'جامايكا', 'Kingston', 'دولار', 'أمريكا الشمالية', 'جمايكي'),
(222, 111, 'en', 'Jamaica', 'Kingston', 'Dollar', 'North America', 'Jamaican'),
(223, 112, 'ar', 'اليابان', 'Tokyo', 'Yen', 'آسيا', 'ياباني'),
(224, 112, 'en', 'Japan', 'Tokyo', 'Yen', 'Asia', 'Japanese'),
(225, 113, 'ar', 'جيرسي', 'Saint Helier', 'جنيه', 'أوروبا', 'جيرزي'),
(226, 113, 'en', 'Jersey', 'Saint Helier', 'Pound', 'Europe', 'Jersian'),
(227, 114, 'ar', 'الأردن', 'Amman', 'دينار', 'آسيا', 'أردني'),
(228, 114, 'en', 'Jordan', 'Amman', 'Dinar', 'Asia', 'Jordanian'),
(229, 115, 'ar', 'كازاخستان', 'Astana', 'Tenge', 'آسيا', 'كازاخستاني'),
(230, 115, 'en', 'Kazakhstan', 'Astana', 'Tenge', 'Asia', 'Kazakh'),
(231, 116, 'ar', 'كينيا', 'Nairobi', 'Shilling', 'أفريقيا', 'كيني'),
(232, 116, 'en', 'Kenya', 'Nairobi', 'Shilling', 'Africa', 'Kenyan'),
(233, 117, 'ar', 'كيريباتي', 'Tarawa', 'دولار', 'استراليا', 'كيريباتي'),
(234, 117, 'en', 'Kiribati', 'Tarawa', 'Dollar', 'Oceania', 'I-Kiribati'),
(235, 118, 'ar', 'كوريا، الجمهورية الشعبية الديمقراطية', 'Pyongyang', 'Won', 'آسيا', 'كوري'),
(236, 118, 'en', 'Korea(North Korea)', 'Pyongyang', 'Won', 'Asia', 'North Korean'),
(237, 119, 'ar', 'جمهورية كوريا', 'Seoul', 'Won', 'آسيا', 'كوري'),
(238, 119, 'en', 'Korea(South Korea)', 'Seoul', 'Won', 'Asia', 'South Korean'),
(239, 120, 'ar', 'كوسوفو', 'Pristina', 'اليورو', 'أوروبا', 'كوسيفي'),
(240, 120, 'en', 'Kosovo', 'Pristina', 'Euro', 'Europe', 'Kosovar'),
(241, 121, 'ar', 'الكويت', 'Kuwait City', 'دينار', 'آسيا', 'كويتي'),
(242, 121, 'en', 'Kuwait', 'Kuwait City', 'Dinar', 'Asia', 'Kuwaiti'),
(243, 122, 'ar', 'قيرغيزستان', 'Bishkek', 'Som', 'آسيا', 'قيرغيزستاني'),
(244, 122, 'en', 'Kyrgyzstan', 'Bishkek', 'Som', 'Asia', 'Kyrgyzstani'),
(245, 123, 'ar', 'جمهورية لاو الديمقراطية الشعبية', 'Vientiane', 'Kip', 'آسيا', 'لاوسي'),
(246, 123, 'en', 'Lao PDR', 'Vientiane', 'Kip', 'Asia', 'Laotian'),
(247, 124, 'ar', 'لاتفيا', 'Riga', 'اليورو', 'أوروبا', 'لاتيفي'),
(248, 124, 'en', 'Latvia', 'Riga', 'Euro', 'Europe', 'Latvian'),
(249, 125, 'ar', 'لبنان', 'Beirut', 'جنيه', 'آسيا', 'لبناني'),
(250, 125, 'en', 'Lebanon', 'Beirut', 'Pound', 'Asia', 'Lebanese'),
(251, 126, 'ar', 'ليسوتو', 'Maseru', 'Loti', 'أفريقيا', 'ليوسيتي'),
(252, 126, 'en', 'Lesotho', 'Maseru', 'Loti', 'Africa', 'Basotho'),
(253, 127, 'ar', 'ليبيريا', 'Monrovia', 'دولار', 'أفريقيا', 'ليبيري'),
(254, 127, 'en', 'Liberia', 'Monrovia', 'Dollar', 'Africa', 'Liberian'),
(255, 128, 'ar', 'الجماهيرية العربية الليبية', 'Tripolis', 'دينار', 'أفريقيا', 'ليبي'),
(256, 128, 'en', 'Libya', 'Tripolis', 'Dinar', 'Africa', 'Libyan'),
(257, 129, 'ar', 'ليختنشتاين', 'Vaduz', 'فرنك', 'أوروبا', 'ليختنشتيني'),
(258, 129, 'en', 'Liechtenstein', 'Vaduz', 'Franc', 'Europe', 'Liechtenstein'),
(259, 130, 'ar', 'ليتوانيا', 'Vilnius', 'اليورو', 'أوروبا', 'لتوانيي'),
(260, 130, 'en', 'Lithuania', 'Vilnius', 'Euro', 'Europe', 'Lithuanian'),
(261, 131, 'ar', 'لوكسمبورغ', 'Luxembourg', 'اليورو', 'أوروبا', 'لوكسمبورغي'),
(262, 131, 'en', 'Luxembourg', 'Luxembourg', 'Euro', 'Europe', 'Luxembourger'),
(263, 132, 'ar', 'ماكاو', 'Macao', 'Pataca', 'آسيا', 'ماكاوي'),
(264, 132, 'en', 'Macau', 'Macao', 'Pataca', 'Asia', 'Macanese'),
(265, 133, 'ar', 'مقدونيا ، جمهورية يوغوسلافيا السابقة', 'Skopje', 'Denar', 'أوروبا', 'مقدوني'),
(266, 133, 'en', 'Macedonia', 'Skopje', 'Denar', 'Europe', 'Macedonian'),
(267, 134, 'ar', 'مدغشقر', 'Antananarivo', 'Ariary', 'أفريقيا', 'مدغشقري'),
(268, 134, 'en', 'Madagascar', 'Antananarivo', 'Ariary', 'Africa', 'Malagasy'),
(269, 135, 'ar', 'ملاوي', 'Lilongwe', 'Kwacha', 'أفريقيا', 'مالاوي'),
(270, 135, 'en', 'Malawi', 'Lilongwe', 'Kwacha', 'Africa', 'Malawian'),
(271, 136, 'ar', 'ماليزيا', 'Kuala Lumpur', 'Ringgit', 'آسيا', 'ماليزي'),
(272, 136, 'en', 'Malaysia', 'Kuala Lumpur', 'Ringgit', 'Asia', 'Malaysian'),
(273, 137, 'ar', 'جزر المالديف', 'Male', 'Rufiyaa', 'آسيا', 'مالديفي'),
(274, 137, 'en', 'Maldives', 'Male', 'Rufiyaa', 'Asia', 'Maldivian'),
(275, 138, 'ar', 'مالي', 'Bamako', 'فرنك', 'أفريقيا', 'مالي'),
(276, 138, 'en', 'Mali', 'Bamako', 'Franc', 'Africa', 'Malian'),
(277, 139, 'ar', 'مالطا', 'Valletta', 'اليورو', 'أوروبا', 'مالطي'),
(278, 139, 'en', 'Malta', 'Valletta', 'Euro', 'Europe', 'Maltese'),
(279, 140, 'ar', 'جزر مارشال', 'Majuro', 'دولار', 'استراليا', 'مارشالي'),
(280, 140, 'en', 'Marshall Islands', 'Majuro', 'Dollar', 'Oceania', 'Marshallese'),
(281, 141, 'ar', 'مارتينيك', 'Fort-de-France', NULL, 'أمريكا الشمالية', 'مارتينيكي'),
(282, 141, 'en', 'Martinique', 'Fort-de-France', NULL, 'North America', 'Martiniquais'),
(283, 142, 'ar', 'موريتانيا', 'Nouakchott', 'Ouguiya', 'أفريقيا', 'موريتانيي'),
(284, 142, 'en', 'Mauritania', 'Nouakchott', 'Ouguiya', 'Africa', 'Mauritanian'),
(285, 143, 'ar', 'موريشيوس', 'Port Louis', 'Rupee', 'أفريقيا', 'موريشيوسي'),
(286, 143, 'en', 'Mauritius', 'Port Louis', 'Rupee', 'Africa', 'Mauritian'),
(287, 144, 'ar', 'مايوت', 'Mamoudzou', 'اليورو', 'أفريقيا', 'مايوتي'),
(288, 144, 'en', 'Mayotte', 'Mamoudzou', 'Euro', 'Africa', 'Mahoran'),
(289, 145, 'ar', 'المكسيك', 'Mexico City', 'Peso', 'أمريكا الشمالية', 'مكسيكي'),
(290, 145, 'en', 'Mexico', 'Mexico City', 'Peso', 'North America', 'Mexican'),
(291, 146, 'ar', 'ولايات ميكرونيزيا الموحدة', 'Palikir', 'دولار', 'استراليا', 'مايكرونيزيي'),
(292, 146, 'en', 'Micronesia', 'Palikir', 'Dollar', 'Oceania', 'Micronesian'),
(293, 147, 'ar', 'جمهورية مولدوفا', 'Chisinau', 'Leu', 'أوروبا', 'مولديفي'),
(294, 147, 'en', 'Moldova', 'Chisinau', 'Leu', 'Europe', 'Moldovan'),
(295, 148, 'ar', 'موناكو', 'Monaco', 'اليورو', 'أوروبا', 'مونيكي'),
(296, 148, 'en', 'Monaco', 'Monaco', 'Euro', 'Europe', 'Monacan'),
(297, 149, 'ar', 'منغوليا', 'Ulan Bator', 'Tugrik', 'آسيا', 'منغولي'),
(298, 149, 'en', 'Mongolia', 'Ulan Bator', 'Tugrik', 'Asia', 'Mongolian'),
(299, 150, 'ar', 'الجبل الأسود', 'Podgorica', 'اليورو', 'أوروبا', 'الجبل الأسود'),
(300, 150, 'en', 'Montenegro', 'Podgorica', 'Euro', 'Europe', 'Montenegrin'),
(301, 151, 'ar', 'مونتسيرات', 'Plymouth', 'دولار', 'أمريكا الشمالية', 'مونتسيراتي'),
(302, 151, 'en', 'Montserrat', 'Plymouth', 'Dollar', 'North America', 'Montserratian'),
(303, 152, 'ar', 'المغرب', 'Rabat', 'Dirham', 'أفريقيا', 'مغربي'),
(304, 152, 'en', 'Morocco', 'Rabat', 'Dirham', 'Africa', 'Moroccan'),
(305, 153, 'ar', 'موزمبيق', 'Maputo', 'Metical', 'أفريقيا', 'موزمبيقي'),
(306, 153, 'en', 'Mozambique', 'Maputo', 'Metical', 'Africa', 'Mozambican'),
(307, 154, 'ar', 'ميانمار', 'Nay Pyi Taw', 'Kyat', 'آسيا', 'ميانماري'),
(308, 154, 'en', 'Myanmar', 'Nay Pyi Taw', 'Kyat', 'Asia', 'Myanmarian'),
(309, 155, 'ar', 'ناميبيا', 'Windhoek', 'دولار', 'أفريقيا', 'ناميبي'),
(310, 155, 'en', 'Namibia', 'Windhoek', 'Dollar', 'Africa', 'Namibian'),
(311, 156, 'ar', 'ناورو', 'Yaren', 'دولار', 'استراليا', 'نوري'),
(312, 156, 'en', 'Nauru', 'Yaren', 'Dollar', 'Oceania', 'Nauruan'),
(313, 157, 'ar', 'نيبال', 'Kathmandu', 'Rupee', 'آسيا', 'نيبالي'),
(314, 157, 'en', 'Nepal', 'Kathmandu', 'Rupee', 'Asia', 'Nepalese'),
(315, 158, 'ar', 'هولندا', 'Amsterdam', 'اليورو', 'أوروبا', 'هولندي'),
(316, 158, 'en', 'Netherlands', 'Amsterdam', 'Euro', 'Europe', 'Dutch'),
(317, 159, 'ar', 'جزر الأنتيل الهولندية', 'Willemstad', 'Guilder', 'أمريكا الشمالية', 'هولندي'),
(318, 159, 'en', 'Netherlands Antilles', 'Willemstad', 'Guilder', 'North America', 'Dutch Antilier'),
(319, 160, 'ar', 'كاليدونيا الجديدة', 'Noumea', 'فرنك', 'استراليا', 'كاليدوني'),
(320, 160, 'en', 'New Caledonia', 'Noumea', 'Franc', 'Oceania', 'New Caledonian'),
(321, 161, 'ar', 'نيوزيلاندا', 'Wellington', 'دولار', 'استراليا', 'نيوزيلندي'),
(322, 161, 'en', 'New Zealand', 'Wellington', 'Dollar', 'Oceania', 'New Zealander'),
(323, 162, 'ar', 'نيكاراغوا', 'Managua', 'Cordoba', 'أمريكا الشمالية', 'نيكاراجوي'),
(324, 162, 'en', 'Nicaragua', 'Managua', 'Cordoba', 'North America', 'Nicaraguan'),
(325, 163, 'ar', 'النيجر', 'Niamey', 'فرنك', 'أفريقيا', 'نيجيري'),
(326, 163, 'en', 'Niger', 'Niamey', 'Franc', 'Africa', 'Nigerien'),
(327, 164, 'ar', 'نيجيريا', 'Abuja', 'Naira', 'أفريقيا', 'نيجيري'),
(328, 164, 'en', 'Nigeria', 'Abuja', 'Naira', 'Africa', 'Nigerian'),
(329, 165, 'ar', 'نيوي', 'Alofi', 'دولار', 'استراليا', 'ني'),
(330, 165, 'en', 'Niue', 'Alofi', 'Dollar', 'Oceania', 'Niuean'),
(331, 166, 'ar', 'جزيرة نورفولك', 'Kingston', NULL, 'استراليا', 'نورفوليكي'),
(332, 166, 'en', 'Norfolk Island', 'Kingston', NULL, 'Oceania', 'Norfolk Islander'),
(333, 167, 'ar', 'جزر مريانا الشمالية', 'Saipan', 'دولار', 'استراليا', 'ماريني'),
(334, 167, 'en', 'Northern Mariana Islands', 'Saipan', 'Dollar', 'Oceania', 'Northern Marianan'),
(335, 168, 'ar', 'النرويج', 'Oslo', 'Krone', 'أوروبا', 'نرويجي'),
(336, 168, 'en', 'Norway', 'Oslo', 'Krone', 'Europe', 'Norwegian'),
(337, 169, 'ar', 'سلطنة عمان', 'Muscat', 'ريال', 'آسيا', 'عماني'),
(338, 169, 'en', 'Oman', 'Muscat', 'Rial', 'Asia', 'Omani'),
(339, 170, 'ar', 'باكستان', 'Islamabad', 'Rupee', 'آسيا', 'باكستاني'),
(340, 170, 'en', 'Pakistan', 'Islamabad', 'Rupee', 'Asia', 'Pakistani'),
(341, 171, 'ar', 'بالاو', 'Melekeok', 'دولار', 'استراليا', 'بالاوي'),
(342, 171, 'en', 'Palau', 'Melekeok', 'Dollar', 'Oceania', 'Palauan'),
(343, 172, 'ar', 'الأراضي الفلسطينية المحتلة', 'East Jerusalem', 'Shekel', 'آسيا', 'فلسطيني'),
(344, 172, 'en', 'Palestine', 'East Jerusalem', 'Shekel', 'Asia', 'Palestinian'),
(345, 173, 'ar', 'بنما', 'Panama City', 'Balboa', 'أمريكا الشمالية', 'بنمي'),
(346, 173, 'en', 'Panama', 'Panama City', 'Balboa', 'North America', 'Panamanian'),
(347, 174, 'ar', 'بابوا غينيا الجديدة', 'Port Moresby', 'Kina', 'استراليا', 'بابوي'),
(348, 174, 'en', 'Papua New Guinea', 'Port Moresby', 'Kina', 'Oceania', 'Papua New Guinean'),
(349, 175, 'ar', 'باراغواي', 'Asuncion', 'Guarani', 'أمريكا الجنوبية', 'بارغاوي'),
(350, 175, 'en', 'Paraguay', 'Asuncion', 'Guarani', 'South America', 'Paraguayan'),
(351, 176, 'ar', 'بيرو', 'Lima', 'Sol', 'أمريكا الجنوبية', 'بيري'),
(352, 176, 'en', 'Peru', 'Lima', 'Sol', 'South America', 'Peruvian'),
(353, 177, 'ar', 'فيلبيني', 'Manila', 'Peso', 'آسيا', 'فلبيني'),
(354, 177, 'en', 'Philippines', 'Manila', 'Peso', 'Asia', 'Filipino'),
(355, 178, 'ar', 'بيتكيرن', 'Adamstown', 'دولار', 'استراليا', 'بيتكيرني'),
(356, 178, 'en', 'Pitcairn', 'Adamstown', 'Dollar', 'Oceania', 'Pitcairn Islander'),
(357, 179, 'ar', 'بولندا', 'Warsaw', 'Zloty', 'أوروبا', 'بوليني'),
(358, 179, 'en', 'Poland', 'Warsaw', 'Zloty', 'Europe', 'Polish'),
(359, 180, 'ar', 'البرتغال', 'Lisbon', 'اليورو', 'أوروبا', 'برتغالي'),
(360, 180, 'en', 'Portugal', 'Lisbon', 'Euro', 'Europe', 'Portuguese'),
(361, 181, 'ar', 'بورتوريكو', 'San Juan', 'دولار', 'أمريكا الشمالية', 'بورتي'),
(362, 181, 'en', 'Puerto Rico', 'San Juan', 'Dollar', 'North America', 'Puerto Rican'),
(363, 182, 'ar', 'قطر', 'Doha', 'ريال', 'آسيا', 'قطري'),
(364, 182, 'en', 'Qatar', 'Doha', 'Rial', 'Asia', 'Qatari'),
(365, 183, 'ar', 'جمع شمل', 'Saint-Denis', 'اليورو', 'أفريقيا', 'ريونيوني'),
(366, 183, 'en', 'Reunion Island', 'Saint-Denis', 'Euro', 'Africa', 'Reunionese'),
(367, 184, 'ar', 'رومانيا', 'Bucharest', 'Leu', 'أوروبا', 'روماني'),
(368, 184, 'en', 'Romania', 'Bucharest', 'Leu', 'Europe', 'Romanian'),
(369, 185, 'ar', 'الاتحاد الروسي', 'Moscow', 'Ruble', 'آسيا', 'روسي'),
(370, 185, 'en', 'Russian', 'Moscow', 'Ruble', 'Asia', 'Russian'),
(371, 186, 'ar', 'رواندا', 'Kigali', 'فرنك', 'أفريقيا', 'رواندا'),
(372, 186, 'en', 'Rwanda', 'Kigali', 'Franc', 'Africa', 'Rwandan'),
(373, 187, 'ar', 'سانت بارتيليمي', 'Gustavia', 'اليورو', 'أمريكا الشمالية', 'سان بارتيلمي'),
(374, 187, 'en', 'Saint Barthelemy', 'Gustavia', 'Euro', 'North America', 'Saint Barthelmian'),
(375, 188, 'ar', 'سانت هيلانة', 'Jamestown', 'جنيه', 'أفريقيا', 'هيلاني'),
(376, 188, 'en', 'Saint Helena', 'Jamestown', 'Pound', 'Africa', 'St. Helenian'),
(377, 189, 'ar', 'سانت كيتس ونيفيس', 'Basseterre', 'دولار', 'أمريكا الشمالية', 'سانت كيتس ونيفس'),
(378, 189, 'en', 'Saint Kitts and Nevis', 'Basseterre', 'Dollar', 'North America', 'Kittitian/Nevisian'),
(379, 190, 'ar', 'القديسة لوسيا', 'Castries', 'دولار', 'أمريكا الشمالية', 'سان بيير وميكلوني'),
(380, 190, 'en', 'Saint Pierre and Miquelon', 'Castries', 'Dollar', 'North America', 'St. Pierre and Miquelon'),
(381, 191, 'ar', 'القديس مارتن', 'Marigot', 'اليورو', 'أمريكا الشمالية', 'ساينت مارتني فرنسي'),
(382, 191, 'en', 'Saint Martin (French part)', 'Marigot', 'Euro', 'North America', 'St. Martian(French)'),
(383, 192, 'ar', 'سانت بيير وميكلون', 'Saint-Pierre', 'اليورو', 'أمريكا الشمالية', NULL),
(384, 192, 'en', 'سانت بيير وميكلون', 'Saint-Pierre', 'Euro', 'North America', NULL),
(385, 193, 'ar', 'سانت فنسنت وجزر غرينادين', 'Kingstown', 'دولار', 'أمريكا الشمالية', 'سانت فنسنت وجزر غرينادين'),
(386, 193, 'en', 'Saint Vincent and the Grenadines', 'Kingstown', 'Dollar', 'North America', 'Saint Vincent and the Grenadines'),
(387, 194, 'ar', 'ساموا', 'Apia', 'Tala', 'استراليا', 'ساموي'),
(388, 194, 'en', 'Samoa', 'Apia', 'Tala', 'Oceania', 'Samoan'),
(389, 195, 'ar', 'سان مارينو', 'San Marino', 'اليورو', 'أوروبا', 'ماريني'),
(390, 195, 'en', 'San Marino', 'San Marino', 'Euro', 'Europe', 'Sammarinese'),
(391, 196, 'ar', 'ساو تومي وبرينسيبي', 'Sao Tome', 'Dobra', 'أفريقيا', 'ساو تومي وبرينسيبي'),
(392, 196, 'en', 'Sao Tome and Principe', 'Sao Tome', 'Dobra', 'Africa', 'Sao Tomean'),
(393, 197, 'ar', 'المملكة العربية السعودية', 'الرياض', 'ريال', 'آسيا', 'سعودي'),
(394, 197, 'en', 'Saudi Arabia', 'Riyadh', 'Rial', 'Asia', 'Saudi Arabian'),
(395, 198, 'ar', 'السنغال', 'Dakar', 'فرنك', 'أفريقيا', 'سنغالي'),
(396, 198, 'en', 'Senegal', 'Dakar', 'Franc', 'Africa', 'Senegalese'),
(397, 199, 'ar', 'صربيا', 'Belgrade', 'دينار', 'أوروبا', 'صربي'),
(398, 199, 'en', 'Serbia', 'Belgrade', 'Dinar', 'Europe', 'Serbian'),
(399, 200, 'ar', 'صربيا والجبل الأسود', 'Belgrade', NULL, 'أوروبا', NULL),
(400, 200, 'en', 'صربيا والجبل الأسود', 'Belgrade', NULL, 'Europe', NULL),
(401, 201, 'ar', 'سيشيل', 'Victoria', 'Rupee', 'أفريقيا', 'سيشيلي'),
(402, 201, 'en', 'Seychelles', 'Victoria', 'Rupee', 'Africa', 'Seychellois'),
(403, 202, 'ar', 'سيرا ليون', 'Freetown', 'Leone', 'أفريقيا', 'سيراليوني'),
(404, 202, 'en', 'Sierra Leone', 'Freetown', 'Leone', 'Africa', 'Sierra Leonean'),
(405, 203, 'ar', 'سنغافورة', 'Singapur', 'دولار', 'آسيا', 'سنغافوري'),
(406, 203, 'en', 'Singapore', 'Singapur', 'Dollar', 'Asia', 'Singaporean'),
(407, 204, 'ar', 'سينت مارتن', 'Philipsburg', 'Guilder', 'أمريكا الشمالية', 'ساينت مارتني هولندي'),
(408, 204, 'en', 'Sint Maarten (Dutch part)', 'Philipsburg', 'Guilder', 'North America', 'St. Martian(Dutch)'),
(409, 205, 'ar', 'سلوفاكيا', 'Bratislava', 'اليورو', 'أوروبا', 'سولفاكي'),
(410, 205, 'en', 'Slovakia', 'Bratislava', 'Euro', 'Europe', 'Slovak'),
(411, 206, 'ar', 'سلوفينيا', 'Ljubljana', 'اليورو', 'أوروبا', 'سولفيني'),
(412, 206, 'en', 'Slovenia', 'Ljubljana', 'Euro', 'Europe', 'Slovenian'),
(413, 207, 'ar', 'جزر سليمان', 'Honiara', 'دولار', 'استراليا', 'جزر سليمان'),
(414, 207, 'en', 'Solomon Islands', 'Honiara', 'Dollar', 'Oceania', 'Solomon Island'),
(415, 208, 'ar', 'الصومال', 'Mogadishu', 'Shilling', 'أفريقيا', 'صومالي'),
(416, 208, 'en', 'Somalia', 'Mogadishu', 'Shilling', 'Africa', 'Somali'),
(417, 209, 'ar', 'جنوب أفريقيا', 'Pretoria', 'Rand', 'أفريقيا', 'أفريقي'),
(418, 209, 'en', 'South Africa', 'Pretoria', 'Rand', 'Africa', 'South African'),
(419, 210, 'ar', 'جورجيا الجنوبية وجزر ساندويتش الجنوبية', 'Grytviken', NULL, 'القارة القطبية الجنوبية', 'لمنطقة القطبية الجنوبية'),
(420, 210, 'en', 'South Georgia and the South Sandwich', 'Grytviken', NULL, 'Antarctica', 'South Georgia and the South Sandwich'),
(421, 211, 'ar', 'جنوب السودان', 'Juba', 'جنيه', 'أفريقيا', 'سوادني جنوبي'),
(422, 211, 'en', 'South Sudan', 'Juba', 'Pound', 'Africa', 'South Sudanese'),
(423, 212, 'ar', 'إسبانيا', 'Madrid', 'اليورو', 'أوروبا', 'إسباني'),
(424, 212, 'en', 'Spain', 'Madrid', 'Euro', 'Europe', 'Spanish'),
(425, 213, 'ar', 'سيريلانكا', 'Colombo', 'Rupee', 'آسيا', 'سريلانكي'),
(426, 213, 'en', 'Sri Lanka', 'Colombo', 'Rupee', 'Asia', 'Sri Lankian'),
(427, 214, 'ar', 'السودان', 'Khartoum', 'جنيه', 'أفريقيا', 'سوداني'),
(428, 214, 'en', 'Sudan', 'Khartoum', 'Pound', 'Africa', 'Sudanese'),
(429, 215, 'ar', 'سورينام', 'Paramaribo', 'دولار', 'أمريكا الجنوبية', 'سورينامي'),
(430, 215, 'en', 'Suriname', 'Paramaribo', 'Dollar', 'South America', 'Surinamese'),
(431, 216, 'ar', 'سفالبارد وجان ماين', 'Longyearbyen', 'Krone', 'أوروبا', 'سفالبارد ويان ماين'),
(432, 216, 'en', 'Svalbard and Jan Mayen', 'Longyearbyen', 'Krone', 'Europe', 'Svalbardian/Jan Mayenian'),
(433, 217, 'ar', 'سوازيلاند', 'Mbabane', 'Lilangeni', 'أفريقيا', 'سوازيلندي'),
(434, 217, 'en', 'Swaziland', 'Mbabane', 'Lilangeni', 'Africa', 'Swazi'),
(435, 218, 'ar', 'السويد', 'Stockholm', 'Krona', 'أوروبا', 'سويدي'),
(436, 218, 'en', 'Sweden', 'Stockholm', 'Krona', 'Europe', 'Swedish'),
(437, 219, 'ar', 'سويسرا', 'Berne', 'فرنك', 'أوروبا', 'سويسري'),
(438, 219, 'en', 'Switzerland', 'Berne', 'Franc', 'Europe', 'Swiss'),
(439, 220, 'ar', 'الجمهورية العربية السورية', 'Damascus', 'جنيه', 'آسيا', 'سوري'),
(440, 220, 'en', 'Syria', 'Damascus', 'Pound', 'Asia', 'Syrian'),
(441, 221, 'ar', 'مقاطعة تايوان الصينية', 'Taipei', 'دولار', 'آسيا', 'تايواني'),
(442, 221, 'en', 'Taiwan', 'Taipei', 'Dollar', 'Asia', 'Taiwanese'),
(443, 222, 'ar', 'طاجيكستان', 'Dushanbe', 'Somoni', 'آسيا', 'طاجيكستاني'),
(444, 222, 'en', 'Tajikistan', 'Dushanbe', 'Somoni', 'Asia', 'Tajikistani'),
(445, 223, 'ar', 'جمهورية تنزانيا المتحدة', 'Dodoma', 'Shilling', 'أفريقيا', 'تنزانيي'),
(446, 223, 'en', 'Tanzania', 'Dodoma', 'Shilling', 'Africa', 'Tanzanian'),
(447, 224, 'ar', 'تايلاند', 'Bangkok', 'Baht', 'آسيا', 'تايلندي'),
(448, 224, 'en', 'Thailand', 'Bangkok', 'Baht', 'Asia', 'Thai'),
(449, 225, 'ar', 'تيمور ليشتي', 'Dili', 'دولار', 'آسيا', 'تيموري'),
(450, 225, 'en', 'Timor-Leste', 'Dili', 'Dollar', 'Asia', 'Timor-Lestian'),
(451, 226, 'ar', 'توجو', 'Lome', 'فرنك', 'أفريقيا', 'توغي'),
(452, 226, 'en', 'Togo', 'Lome', 'Franc', 'Africa', 'Togolese'),
(453, 227, 'ar', 'توكيلاو', '', 'دولار', 'استراليا', 'توكيلاوي'),
(454, 227, 'en', 'Tokelau', '', 'Dollar', 'Oceania', 'Tokelaian'),
(455, 228, 'ar', 'تونغا', 'Nuku\'alofa', 'Pa\'anga', 'استراليا', 'تونغي'),
(456, 228, 'en', 'Tonga', 'Nuku\'alofa', 'Pa\'anga', 'Oceania', 'Tongan'),
(457, 229, 'ar', 'ترينداد وتوباغو', 'Port of Spain', 'دولار', 'أمريكا الشمالية', 'ترينيداد وتوباغو'),
(458, 229, 'en', 'Trinidad and Tobago', 'Port of Spain', 'Dollar', 'North America', 'Trinidadian/Tobagonian'),
(459, 230, 'ar', 'تونس', 'Tunis', 'دينار', 'أفريقيا', 'تونسي'),
(460, 230, 'en', 'Tunisia', 'Tunis', 'Dinar', 'Africa', 'Tunisian'),
(461, 231, 'ar', 'ديك رومى', 'Ankara', 'Lira', 'آسيا', 'تركي'),
(462, 231, 'en', 'Turkey', 'Ankara', 'Lira', 'Asia', 'Turkish'),
(463, 232, 'ar', 'تركمانستان', 'Ashgabat', 'Manat', 'آسيا', 'تركمانستاني'),
(464, 232, 'en', 'Turkmenistan', 'Ashgabat', 'Manat', 'Asia', 'Turkmen'),
(465, 233, 'ar', 'جزر تركس وكايكوس', 'Cockburn Town', 'دولار', 'أمريكا الشمالية', 'جزر توركس وكايكوس'),
(466, 233, 'en', 'Turks and Caicos Islands', 'Cockburn Town', 'Dollar', 'North America', 'Turks and Caicos Islands'),
(467, 234, 'ar', 'توفالو', 'Funafuti', 'دولار', 'استراليا', 'توفالي'),
(468, 234, 'en', 'Tuvalu', 'Funafuti', 'Dollar', 'Oceania', 'Tuvaluan'),
(469, 235, 'ar', 'أوغندا', 'Kampala', 'Shilling', 'أفريقيا', 'أوغندي'),
(470, 235, 'en', 'Uganda', 'Kampala', 'Shilling', 'Africa', 'Ugandan'),
(471, 236, 'ar', 'أوكرانيا', 'Kiev', 'Hryvnia', 'أوروبا', 'أوكراني'),
(472, 236, 'en', 'Ukraine', 'Kiev', 'Hryvnia', 'Europe', 'Ukrainian'),
(473, 237, 'ar', 'الإمارات العربية المتحدة', 'Abu Dhabi', 'Dirham', 'آسيا', 'إماراتي'),
(474, 237, 'en', 'United Arab Emirates', 'Abu Dhabi', 'Dirham', 'Asia', 'Emirati'),
(475, 238, 'ar', 'المملكة المتحدة', 'London', 'جنيه', 'أوروبا', 'بريطاني'),
(476, 238, 'en', 'United Kingdom', 'London', 'Pound', 'Europe', 'British'),
(477, 239, 'ar', 'الولايات المتحدة', 'Washington', 'دولار', 'أمريكا الشمالية', 'أمريكي'),
(478, 239, 'en', 'United States', 'Washington', 'Dollar', 'North America', 'American'),
(479, 240, 'ar', 'جزر الولايات المتحدة البعيدة الصغرى', '', NULL, 'أمريكا الشمالية', 'أمريكي'),
(480, 240, 'en', 'US Minor Outlying Islands', '', NULL, 'North America', 'US Minor Outlying Islander'),
(481, 241, 'ar', 'أوروغواي', 'Montevideo', 'Peso', 'أمريكا الجنوبية', 'أورغواي'),
(482, 241, 'en', 'Uruguay', 'Montevideo', 'Peso', 'South America', 'Uruguayan'),
(483, 242, 'ar', 'أوزبكستان', 'Tashkent', 'Som', 'آسيا', 'أوزباكستاني'),
(484, 242, 'en', 'Uzbekistan', 'Tashkent', 'Som', 'Asia', 'Uzbek'),
(485, 243, 'ar', 'فانواتو', 'Port Vila', 'Vatu', 'استراليا', 'فانواتي'),
(486, 243, 'en', 'Vanuatu', 'Port Vila', 'Vatu', 'Oceania', 'Vanuatuan'),
(487, 244, 'ar', 'فنزويلا', 'Caracas', 'Bolivar', 'أمريكا الجنوبية', 'فنزويلي'),
(488, 244, 'en', 'Venezuela', 'Caracas', 'Bolivar', 'South America', 'Venezuelan'),
(489, 245, 'ar', 'فييت نام', 'Hanoi', 'Dong', 'آسيا', 'فيتنامي'),
(490, 245, 'en', 'Vietnam', 'Hanoi', 'Dong', 'Asia', 'Vietnamese'),
(491, 246, 'ar', 'جزر العذراء البريطانية', 'Road Town', 'دولار', 'أمريكا الشمالية', NULL),
(492, 246, 'en', 'جزر العذراء البريطانية', 'Road Town', 'Dollar', 'North America', NULL),
(493, 247, 'ar', 'جزر فيرجن ، الولايات المتحدة', 'Charlotte Amalie', 'دولار', 'أمريكا الشمالية', 'أمريكي'),
(494, 247, 'en', 'Virgin Islands (U.S.)', 'Charlotte Amalie', 'Dollar', 'North America', 'American Virgin Islander'),
(495, 248, 'ar', 'واليس وفوتونا', 'Mata Utu', 'فرنك', 'استراليا', 'فوتوني'),
(496, 248, 'en', 'Wallis and Futuna Islands', 'Mata Utu', 'Franc', 'Oceania', 'Wallisian/Futunan'),
(497, 249, 'ar', 'الصحراء الغربية', 'El-Aaiun', 'Dirham', 'أفريقيا', 'صحراوي'),
(498, 249, 'en', 'Western Sahara', 'El-Aaiun', 'Dirham', 'Africa', 'Sahrawian'),
(499, 250, 'ar', 'اليمن', 'Sanaa', 'ريال', 'آسيا', 'يمني'),
(500, 250, 'en', 'Yemen', 'Sanaa', 'Rial', 'Asia', 'Yemeni'),
(501, 251, 'ar', 'زامبيا', 'Lusaka', 'Kwacha', 'أفريقيا', 'زامبياني'),
(502, 251, 'en', 'Zambia', 'Lusaka', 'Kwacha', 'Africa', 'Zambian'),
(503, 252, 'ar', 'زيمبابوي', 'Harare', 'دولار', 'أفريقيا', 'زمبابوي'),
(504, 252, 'en', 'Zimbabwe', 'Harare', 'Dollar', 'Africa', 'Zimbabwean');

-- --------------------------------------------------------

--
-- Table structure for table `failed_jobs`
--

CREATE TABLE `failed_jobs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `uuid` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `leads_contact_us`
--

CREATE TABLE `leads_contact_us` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `export` int(11) DEFAULT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `phone` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `full_number` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `country` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `subject` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `listing_id` int(11) DEFAULT NULL,
  `project_id` int(11) DEFAULT NULL,
  `request_type` int(11) NOT NULL DEFAULT 1,
  `meeting_day` datetime DEFAULT NULL,
  `meeting_time` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `message` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `leads_contact_us`
--

INSERT INTO `leads_contact_us` (`id`, `export`, `name`, `phone`, `full_number`, `country`, `subject`, `listing_id`, `project_id`, `request_type`, `meeting_day`, `meeting_time`, `message`, `created_at`, `updated_at`) VALUES
(1, 0, 'أ.د كمال عبد الجليل', '5448767200', '+205448767200', 'EG', NULL, 6533, 233, 2, NULL, NULL, NULL, '2024-01-09 07:13:26', '2024-02-09 09:30:20'),
(2, 0, 'السيدة تالا عبد الناصر', '6455285687', '+9736455285687', 'BH', NULL, 4468, 3266, 2, NULL, NULL, NULL, '2024-01-24 09:20:34', '2024-02-09 09:30:20'),
(3, 0, 'Meggie Weissnat', '9518253797', '+19518253797', 'US', NULL, 15385, 15212, 3, '2024-02-10 09:22:38', '04:30 PM', NULL, '2024-02-08 09:22:38', '2024-02-09 09:30:20'),
(4, 0, 'السيدة أروى عبد الرحيم', '6628224522', '+206628224522', 'EG', NULL, 20655, NULL, 3, '2024-01-11 07:05:40', '03:00 PM', NULL, '2024-01-05 07:05:40', '2024-02-09 09:30:20'),
(5, 0, 'عثمان عبد السلام', '5269888644', '+9735269888644', 'BH', NULL, 26275, 25435, 2, NULL, NULL, NULL, '2024-02-06 12:42:19', '2024-02-09 09:30:20'),
(6, 1, 'م. عماد عبد المعطي', '4624270457', '+9734624270457', 'BH', NULL, 5054606, 5052191, 3, '2024-01-24 07:26:58', '05:00 PM', NULL, '2024-01-21 07:26:58', '2024-02-09 09:30:20'),
(7, 1, 'د. شهد عبد الجليل', '4770763223', '+9654770763223', 'KW', 'وجل فأخذتها وكسوتها وفرشت.', NULL, NULL, 1, NULL, NULL, 'فافعل معي معروفًا لأني ممن يصنع معه المعروف والإحسان ويجازي عليهما ولا يغرنك حالي. فلما سمعت كلامها حن قلبي إليها لأمر يريده الله عز وجل علي بهذا ولم يبق لهذا الكلام فائدة ولست أملك شيئًا فأخذته.', '2024-02-07 20:18:01', '2024-02-09 09:30:20'),
(8, 0, 'Dr. Dallas Konopelski', '3711624193', '+13711624193', 'US', NULL, 7946, 4031, 3, '2024-02-01 01:08:35', '12:30 PM', NULL, '2024-01-27 01:08:35', '2024-02-09 09:30:20'),
(9, 1, 'Prof. Jess Conroy V', '1285853993', '+11285853993', 'US', NULL, 5959, 1156, 2, NULL, NULL, NULL, '2024-01-02 18:23:44', '2024-02-09 09:30:20'),
(10, 1, 'ادريس عبد الحميد', '4285875117', '+204285875117', 'EG', 'ثلاثين سنة فلم أرزق منها.', NULL, NULL, 1, NULL, NULL, 'والمعروف ولو لم تجازيني فقالت: يا سيدي إني أقول شيئًا تسر به ولي البشارة. فقلت: نعم فقال: أيها التاجر إن لي بنتًا كانت تعلمت السحر والكهانة من صغرها فسحرت ذلك الولد عجلًا وسحرت الجارية أمه بقرة.', '2024-01-06 18:31:46', '2024-02-09 09:30:20'),
(11, 0, 'دانا الفدا', '0055003790', '+9660055003790', 'SA', NULL, 14534, 115, 2, NULL, NULL, NULL, '2024-01-07 18:13:07', '2024-02-09 09:30:20'),
(12, 1, 'أ.د هالة عبد الحليم', '5291768881', '+9735291768881', 'BH', NULL, 28236, 2159, 2, NULL, NULL, NULL, '2024-01-30 15:01:00', '2024-02-09 09:30:20'),
(13, 1, 'الأستاذ لبيب رجائي', '4730873062', '+9734730873062', 'BH', NULL, 5053019, 5051201, 3, '2024-02-02 14:36:15', '02:00 PM', NULL, '2024-01-27 14:36:15', '2024-02-09 09:30:20'),
(14, 0, 'السيد سيف رجائي', '6230306241', '+9716230306241', 'AE', 'وعظم فندمت على ذبحها حيث لا.', NULL, NULL, 1, NULL, NULL, 'والإحسان ويجازي عليهما ولا يغرنك حالي. فلما سمعت أيها الجني كلام بنت الراعي قلت : ولك فوق جميع ما صنعت بك وبأمك بنت عمي هذه الغزالة هي بنت عمي فحكى لي جميع ما صنعت بك وبأمك بنت عمي هذه الغزالة هي.', '2024-01-25 02:12:56', '2024-02-09 09:30:20'),
(15, 0, 'عوض عبد الناصر', '0692187814', '+200692187814', 'EG', NULL, 5051202, NULL, 2, NULL, NULL, NULL, '2024-01-03 15:51:33', '2024-02-09 09:30:20'),
(16, 1, 'حبيب عبد الحليم', '5805290739', '+9655805290739', 'KW', NULL, 5053165, 5051296, 3, '2024-02-13 15:01:34', '01:00 PM', NULL, '2024-02-08 15:01:34', '2024-02-09 09:30:20'),
(17, 1, 'أ. ديما كاظم', '1820802484', '+9731820802484', 'BH', NULL, 9571, 177, 2, NULL, NULL, NULL, '2024-01-28 01:21:44', '2024-02-09 09:30:20'),
(18, 1, 'م. فاروق عبد الهادي', '0040547046', '+9710040547046', 'AE', 'في بعض البلاد فاشتد عليه.', NULL, NULL, 1, NULL, NULL, 'هذا. وأدرك شهرزاد الصباح فسكتت عن الكلام المباح. فقالت لها أختها: ما أطيب حديثك وألطفه وألذه وأعذبه فقالت: أين هذا مما أحدثكم به الليلة القابلة إن عشت وأبقاني الملك فقال الملك في ذلك فقال لها الملك.', '2024-01-30 11:24:14', '2024-02-09 09:30:20'),
(19, 0, 'نوفان الجريد', '4087915828', '+9664087915828', 'SA', NULL, 24889, 24864, 3, '2024-01-07 11:34:06', '10:00 AM', NULL, '2024-01-01 11:34:06', '2024-02-09 09:30:20'),
(20, 0, 'رائد هارون', '1947094354', '+9731947094354', 'BH', NULL, 5054085, 5053797, 3, '2024-02-07 22:41:56', '04:30 PM', NULL, '2024-02-01 22:41:56', '2024-02-09 09:30:20'),
(21, 1, 'السيد بهاء صدام', '1704795734', '+9651704795734', 'KW', NULL, 5053672, NULL, 3, '2024-02-02 23:10:13', '10:30 AM', NULL, '2024-01-29 23:10:13', '2024-02-09 09:30:20'),
(22, 0, 'م. ضياء عزيز', '2389782719', '+9652389782719', 'KW', 'من حكاية الصياد فقال لها.', NULL, NULL, 1, NULL, NULL, 'القتل بإذن الله تعالى واعلم أني جنية رأيتك فحبك قلبي وأنا مؤمنة بالله ورسوله فجئتك بالحال الذي رأيتني فيه فتزوجت بي وها أنا قد نجيتك من الغرق وقد غضبت على إخوتك ولا بد أن أقتلهم. فلما سمعت كلامي.', '2024-01-14 05:48:29', '2024-02-09 09:30:20'),
(23, 0, 'شريهان عبد الهادي', '3816830647', '+9653816830647', 'KW', 'أشرت عليك بعدم السفر فبكى.', NULL, NULL, 1, NULL, NULL, 'دينار فقلت: ندفن نصفها تحت الأرض وفتحت دكاني بعد ما سلمت على الناس واشتريت بضائع فلما كان الليل دخلت داري فوجدت هاتين الكلبتين أخوتي وأنا ثالثهم ومات والدي وخلف لنا ثلاثة آلاف دينار فقلت: ندفن نصفها.', '2024-01-04 04:45:10', '2024-02-09 09:30:20'),
(24, 0, 'م. لينا عبد المطلب', '1313529094', '+201313529094', 'EG', NULL, 28370, NULL, 2, NULL, NULL, NULL, '2024-01-06 17:32:03', '2024-02-09 09:30:20'),
(25, 1, 'السيدة ثريا عبد الباسط', '6181590747', '+9736181590747', 'BH', NULL, 27988, 27784, 3, '2024-01-26 20:27:24', '02:00 PM', NULL, '2024-01-23 20:27:24', '2024-02-09 09:30:20'),
(26, 0, 'أنسام عبد المهيمن', '0465409690', '+9710465409690', 'AE', 'وقلت لهم: يا أخوتي إننا نحسب.', NULL, NULL, 1, NULL, NULL, 'بعجل سمين فأتاني بولدي المسحور عجلًا فلما رآني ذلك العجل فقالت: نعم يا سيدي إني أقول شيئًا تسر به ولي البشارة. فقلت: نعم فقال: أيها التاجر إن لي بنتًا كانت تعلمت السحر في صغرها من امرأة عجوز كانت.', '2024-01-07 14:00:08', '2024-02-09 09:30:20'),
(27, 0, 'سندس صدام', '1274074890', '+9711274074890', 'AE', NULL, 9986, 4477, 3, '2024-01-31 07:43:29', '03:00 PM', NULL, '2024-01-25 07:43:29', '2024-02-09 09:30:20'),
(28, 1, 'جاسر الداوود', '0933527579', '+200933527579', 'EG', NULL, 733, 185, 3, '2024-01-17 16:25:32', '12:00 PM', NULL, '2024-01-13 16:25:32', '2024-02-09 09:30:20'),
(29, 1, 'المهندس اياد السباعي', '3801897938', '+9713801897938', 'AE', NULL, 16329, 95, 3, '2024-01-23 23:17:58', '12:30 PM', NULL, '2024-01-17 23:17:58', '2024-02-09 09:30:20'),
(30, 0, 'إيمان مهران', '7686598893', '+207686598893', 'EG', NULL, 5053189, 5051297, 3, '2024-01-24 13:34:34', '04:30 PM', NULL, '2024-01-18 13:34:34', '2024-02-09 09:30:20'),
(31, 0, 'السيد أيمن كاظم', '7099436797', '+9737099436797', 'BH', NULL, 5053362, 5051463, 3, '2024-01-18 19:34:50', '11:00 AM', NULL, '2024-01-14 19:34:50', '2024-02-09 09:30:20'),
(32, 1, 'راوية الحصين', '3858319083', '+9663858319083', 'SA', NULL, 27455, 27351, 2, NULL, NULL, NULL, '2024-01-01 14:09:14', '2024-02-09 09:30:20'),
(33, 1, 'Jaylan Brakus', '1543247165', '+11543247165', 'US', 'They had not noticed before.', NULL, NULL, 1, NULL, NULL, 'There were doors all round her head. Still she went hunting about, and crept a little now and then turned to the Duchess: \'what a clear way you go,\' said the Mock Turtle with a bound into the air.', '2024-01-31 05:17:11', '2024-02-09 09:30:20'),
(34, 0, 'الدكتورة رشا هوساوي', '4763695104', '+9714763695104', 'AE', NULL, 2657, 2160, 2, NULL, NULL, NULL, '2024-01-01 16:46:34', '2024-02-09 09:30:20'),
(35, 0, 'سيلين عبد الرحمن', '0916570750', '+200916570750', 'EG', 'قصره. وفي الليلة الثالثة.', NULL, NULL, 1, NULL, NULL, 'له: يا أيها العفريت أن هذه الغزالة هي بنت عمي فدمها لك مباح. فلما سمعت حكايتها تعجبت وشكرتها على فعلها وقلت لها أما هلاك إخوتي فلا ينبغي ثم حكيت لها ما جرى لهما فقلت: يا ولدي قد قيض الله لك من خلصك.', '2024-01-18 13:26:23', '2024-02-09 09:30:20'),
(36, 0, 'أ. يامن عبد الفتاح', '6073042454', '+9656073042454', 'KW', 'حصل لي إلى أن صار ابن خمس.', NULL, NULL, 1, NULL, NULL, 'حديثك وأطيبه وألذه وأعذبه فقالت: وأين هذا مما أحدثكم به الليلة القابلة إن عشت وأبقاني الملك فقال الملك: والله لا أقتلها حتى أسمع بقية حديثها لأنه عجيب ثم باتوا تلك الليلة إلى الصباح متعانقين فخرج.', '2024-01-11 00:25:12', '2024-02-09 09:30:20'),
(37, 1, 'عبدالوهاب قارس الفريدي', '3670622181', '+9663670622181', 'SA', 'أكثر ما وصفه هؤلاء بعد هذا.', NULL, NULL, 1, NULL, NULL, 'الشيء الذي كان تشوقه اليه ابداً، مركبة من معنيين: أحدهما ما يقع فيه الاشتراك منهما جميعاً، وهو معنى الامتداد يشبه الصورة التي لسائر الأجسام ذوات الصور. وهذا الشيء العارف، أمر رباني الهي يستحيل ولا.', '2024-01-17 09:59:18', '2024-02-09 09:30:20'),
(38, 1, 'م. امجد صدام', '7726145340', '+9737726145340', 'BH', 'أمه فقالت لي أن هذا العجل.', NULL, NULL, 1, NULL, NULL, 'هنا فرأيت هؤلاء الجماعة فسألتهم عن حالهم فأخبروني بما جرى لهذا التاجر فجلست لأنظر ما يكون وهذا حديثي فقال الجني: هذا حديث عجيب وقد وهبت لك ثلث دمه في جنايته فعند ذلك تقدم الشيخ الثالث صاحب البغلة.', '2024-02-08 18:40:16', '2024-02-09 09:30:20'),
(39, 0, 'م. عبيدة عبد الناصر', '0697434106', '+9710697434106', 'AE', NULL, 20694, 15985, 2, NULL, NULL, NULL, '2024-01-31 21:13:23', '2024-02-09 09:30:20'),
(40, 1, 'Eleanora Romaguera I', '3181798628', '+13181798628', 'US', NULL, 5051085, 5050816, 2, NULL, NULL, NULL, '2024-01-15 06:18:27', '2024-02-09 09:30:20'),
(41, 0, 'الآنسة بهجة العتيبي', '4466572296', '+9664466572296', 'SA', NULL, 29611, 28824, 2, NULL, NULL, NULL, '2024-01-12 00:50:41', '2024-02-09 09:30:20'),
(42, 1, 'أ.د عوني كاظم', '7269086189', '+207269086189', 'EG', NULL, 5052170, NULL, 2, NULL, NULL, NULL, '2024-01-25 09:22:33', '2024-02-09 09:30:20'),
(43, 1, 'د. عبيدة عبد المهيمن', '8303958559', '+9718303958559', 'AE', NULL, 5978, 201, 3, '2024-01-10 07:26:07', '11:30 AM', NULL, '2024-01-05 07:26:07', '2024-02-09 09:30:20'),
(44, 1, 'Prof. Yvette Abernathy', '4116681142', '+14116681142', 'US', 'Footman went on saying to.', NULL, NULL, 1, NULL, NULL, 'MINE.\' The Queen smiled and passed on. \'Who ARE you talking to?\' said the Mouse. \'--I proceed. \"Edwin and Morcar, the earls of Mercia and Northumbria--\"\' \'Ugh!\' said the Duchess; \'and the moral of.', '2024-01-02 05:14:08', '2024-02-09 09:30:20'),
(45, 1, 'أ. زهرة رسلان', '7590782851', '+207590782851', 'EG', NULL, 2093, 122, 3, '2024-02-02 08:33:06', '11:00 AM', NULL, '2024-01-30 08:33:06', '2024-02-09 09:30:20'),
(46, 0, 'صافي عز العرب', '9470332356', '+9659470332356', 'KW', NULL, 12383, 99, 2, NULL, NULL, NULL, '2024-01-19 05:34:41', '2024-02-09 09:30:20'),
(47, 0, 'د. لبنا هارون', '8489017920', '+208489017920', 'EG', NULL, 20745, 15987, 2, NULL, NULL, NULL, '2024-01-17 13:06:33', '2024-02-09 09:30:20'),
(48, 1, 'أ.د عالية عبد المعطي', '1549004095', '+9711549004095', 'AE', NULL, 3521, 120, 3, '2024-02-09 14:18:22', '02:30 PM', NULL, '2024-02-07 14:18:22', '2024-02-09 09:30:20'),
(49, 1, 'بثينة مجاهد', '4439971239', '+9734439971239', 'BH', NULL, 23830, 5681, 2, NULL, NULL, NULL, '2024-01-12 00:01:20', '2024-02-09 09:30:20'),
(50, 0, 'مجدي مهران', '7620966856', '+207620966856', 'EG', 'فسألت عن ولدي وعن أمه فقالت.', NULL, NULL, 1, NULL, NULL, 'من ذلك غاية العجب وما صدقت بطلوع الصباح حتى جئت إليك لأعلمك فلما سمعت كلامي أخذت طاسة وملأتها ماء ثم أنها حملتني وطارت فوضعتني على سطح داري ففتحت الأبواب وأخرجت الذي خبأته تحت الأرض لينفعا إذا.', '2024-01-08 02:19:26', '2024-02-09 09:30:20'),
(51, 0, 'الآنسة نجلاء عبد الباسط', '9739783040', '+9739739783040', 'BH', NULL, 8362, 54, 2, NULL, NULL, NULL, '2024-01-21 18:28:55', '2024-02-09 09:30:20'),
(52, 0, 'عبدالحليم الشهري', '8746522821', '+9668746522821', 'SA', 'في ذلك كله بتشريح الحيوانات.', NULL, NULL, 1, NULL, NULL, 'فقد حصلت عنده ذاته، وقد كان اولع به حي بن يقظان فيما كان ألزم نفسه من شدة الحرارة عند صدره، بازاء الموضع الذي كان قد اعتبره في نفسه تعلق بما كان قد عاينها قبل ذلك. ونظر هل يجد وصفاً واحداً يعم جميع.', '2024-01-05 23:51:25', '2024-02-09 09:30:20'),
(53, 1, 'السيد شريف عبد الحليم', '3587554306', '+9713587554306', 'AE', NULL, 13790, 80, 3, '2024-01-19 05:52:21', '10:30 AM', NULL, '2024-01-15 05:52:21', '2024-02-09 09:30:20'),
(54, 0, 'د. زيد عبد اللطيف', '9240323785', '+209240323785', 'EG', NULL, 29182, 28443, 3, '2024-01-08 15:29:14', '01:30 PM', NULL, '2024-01-05 15:29:14', '2024-02-09 09:30:20'),
(55, 1, 'م. نزيه عبد الكريم', '3847492446', '+9653847492446', 'KW', NULL, 1463, 166, 3, '2024-01-11 01:14:22', '12:00 PM', NULL, '2024-01-07 01:14:22', '2024-02-09 09:30:20'),
(56, 0, 'Miss Lora Purdy', '6475715053', '+16475715053', 'US', NULL, 5051694, NULL, 3, '2024-01-20 04:20:41', '01:30 PM', NULL, '2024-01-16 04:20:41', '2024-02-09 09:30:20'),
(57, 1, 'Joey Hammes', '5436591172', '+15436591172', 'US', NULL, 3635, 2404, 3, '2024-01-19 16:52:21', '01:30 PM', NULL, '2024-01-17 16:52:21', '2024-02-09 09:30:20'),
(58, 0, 'دانا مجاهد', '6406854178', '+9656406854178', 'KW', NULL, 20465, 17670, 3, '2024-02-12 05:37:21', '01:00 PM', NULL, '2024-02-08 05:37:21', '2024-02-09 09:30:20'),
(59, 0, 'سامي السعيد', '5008033293', '+9715008033293', 'AE', NULL, 12384, 99, 3, '2024-01-07 15:03:22', '01:00 PM', NULL, '2024-01-03 15:03:22', '2024-02-09 09:30:20'),
(60, 1, 'صادق عبد المجيد', '4685210246', '+9714685210246', 'AE', NULL, 5054500, 5052256, 3, '2024-01-30 21:26:58', '05:00 PM', NULL, '2024-01-28 21:26:58', '2024-02-09 09:30:20'),
(61, 0, 'Tod Satterfield', '4814650960', '+14814650960', 'US', NULL, 4437, 201, 2, NULL, NULL, NULL, '2024-01-06 08:19:15', '2024-02-09 09:30:20'),
(62, 0, 'Dr. Jordane Bayer', '3807842348', '+13807842348', 'US', NULL, 1908, 199, 2, NULL, NULL, NULL, '2024-02-01 12:40:16', '2024-02-09 09:30:20'),
(63, 0, 'أ. حمزة عبد المهيمن', '6873858211', '+206873858211', 'EG', NULL, 20161, NULL, 2, NULL, NULL, NULL, '2024-01-16 16:32:12', '2024-02-09 09:30:20'),
(64, 1, 'د. شريفة عزام', '5391869650', '+9655391869650', 'KW', NULL, 5051934, 5050879, 2, NULL, NULL, NULL, '2024-01-17 04:10:32', '2024-02-09 09:30:20'),
(65, 0, 'Maribel Windler', '8620644244', '+18620644244', 'US', NULL, 8502, 117, 3, '2024-02-02 12:05:27', '03:30 PM', NULL, '2024-01-29 12:05:27', '2024-02-09 09:30:20'),
(66, 0, 'الآنسة نانسي عبد الرحمن', '4396554417', '+204396554417', 'EG', NULL, 1285, 150, 2, NULL, NULL, NULL, '2024-01-23 00:04:14', '2024-02-09 09:30:20'),
(67, 1, 'هدى كاظم', '7252855429', '+9737252855429', 'BH', 'فقمت عنها وأمرت ذلك الراعي.', NULL, NULL, 1, NULL, NULL, 'وأقمنا مع بعضنا أيامًا ثم إن أخوتي طلبوا السفر أيضًا وأرادوا أن أسافر معهم فلم أرض وقلت لهم: أي شيء كسبتم من سفركم حتى أكسب أنا فألحوا علي ولم أطعهم بل أقمنا في دكاكيننا نبيع ونشتري سنة كاملة وهم.', '2024-01-14 18:48:34', '2024-02-09 09:30:20'),
(68, 1, 'بسام عمران', '8120771123', '+208120771123', 'EG', NULL, 16565, 33, 3, '2024-01-24 19:44:32', '03:30 PM', NULL, '2024-01-21 19:44:32', '2024-02-09 09:30:20'),
(69, 0, 'Sunny Huels', '3369693917', '+13369693917', 'US', 'However, this bottle was a.', NULL, NULL, 1, NULL, NULL, 'WHAT?\' thought Alice to herself. Imagine her surprise, when the Rabbit say, \'A barrowful of WHAT?\' thought Alice to herself, rather sharply; \'I advise you to set them free, Exactly as we were. My.', '2024-01-07 17:54:49', '2024-02-09 09:30:20'),
(70, 0, 'حنين عبد الفتاح', '5729089529', '+9715729089529', 'AE', NULL, 22382, NULL, 3, '2024-01-14 00:40:12', '12:30 PM', NULL, '2024-01-09 00:40:12', '2024-02-09 09:30:20'),
(71, 0, 'المهندس امين عبد العزيز', '2929105424', '+202929105424', 'EG', NULL, 17087, 117, 3, '2024-01-23 20:57:25', '04:00 PM', NULL, '2024-01-17 20:57:25', '2024-02-09 09:30:20'),
(72, 1, 'م. اسراء عبد الرزاق', '4927161145', '+9714927161145', 'AE', NULL, 14567, 4027, 3, '2024-01-30 19:17:25', '11:00 AM', NULL, '2024-01-28 19:17:25', '2024-02-09 09:30:20'),
(73, 1, 'طه هارون', '5119886656', '+9735119886656', 'BH', NULL, 26136, 25486, 3, '2024-01-05 07:01:45', '11:30 AM', NULL, '2024-01-01 07:01:45', '2024-02-09 09:30:20'),
(74, 1, 'السيد نزار غالب', '6541589827', '+9716541589827', 'AE', 'وقالت لي: أنا زوجتك التي.', NULL, NULL, 1, NULL, NULL, 'عمي هذه الغزالة تعلمت السحر والكهانة من صغرها فسحرت ذلك الولد عجلًا وسحرت الجارية أمه بقرة وسلمتها إلى الراعي ثم أنها حملتني وطارت فوضعتني على سطح داري ففتحت الأبواب وأخرجت الذي خبأته تحت الأرض.', '2024-01-12 15:43:16', '2024-02-09 09:30:20'),
(75, 1, 'Mrs. Neva Keebler Sr.', '1130369318', '+11130369318', 'US', NULL, 9420, 209, 3, '2024-02-02 12:01:51', '10:30 AM', NULL, '2024-01-29 12:01:51', '2024-02-09 09:30:20'),
(76, 0, 'م. سعيد مجاهد', '4125253490', '+204125253490', 'EG', NULL, 5050534, 5050399, 3, '2024-01-16 18:50:27', '03:30 PM', NULL, '2024-01-11 18:50:27', '2024-02-09 09:30:20'),
(77, 0, 'Tyson Hoeger', '6066790587', '+16066790587', 'US', 'However, I\'ve got to the.', NULL, NULL, 1, NULL, NULL, 'Alice; \'I daresay it\'s a French mouse, come over with diamonds, and walked two and two, as the Dormouse began in a twinkling! Half-past one, time for dinner!\' (\'I only wish it was,\' he said.', '2024-01-10 05:28:32', '2024-02-09 09:30:20'),
(78, 0, 'السيدة هيلين جبر', '4729814289', '+204729814289', 'EG', NULL, 21367, 20724, 3, '2024-01-10 04:53:39', '01:00 PM', NULL, '2024-01-04 04:53:39', '2024-02-09 09:30:20'),
(79, 1, 'سائد مدني', '8507201101', '+9668507201101', 'SA', NULL, 5050447, 5050405, 3, '2024-01-15 11:20:32', '01:30 PM', NULL, '2024-01-09 11:20:32', '2024-02-09 09:30:20'),
(80, 0, 'م. صفاء الكفراوي', '5626167075', '+9715626167075', 'AE', 'اشتغلت بها عن إخوتي فغاروا.', NULL, NULL, 1, NULL, NULL, 'بل أقمنا في دكاكيننا نبيع ونشتري سنة كاملة وهم يعرضون علي السفر وأنا لم أرض حتى مضت ست سنوات كوامل. ثم وافقتهم على السفر وقلت لهم: يا أخوتي إننا نحسب ما عندنا من المال فحسبناه فإذا هو ستة آلاف دينار.', '2024-01-24 22:34:56', '2024-02-09 09:30:20'),
(81, 1, 'آمال الداوود', '0695208404', '+9730695208404', 'BH', NULL, 17538, 10, 2, NULL, NULL, NULL, '2024-01-13 00:26:44', '2024-02-09 09:30:20'),
(82, 0, 'السيدة رزان عزام', '9261618618', '+9719261618618', 'AE', 'هذه الغزالة تنظر وترى وتقول.', NULL, NULL, 1, NULL, NULL, 'طالب فوجدتها نائمة فرششت عليها الماء وقلت اخرجي من هذه الصورة إلى صورة كلب فصرت في الحال بغلة وهي هذه التي تنظرها بعينك أيها السلطان ورئيس الجان إن هذه البغلة كانت زوجتي سافرت وغبت عنها سنة كاملة ثم.', '2024-01-05 05:53:41', '2024-02-09 09:30:20'),
(83, 0, 'رغد الصعيدي', '1356228615', '+201356228615', 'EG', NULL, 5052129, 5050832, 3, '2024-01-19 17:51:31', '10:00 AM', NULL, '2024-01-15 17:51:31', '2024-02-09 09:30:20'),
(84, 1, 'د. وسام عز الدين', '4516420171', '+9714516420171', 'AE', NULL, 3613, 932, 3, '2024-01-17 03:18:50', '11:00 AM', NULL, '2024-01-11 03:18:50', '2024-02-09 09:30:20'),
(85, 0, 'م. ريم عبد اللطيف', '4725531762', '+204725531762', 'EG', NULL, 13118, 199, 2, NULL, NULL, NULL, '2024-01-10 07:31:10', '2024-02-09 09:30:20'),
(86, 1, 'Georgiana Lind', '3670553065', '+13670553065', 'US', NULL, 5110, 116, 2, NULL, NULL, NULL, '2024-01-31 02:35:01', '2024-02-09 09:30:20'),
(87, 0, 'م. صباح عز الدين', '8929780114', '+9738929780114', 'BH', NULL, 15236, 3651, 2, NULL, NULL, NULL, '2024-01-05 21:27:15', '2024-02-09 09:30:20'),
(88, 0, 'حسان عبد اللطيف', '7392928556', '+9717392928556', 'AE', 'إليها تخلصهم بعد إقامتهم عشر.', NULL, NULL, 1, NULL, NULL, 'أزل سائرًا حتى وصلت دكان جزار فتقدمت وصرت آكل من العظام. فلما رآني صاحب الدكان أخذني ودخل بي بيته فلما رأتني بنت الجزار غطت وجهها مني فقالت أتجيء لنا برجل وتدخل علينا به فقال أبوها أين الرجل قالت إن.', '2024-02-04 04:45:23', '2024-02-09 09:30:20'),
(89, 0, 'السيد نعيم عبد المعطي', '3726282308', '+9713726282308', 'AE', NULL, 806, 186, 2, NULL, NULL, NULL, '2024-01-02 08:24:29', '2024-02-09 09:30:20'),
(90, 0, 'د. خليل عبد الناصر', '6439787580', '+206439787580', 'EG', NULL, 5604, 155, 3, '2024-02-03 20:27:30', '12:30 PM', NULL, '2024-01-31 20:27:30', '2024-02-09 09:30:20'),
(91, 1, 'عوده العتيبي', '7921792946', '+9667921792946', 'SA', NULL, 25626, 25585, 2, NULL, NULL, NULL, '2024-01-05 14:34:54', '2024-02-09 09:30:20'),
(92, 0, 'اسلام جمال الدين', '9125261215', '+209125261215', 'EG', NULL, 3125, 3016, 3, '2024-02-05 10:59:05', '02:30 PM', NULL, '2024-02-03 10:59:05', '2024-02-09 09:30:20'),
(93, 1, 'راوية عبد الكريم', '3330961102', '+9733330961102', 'BH', 'الفرح وقسمت الربح بيني وبينه.', NULL, NULL, 1, NULL, NULL, 'بنتي خلصيه فأخذت كوزًا فيه ماء فتكلمت عليه ورشتني وقالت اخرج من هذه الصورة إلى صورتك الأولى فصرت إلى صورتي الأولى فقبلت يدها وقلت لها: أريد أن تسحري زوجتي كما سحرتني فأعطتني قليلًا من الماء وقالت.', '2024-01-14 20:08:42', '2024-02-09 09:30:20'),
(94, 0, 'هديل عزام', '6959289887', '+9656959289887', 'KW', 'المال جميعه وتحدثوا بقتلي.', NULL, NULL, 1, NULL, NULL, 'فقلت لها: أيها الصبية إن أنت خلصتيه فلك عندي ما تحت يد أبيك من المواشي والأموال فتبسمت وقالت: يا سيدي هل عندك إحسان ومعروف أجازيك عليهما قلت: نعم إن عندي الإحسان والمعروف ولو لم تجازيني فقالت: يا.', '2024-01-20 03:51:58', '2024-02-09 09:30:20'),
(95, 1, 'السيدة اشراق عبد السلام', '5103777520', '+9735103777520', 'BH', NULL, 23541, NULL, 3, '2024-02-07 12:14:10', '04:00 PM', NULL, '2024-02-02 12:14:10', '2024-02-09 09:30:20'),
(96, 1, 'منتصر عبد الجليل', '2423339177', '+9712423339177', 'AE', 'فأخذت كوزًا فيه ماء فتكلمت.', NULL, NULL, 1, NULL, NULL, 'وترى وتقول اذبح هذا العجل الذي معك ابن سيدي التاجر ولكنه مسحور وسحرته زوجة أبيه هو وأمه فهذا سبب ضحكي وأما سبب بكائي فمن أجل أمه حيث ذبحها أبوه فتعجبت من ذلك غاية العجب وما صدقت بطلوع الصباح حتى جئت.', '2024-01-30 18:43:19', '2024-02-09 09:30:20'),
(97, 0, 'ركان جعفر اصلان الجريد', '0379397868', '+9660379397868', 'SA', 'الحيوان محاكاة شديدة لقوة.', NULL, NULL, 1, NULL, NULL, 'كله بتشريح الحيوانات الأحياء و الاموات، ولم يزل أسال يرغب إليه ويستعطفه. وقد كان له مسكن يقيه مما يرد عليه من الكمال والبهاء والجمال، وليس في الوجود إلا الواحد الحق - تعالى وتقدس عن ذلك؛ لا اله إلا.', '2024-01-13 03:02:31', '2024-02-09 09:30:20'),
(98, 1, 'خضر جبر', '0016227665', '+9710016227665', 'AE', NULL, 8323, 4754, 2, NULL, NULL, NULL, '2024-01-23 06:39:49', '2024-02-09 09:30:20'),
(99, 0, 'ليان رجب سلام العتيبي', '9286260271', '+9669286260271', 'SA', NULL, 29903, 29805, 2, NULL, NULL, NULL, '2024-01-06 22:00:09', '2024-02-09 09:30:20'),
(100, 0, 'الأستاذ علي مجاهد', '5302431989', '+9735302431989', 'BH', NULL, 6468, 183, 2, NULL, NULL, NULL, '2024-01-23 04:25:37', '2024-02-09 09:30:20'),
(101, 1, 'مالك جمال الدين', '7737716437', '+9737737716437', 'BH', 'قليلًا وقالت: اخرج من هذه.', NULL, NULL, 1, NULL, NULL, 'كل حال قالت لا بد من قتلهم فاستعطفتها ثم أنها حملتني وطارت فوضعتني على سطح داري ففتحت الأبواب وأخرجت الذي خبأته تحت الأرض لينفعا إذا أصابنا أمر ويأخذ كل واحد منا ألف دينار وجهزنا بضائع واكترينا.', '2024-01-27 08:12:07', '2024-02-09 09:30:20'),
(102, 0, 'نيروز السايس', '8958945881', '+9658958945881', 'KW', 'لي معهم من أول الزمان إلى.', NULL, NULL, 1, NULL, NULL, 'أن تزوجني به والثاني: أن أسر من سحرته وأحبسها وإلا فلست آمن مكرها فلما سمعت كلامي قالت: أنا في هذه الليلة أطير إليهم وأغرق مراكبهم وأهلكهم فقلت لها: بالله لا تفعلي فإن صاحب المثل يقول: يا محسنًا لمن.', '2024-01-06 18:52:57', '2024-02-09 09:30:20'),
(103, 0, 'لانا مدني', '9598376814', '+9669598376814', 'SA', NULL, 14104, 75, 2, NULL, NULL, NULL, '2024-01-30 10:01:50', '2024-02-09 09:30:20'),
(104, 1, 'سندس القحطاني', '3563745213', '+9663563745213', 'SA', 'عمي فانه لا محالة صادران عن.', NULL, NULL, 1, NULL, NULL, 'كانت لا تغيب عنه في وقت من الأوقات، فبان له بذلك ما امله من طرد الحيوانات التي يتغذى بها: أما البرية واما البحرية. وكان قد اعتقد أن أحوال الحيوان، ولم ير فيه شيء على خلاف الحقيقة، فلا يعرفه إلا من.', '2024-02-08 07:49:37', '2024-02-09 09:30:20'),
(105, 0, 'الدكتور عوني عبد الرزاق', '1473682112', '+9651473682112', 'KW', NULL, 3623, 2404, 3, '2024-01-30 11:39:15', '04:30 PM', NULL, '2024-01-25 11:39:15', '2024-02-09 09:30:20'),
(106, 0, 'د. غسان عبد الحميد', '4600187281', '+9654600187281', 'KW', NULL, 11437, 931, 2, NULL, NULL, NULL, '2024-02-04 07:38:50', '2024-02-09 09:30:20'),
(107, 0, 'الدكتور وجيه جمال الدين', '2124747863', '+9652124747863', 'KW', 'آلاف الأخرى فأعطيت كل واحد.', NULL, NULL, 1, NULL, NULL, 'لي الملك في نفسه: والله ما أقتلها حتى أسمع بقية حديثها ثم أنهم باتوا تلك الليلة إلى الصباح فخرج الملك إلى محل حكمه ودخل عليه الوزير والعسكر واحتبك الديوان فحكم الملك وولى وعزل ونهى وأمر إلى آخر.', '2024-02-04 01:15:30', '2024-02-09 09:30:20'),
(108, 0, 'الأستاذ حمدان عبد الحميد', '2406873080', '+9652406873080', 'KW', 'وقال: أصحيح هذا فهزت رأسها.', NULL, NULL, 1, NULL, NULL, 'والعسكر واحتبك الديوان فحكم الملك وولى وعزل ونهى وأمر إلى آخر النهار ولم يخبر الوزير بشيء من ذلك غاية العجب وما صدقت بطلوع الصباح حتى جئت إليك لأعلمك فلما سمعت كلامي أخذت طاسة وملأتها ماء ثم أنها.', '2024-02-01 00:54:01', '2024-02-09 09:30:20'),
(109, 0, 'أ. حاتم عبد العزيز', '2258007686', '+9712258007686', 'AE', NULL, 704, 203, 2, NULL, NULL, NULL, '2024-01-26 09:25:33', '2024-02-09 09:30:20'),
(110, 1, 'تغريد الماجد', '9541455736', '+9669541455736', 'SA', NULL, 8311, 4754, 2, NULL, NULL, NULL, '2024-02-01 23:11:49', '2024-02-09 09:30:20'),
(111, 1, 'الآنسة هيا عبد الوهاب', '7387448851', '+9717387448851', 'AE', NULL, 12769, 82, 3, '2024-02-13 07:46:08', '04:30 PM', NULL, '2024-02-08 07:46:08', '2024-02-09 09:30:20'),
(112, 0, 'حليمة السويلم', '4304098887', '+9734304098887', 'BH', NULL, 14698, 31, 3, '2024-02-04 13:27:37', '12:00 PM', NULL, '2024-02-01 13:27:37', '2024-02-09 09:30:20'),
(113, 1, 'Jess Bartoletti PhD', '6110397842', '+16110397842', 'US', NULL, 17012, 91, 3, '2024-01-12 10:06:46', '02:30 PM', NULL, '2024-01-09 10:06:46', '2024-02-09 09:30:20'),
(114, 0, 'Miss Grace Moen DDS', '3334166115', '+13334166115', 'US', NULL, 4179, 9, 3, '2024-01-19 18:43:35', '01:30 PM', NULL, '2024-01-14 18:43:35', '2024-02-09 09:30:20'),
(115, 0, 'Madeline Lesch', '1513139006', '+11513139006', 'US', NULL, 3246, 2410, 2, NULL, NULL, NULL, '2024-01-08 14:26:50', '2024-02-09 09:30:20'),
(116, 1, 'مرح مروان الخضيري', '5389437437', '+9665389437437', 'SA', NULL, 15383, 15212, 3, '2024-01-18 10:37:02', '02:30 PM', NULL, '2024-01-15 10:37:02', '2024-02-09 09:30:20'),
(117, 1, 'هايدي عبد القادر', '7229209371', '+9657229209371', 'KW', NULL, 17509, 117, 3, '2024-01-16 21:21:29', '01:30 PM', NULL, '2024-01-11 21:21:29', '2024-02-09 09:30:20'),
(118, 1, 'أ.د جنى كاظم', '5152344517', '+9735152344517', 'BH', NULL, 11585, 96, 3, '2024-02-05 17:41:07', '02:30 PM', NULL, '2024-02-01 17:41:07', '2024-02-09 09:30:20'),
(119, 0, 'نزار عبد اللطيف', '4612389085', '+204612389085', 'EG', NULL, 167, NULL, 2, NULL, NULL, NULL, '2024-01-15 16:24:20', '2024-02-09 09:30:20'),
(120, 1, 'Aaron Schultz', '6165322302', '+16165322302', 'US', 'Alice \'without pictures or.', NULL, NULL, 1, NULL, NULL, 'Rabbit in a hurry. \'No, I\'ll look first,\' she said, as politely as she remembered the number of bathing machines in the air: it puzzled her a good way off, panting, with its legs hanging down, but.', '2024-01-23 03:08:18', '2024-02-09 09:30:20'),
(121, 0, 'الأستاذ داوود شافع', '1655089125', '+201655089125', 'EG', 'أنا بعد مدة طويلة من السفر.', NULL, NULL, 1, NULL, NULL, 'مسلسلة فسلم على هذا التاجر وحياه وقال له: يا أخي أما أشرت عليك بعدم السفر فبكى وقال: يا سيدي إيه ابنك وحشاشة كبدك فقلت لها: بالله لا تفعلي فإن صاحب المثل يقول: يا محسنًا لمن أساء كفي المسيء فعله وهم.', '2024-01-09 05:38:18', '2024-02-09 09:30:20'),
(122, 1, 'بشير بشر قيس هوساوي', '2879638737', '+9662879638737', 'SA', 'أن يشغله عن حاله، فاقتفى حي.', NULL, NULL, 1, NULL, NULL, 'العدو وقوة البطش، وما لها من جهة الابتداء، إذ لم يكن جسماً فليس إلى إدراكه لشيء من الحواس لكان جسماً من الأجسام، تشترك في صورة واحدة تصدر عنها الحركة إلى الأسفل، ما لم يقم بباله قط؛ وراها في ألام لا.', '2024-02-06 05:38:18', '2024-02-09 09:30:20'),
(123, 0, 'إلياس الداوود', '3499373714', '+203499373714', 'EG', 'الله لك من خلصك وخلص حقك ثم.', NULL, NULL, 1, NULL, NULL, 'قتلت ولدي فقال له التاجر: كيف قتلت ولدك قال له: لما أكلت التمرة ورميت نواتها جاءت النواة في صدر ولدي فقضي عليه ومات من ساعته فقال التاجر للعفريت: أعلم أيها العفريت أن هذه الغزالة تعلمت السحر.', '2024-01-11 20:53:37', '2024-02-09 09:30:20'),
(124, 1, 'احسان عبد المهيمن', '4054479616', '+9654054479616', 'KW', NULL, 24295, NULL, 3, '2024-02-06 14:15:47', '12:00 PM', NULL, '2024-02-02 14:15:47', '2024-02-09 09:30:20'),
(125, 1, 'نائل عبد المعطي', '7686173984', '+9717686173984', 'AE', NULL, 22822, 20388, 2, NULL, NULL, NULL, '2024-01-13 04:02:24', '2024-02-09 09:30:20'),
(126, 1, 'مظهر الحسين', '3366948027', '+9663366948027', 'SA', NULL, 6368, 1133, 3, '2024-01-23 21:00:59', '01:00 PM', NULL, '2024-01-20 21:00:59', '2024-02-09 09:30:20'),
(127, 0, 'Miss Maxie Gutkowski', '1044844766', '+11044844766', 'US', NULL, 14559, 4027, 2, NULL, NULL, NULL, '2024-01-26 03:51:30', '2024-02-09 09:30:21'),
(128, 0, 'ضحى السباعي', '8207415981', '+208207415981', 'EG', NULL, 5054348, NULL, 3, '2024-01-07 19:55:17', '04:00 PM', NULL, '2024-01-03 19:55:17', '2024-02-09 09:30:21'),
(129, 0, 'المهندسة نيفين حارث', '6702532125', '+9656702532125', 'KW', NULL, 9748, 3898, 2, NULL, NULL, NULL, '2024-01-08 19:27:06', '2024-02-09 09:30:21'),
(130, 0, 'Keshaun Wolff PhD', '2505947544', '+12505947544', 'US', NULL, 21123, 20631, 2, NULL, NULL, NULL, '2024-01-01 08:24:00', '2024-02-09 09:30:21'),
(131, 0, 'م. آدم جمال الدين', '5143173439', '+9735143173439', 'BH', NULL, 20183, NULL, 2, NULL, NULL, NULL, '2024-01-19 00:27:54', '2024-02-09 09:30:21'),
(132, 1, 'نشات عبد المعطي', '4709879913', '+9654709879913', 'KW', NULL, 5177, 1036, 2, NULL, NULL, NULL, '2024-01-09 15:42:15', '2024-02-09 09:30:21'),
(133, 0, 'السيد مسعد مهران', '1642178408', '+9731642178408', 'BH', 'أخي إني أحسب ربح دكاني من.', NULL, NULL, 1, NULL, NULL, 'بعدم السفر فبكى وقال: يا أخي أما أشرت عليك بعدم السفر فبكى وقال: يا أخي أما أشرت عليك بعدم السفر فبكى وقال: يا سيدي إني أقول شيئًا تسر به ولي البشارة. فقلت: نعم فقال: أيها التاجر إن لي بنتًا كانت.', '2024-02-05 11:04:31', '2024-02-09 09:30:21'),
(134, 1, 'السيد فادي عبد المطلب', '0752845516', '+200752845516', 'EG', 'صورتي الأولى فقبلت يدها وقلت.', NULL, NULL, 1, NULL, NULL, 'وأولاده وأوصى وقعد عندهم إلى تمام السنة ثم توجه وأخذ كفنه تحت إبطه وودع أهله وجيرانه وجميع أهله وخرج رغمًا عن أنفه وأقيم عليه العياط والصراخ فمشى إلى أن أتيت إلى داره فرحبت بي ابنة الراعي ثم أنها.', '2024-01-24 12:32:34', '2024-02-09 09:30:21'),
(135, 0, 'المهندسة دارين الشيباني', '6302740008', '+9666302740008', 'SA', NULL, 7250, 85, 3, '2024-01-20 23:06:34', '01:00 PM', NULL, '2024-01-18 23:06:34', '2024-02-09 09:30:21'),
(136, 0, 'أ. اديب غالب', '6437793399', '+9716437793399', 'AE', 'شيئًا تسر به ولي البشارة.', NULL, NULL, 1, NULL, NULL, 'البدر إذا بدا بعينين مليحتين وحاجبين مزججين وأعضاء كاملة فكبر شيئًا فشيئًا إلى أن أتيت إلى داره فرحبت بي ابنة الراعي وقبلت يدي ثم إن العجل جاء إلي وتمرغ علي وولول وبكى فأخذتني الرأفة عليه وقلت له.', '2024-01-07 10:39:23', '2024-02-09 09:30:21'),
(137, 0, 'م. شاكر عبد المطلب', '4978454562', '+9654978454562', 'KW', NULL, 7165, 162, 3, '2024-01-16 23:01:52', '12:30 PM', NULL, '2024-01-13 23:01:52', '2024-02-09 09:30:21'),
(138, 0, 'الدكتورة رويدة الداوود', '5145746346', '+9715145746346', 'AE', NULL, 26391, 25493, 2, NULL, NULL, NULL, '2024-01-23 01:13:45', '2024-02-09 09:30:21'),
(139, 0, 'الآنسة وسام عبد المطلب', '0652258163', '+9710652258163', 'AE', NULL, 5539, 76, 3, '2024-01-30 16:21:12', '01:30 PM', NULL, '2024-01-24 16:21:12', '2024-02-09 09:30:21'),
(140, 1, 'شروق عبد الرحمن', '2544423142', '+9712544423142', 'AE', NULL, 5287, 35, 3, '2024-01-11 17:01:50', '01:30 PM', NULL, '2024-01-09 17:01:50', '2024-02-09 09:30:21'),
(141, 0, 'تهاني عز الدين', '0965763474', '+9650965763474', 'KW', NULL, 20709, 15985, 3, '2024-02-09 05:55:04', '04:00 PM', NULL, '2024-02-07 05:55:04', '2024-02-09 09:30:21'),
(142, 0, 'ريناد جمال الدين', '7819906984', '+9737819906984', 'BH', NULL, 22558, 18957, 3, '2024-01-26 14:16:41', '05:00 PM', NULL, '2024-01-22 14:16:41', '2024-02-09 09:30:21'),
(143, 1, 'م. إكرام عبد الهادي', '6965280140', '+9716965280140', 'AE', NULL, 9835, 4053, 3, '2024-01-05 12:23:18', '12:00 PM', NULL, '2024-01-02 12:23:18', '2024-02-09 09:30:21'),
(144, 0, 'Ms. Laney Schaden II', '3512500642', '+13512500642', 'US', NULL, 22449, 20391, 3, '2024-01-17 20:29:47', '04:00 PM', NULL, '2024-01-11 20:29:47', '2024-02-09 09:30:21'),
(145, 0, 'م. نقولا عبد القادر', '7995678276', '+207995678276', 'EG', 'ولم أزل سائرًا حتى وصلت دكان.', NULL, NULL, 1, NULL, NULL, 'وبعنا بضائعنا فربحنا في الدينار عشرة دنانير ثم أردنا السفر فوجدنا على شاطئ البحر جارية عليها خلق مقطع فقبلت يدي وقالت: يا أبي قد خس قدري عندك حتى تدخل علي الرجال الأجانب. فقلت لها: وأين الرجال.', '2024-01-25 22:00:05', '2024-02-09 09:30:21'),
(146, 0, 'وديع السقا', '4176241177', '+9654176241177', 'KW', 'البدر إذا بدا بعينين مليحتين.', NULL, NULL, 1, NULL, NULL, 'حالهم فأخبروني بما جرى لهذا التاجر فجلست لأنظر ما يكون وهذا حديثي فقال الجني: هذا حديث عجيب وقد وهبت لك ثلث دمه فعند ذلك تقدم الشيخ صاحب الكلبتين السلاقيتين وقال له: يا أخي إني أحسب ربح دكاني من.', '2024-01-20 23:51:03', '2024-02-09 09:30:21'),
(147, 0, 'د. ناديه نجيب', '5659369952', '+205659369952', 'EG', NULL, 4533, 186, 2, NULL, NULL, NULL, '2024-02-05 16:40:29', '2024-02-09 09:30:21'),
(148, 0, 'مجدولين عبد المطلب', '9905815535', '+209905815535', 'EG', 'الراعي أن يأخذه وتوجه به ففي.', NULL, NULL, 1, NULL, NULL, 'أبوها كلامها قال: بالله عليك يا بنتي خلصيه فأخذت كوزًا فيه ماء وتكلمت عليه ورشت علي منه قليلًا وقالت: اخرج من هذه الصورة إلى صورتك الأولى فصرت إلى صورتي الأولى فقبلت يدها وقلت لها: أريد أن تسحري.', '2024-01-20 13:25:06', '2024-02-09 09:30:21'),
(149, 0, 'قارس فواز', '3740016697', '+9653740016697', 'KW', NULL, 13764, 1043, 3, '2024-01-26 09:31:11', '02:30 PM', NULL, '2024-01-22 09:31:11', '2024-02-09 09:30:21'),
(150, 0, 'حلا جبر', '4136645541', '+9654136645541', 'KW', NULL, 6437, 172, 2, NULL, NULL, NULL, '2024-01-23 12:20:09', '2024-02-09 09:30:21'),
(151, 1, 'م. مؤنس غالب', '7329210833', '+9657329210833', 'KW', NULL, 29131, 28441, 2, NULL, NULL, NULL, '2024-01-15 20:53:50', '2024-02-09 09:30:21'),
(152, 0, 'م. ميان مهران', '1681996910', '+9731681996910', 'BH', 'رهون فدعني أذهب إلى بيتي.', NULL, NULL, 1, NULL, NULL, 'الليلة إلى الصباح فخرج الملك إلى محل حكمه ودخل عليه الوزير والعسكر واحتبك الديوان فحكم الملك وولى وعزل ونهى وأمر إلى آخر النهار ثم انفض الديوان ودخل الملك شهريار قصره. و في الليلة الثانية قالت.', '2024-02-05 19:44:48', '2024-02-09 09:30:21'),
(153, 1, 'أ.د مهدي عبد الحميد', '2022287540', '+9712022287540', 'AE', 'فتزوجت بي وها أنا قد نجيتك.', NULL, NULL, 1, NULL, NULL, 'اخرجي من هذه الصورة إلى صورتك الأولى فصرت إلى صورتي الأولى فقبلت يدها وقلت لها: أريد أن تسحري زوجتي كما سحرتني فأعطتني قليلًا من الماء وقالت إذا رأيتها نائمة فرش هذا الماء عليها فإنها تصير كما أنت.', '2024-01-13 00:18:02', '2024-02-09 09:30:21'),
(154, 0, 'نسيمة عبد الرؤوف', '2466986665', '+9732466986665', 'BH', NULL, 3701, 3186, 2, NULL, NULL, NULL, '2024-02-06 00:20:45', '2024-02-09 09:30:21'),
(155, 1, 'Dr. Dorthy Streich III', '6185022183', '+16185022183', 'US', 'Hatter instead!\' CHAPTER.', NULL, NULL, 1, NULL, NULL, 'Alice, who felt ready to talk to.\' \'How are you getting on now, my dear?\' it continued, turning to Alice, very loudly and decidedly, and there stood the Queen added to one of the garden: the roses.', '2024-01-31 09:36:20', '2024-02-09 09:30:21'),
(156, 0, 'Ms. Astrid Beahan Sr.', '5352017662', '+15352017662', 'US', NULL, 16220, 150, 2, NULL, NULL, NULL, '2024-01-07 15:17:55', '2024-02-09 09:30:21'),
(157, 1, 'الآنسة أزهار السباعي', '6615813580', '+9716615813580', 'AE', NULL, 27969, 27785, 3, '2024-01-24 02:18:27', '01:00 PM', NULL, '2024-01-19 02:18:27', '2024-02-09 09:30:21'),
(158, 0, 'د. رشا الداوود', '3821990879', '+9653821990879', 'KW', NULL, 11653, 873, 2, NULL, NULL, NULL, '2024-02-08 10:53:16', '2024-02-09 09:30:21'),
(159, 1, 'هلال مظهر', '1497925271', '+9651497925271', 'KW', NULL, 15252, 15212, 3, '2024-01-09 16:06:55', '12:30 PM', NULL, '2024-01-04 16:06:55', '2024-02-09 09:30:21'),
(160, 0, 'Pearline Effertz II', '0983751222', '+10983751222', 'US', NULL, 5050247, 5050234, 3, '2024-01-25 14:01:36', '03:00 PM', NULL, '2024-01-19 14:01:36', '2024-02-09 09:30:21'),
(161, 1, 'السيد عواد عبد الجواد', '4891847769', '+9654891847769', 'KW', NULL, 29177, 28443, 3, '2024-01-31 22:03:34', '03:00 PM', NULL, '2024-01-29 22:03:34', '2024-02-09 09:30:21'),
(162, 1, 'جراح السعيد', '8511096779', '+9668511096779', 'SA', NULL, 7035, 97, 2, NULL, NULL, NULL, '2024-01-17 09:15:20', '2024-02-09 09:30:21'),
(163, 0, 'الأستاذ نزيه غالب', '8581193475', '+208581193475', 'EG', 'إليه ابنتي وغطت وجهها وبكت.', NULL, NULL, 1, NULL, NULL, 'تريد والله على ما أقول وكيل. فاستوثق منه الجني وأطلقه فرجع إلى بلده وقضى جميع تعلقاته وأوصل الحقوق إلى أهلها وأعلم زوجته وأولاده بما جرى له فبكوا وكذلك جميع أهله ونساءه وأولاده وأوصى وقعد عندهم إلى.', '2024-01-30 15:04:24', '2024-02-09 09:30:21'),
(164, 0, 'المهندس سليمان عزيز', '7801282429', '+9737801282429', 'BH', NULL, 4393, 76, 2, NULL, NULL, NULL, '2024-02-06 23:17:22', '2024-02-09 09:30:21'),
(165, 0, 'المهندس أنس جبر', '6110396452', '+9716110396452', 'AE', NULL, 5719, 225, 3, '2024-01-27 22:39:15', '05:00 PM', NULL, '2024-01-21 22:39:15', '2024-02-09 09:30:21'),
(166, 1, 'مصطفى عز الدين', '8516027348', '+9658516027348', 'KW', NULL, 15358, 6825, 2, NULL, NULL, NULL, '2024-02-02 16:15:26', '2024-02-09 09:30:21'),
(167, 1, 'أ. شهد عبد الحميد', '6596681691', '+9716596681691', 'AE', 'عهد وميثاق أني أعود إليك.', NULL, NULL, 1, NULL, NULL, 'من أول الزمان إلى آخره. فلما سمعت أيها الجني زوجته ابنة الراعي ثم جئت أنا بعد مدة طويلة من السفر فسألت عن ولدي وعن أمه فقالت لي أن هذا العجل بين البهائم. كل ذلك جرى وابنة عمي هذه الغزالة تعلمت السحر.', '2024-02-07 22:56:12', '2024-02-09 09:30:21'),
(168, 1, 'الآنسة فدى عزام', '2473334097', '+9652473334097', 'KW', NULL, 5578, 123, 3, '2024-02-03 03:00:31', '10:00 AM', NULL, '2024-01-31 03:00:31', '2024-02-09 09:30:21'),
(169, 0, 'Rusty Quitzon', '5218726518', '+15218726518', 'US', 'The Dormouse had closed its.', NULL, NULL, 1, NULL, NULL, 'As soon as she could, and waited to see what this bottle was a queer-shaped little creature, and held out its arms folded, quietly smoking a long tail, certainly,\' said Alice to herself. \'Of the.', '2024-01-17 01:01:48', '2024-02-09 09:30:21'),
(170, 0, 'تمارا عادل سقا', '3934228601', '+9663934228601', 'SA', NULL, 5106, 116, 3, '2024-01-22 16:20:04', '01:30 PM', NULL, '2024-01-20 16:20:04', '2024-02-09 09:30:21'),
(171, 1, 'د. سما عبد الحميد', '7709433560', '+207709433560', 'EG', NULL, 28557, NULL, 2, NULL, NULL, NULL, '2024-01-08 23:29:45', '2024-02-09 09:30:21'),
(172, 0, 'د. زين مجاهد', '1427947541', '+201427947541', 'EG', NULL, 19521, 18742, 2, NULL, NULL, NULL, '2024-01-13 10:01:30', '2024-02-09 09:30:21'),
(173, 0, 'زاهر شافع', '4949634914', '+204949634914', 'EG', 'في البحر فلما استيقظت زوجتي.', NULL, NULL, 1, NULL, NULL, 'دمه وأدرك شهرزاد الصباح فسكتت عن الكلام المباح. فقالت لها أختها: يا أختي أتممي لنا حديثك فقالت حبًا وكرامة إن أذن لي الملك في ذلك فقال لها الملك: احكي فقالت: بلغني أيها الملك السعيد ذو الرأي الرشيد.', '2024-01-06 13:36:52', '2024-02-09 09:30:21'),
(174, 0, 'أ. نانسي السعيد', '9860494907', '+209860494907', 'EG', NULL, 5053472, 5051572, 2, NULL, NULL, NULL, '2024-01-08 11:18:29', '2024-02-09 09:30:21'),
(175, 0, 'Mr. Landen Stokes', '7305320480', '+17305320480', 'US', NULL, 620, 208, 3, '2024-02-06 14:17:06', '01:00 PM', NULL, '2024-01-31 14:17:06', '2024-02-09 09:30:21'),
(176, 0, 'سلمى مهران', '2890939438', '+9712890939438', 'AE', 'يد أبيك من المواشي والأموال.', NULL, NULL, 1, NULL, NULL, 'ما صنعت بك وبأمك بنت عمي فدمها لك مباح. فلما سمعت حكايتها تعجبت وشكرتها على فعلها وقلت لها أما هلاك إخوتي فلا ينبغي ثم حكيت لها ما جرى لي معهم من أول الزمان إلى آخره. فلما سمعت حكايتها تعجبت وشكرتها.', '2024-01-11 21:55:10', '2024-02-09 09:30:21'),
(177, 0, 'مياده السويلم', '3467599128', '+9713467599128', 'AE', NULL, 16305, 869, 2, NULL, NULL, NULL, '2024-02-03 00:24:02', '2024-02-09 09:30:21'),
(178, 1, 'زيد عزمي', '0694070373', '+9650694070373', 'KW', NULL, 14126, 216, 3, '2024-01-06 07:16:20', '11:30 AM', NULL, '2024-01-01 07:16:20', '2024-02-09 09:30:21'),
(179, 1, 'أ.د امين هوساوي', '8429124622', '+9718429124622', 'AE', NULL, 5053349, 5051462, 3, '2024-01-28 21:52:29', '05:00 PM', NULL, '2024-01-25 21:52:29', '2024-02-09 09:30:21'),
(180, 1, 'السيدة إيناس كاظم', '6308878450', '+9736308878450', 'BH', NULL, 155, NULL, 2, NULL, NULL, NULL, '2024-02-02 11:33:56', '2024-02-09 09:30:21'),
(181, 0, 'إنعام مكي', '8147311333', '+9658147311333', 'KW', NULL, 11500, 119, 3, '2024-01-23 08:35:23', '12:00 PM', NULL, '2024-01-18 08:35:23', '2024-02-09 09:30:21'),
(182, 1, 'د. جعفر كاظم', '6044804642', '+9656044804642', 'KW', NULL, 24878, 24813, 2, NULL, NULL, NULL, '2024-01-17 04:11:16', '2024-02-09 09:30:21'),
(183, 1, 'Ricardo Bahringer V', '1825259448', '+11825259448', 'US', NULL, 27128, 27030, 3, '2024-01-21 16:08:08', '11:00 AM', NULL, '2024-01-19 16:08:08', '2024-02-09 09:30:21'),
(184, 1, 'عدلي جبر', '1020379060', '+9651020379060', 'KW', 'الذي رأيتني فيه فتزوجت بي.', NULL, NULL, 1, NULL, NULL, 'كانت معه وتمرة فلما فرغ من حديثه اهتز الجني من الطرب ووهب له باقي دمه وأدرك شهرزاد الصباح فسكتت عن الكلام المباح. فقالت لها أختها: ما أطيب حديثك وألطفه وألذه وأعذبه فقالت: وأين هذا مما أحدثكم به.', '2024-02-05 14:11:12', '2024-02-09 09:30:21'),
(185, 1, 'أ. أنسام عبد المطلب', '7588797637', '+207588797637', 'EG', NULL, 12970, 3786, 2, NULL, NULL, NULL, '2024-02-04 04:59:44', '2024-02-09 09:30:21'),
(186, 1, 'أ. شفاء عبد المعطي', '2109859553', '+9712109859553', 'AE', NULL, 19198, 18779, 3, '2024-01-17 17:59:44', '04:00 PM', NULL, '2024-01-11 17:59:44', '2024-02-09 09:30:21'),
(187, 1, 'أريج الخالدي', '3141199161', '+9663141199161', 'SA', NULL, 5051579, NULL, 3, '2024-01-24 04:04:44', '10:00 AM', NULL, '2024-01-18 04:04:44', '2024-02-09 09:30:21'),
(188, 0, 'السيدة هدى الصقيه', '1007688833', '+9661007688833', 'SA', NULL, 4710, 57, 3, '2024-02-01 21:46:27', '01:00 PM', NULL, '2024-01-30 21:46:27', '2024-02-09 09:30:21'),
(189, 1, 'Brycen Kuphal', '9415733832', '+19415733832', 'US', 'Hatter. \'It isn\'t directed.', NULL, NULL, 1, NULL, NULL, 'How funny it\'ll seem to put it right; \'not that it would be offended again. \'Mine is a very short time the Queen had never been so much frightened that she was near enough to get through was more.', '2024-01-02 10:25:58', '2024-02-09 09:30:21'),
(190, 0, 'ربى مكي', '5808177546', '+9655808177546', 'KW', 'قلت: نعم إن عندي الإحسان.', NULL, NULL, 1, NULL, NULL, 'له: يا أخي قدر الله عز وجل فأخذتها وكسوتها وفرشت لها في المركب فرشًا حسنًا وأقبلت عليها وأكرمتها ثم سافرنا وقد أحبها قلبي محبة عظيمة وصرت لا أفارقها ليلًا ولا نهارًا أو اشتغلت بها عن إخوتي فغاروا.', '2024-01-25 15:59:33', '2024-02-09 09:30:21'),
(191, 0, 'الآنسة ضحى عبد العزيز', '5921929678', '+9735921929678', 'BH', NULL, 5053299, 5051458, 2, NULL, NULL, NULL, '2024-02-08 02:15:38', '2024-02-09 09:30:21'),
(192, 0, 'م. كرم عبد الكريم', '3845655929', '+9733845655929', 'BH', NULL, 17831, 4016, 3, '2024-02-14 11:20:30', '12:30 PM', NULL, '2024-02-08 11:20:30', '2024-02-09 09:30:21'),
(193, 1, 'الدكتورة نهاد السباعي', '0597257513', '+200597257513', 'EG', 'إني عملت حساب الدكان من بربح.', NULL, NULL, 1, NULL, NULL, 'أنه لما رأى بكاء العجل حن قلبه إليه وقال للراعي: ابق هذا العجل فإنه سمين فلم يهن علي أن أذبحه وأمرت الراعي أن يخصني ببقرة سمينة وهي سريتي التي سحرتها تلك الغزالة فشمرت ثيابي وأخذت السكين بيدي وتهيأت.', '2024-01-05 07:28:21', '2024-02-09 09:30:21'),
(194, 1, 'أ. سلطان عز الدين', '9253471139', '+9719253471139', 'AE', 'وبيده سيف فدنا من ذلك فتعجب.', NULL, NULL, 1, NULL, NULL, 'معها نحو ثلاثين سنة فلم أرزق منها بولد فأخذت لي سرية فرزقت منها بولد فأخذت لي سرية فرزقت منها بولد ذكر كأنه البدر إذا بدا بعينين مليحتين وحاجبين مزججين وأعضاء كاملة فكبر شيئًا فشيئًا إلى أن جاء عيد.', '2024-01-03 09:24:28', '2024-02-09 09:30:21'),
(195, 0, 'Nikki Ullrich', '8551212609', '+18551212609', 'US', NULL, 28687, 28180, 2, NULL, NULL, NULL, '2024-01-04 00:16:31', '2024-02-09 09:30:21'),
(196, 1, 'أ. وصفي عبد الحميد', '2578676253', '+9732578676253', 'BH', 'قال صاحب الغزالة: يا سيد.', NULL, NULL, 1, NULL, NULL, 'الصباح متعانقين فخرج الملك إلى محل حكمه ودخل عليه الوزير والعسكر واحتبك الديوان فحكم الملك وولى وعزل ونهى وأمر إلى آخر النهار ثم انفض الديوان ودخل الملك شهريار قصره. و في الليلة الثانية قالت دنيازاد.', '2024-01-06 04:52:58', '2024-02-09 09:30:21'),
(197, 0, 'المهندس فوزي عز الدين', '0014493152', '+9710014493152', 'AE', 'أملك شيئًا فأخذته وطلعت به.', NULL, NULL, 1, NULL, NULL, 'ذبحها حيث لا ينفعني الندم وأعطيتها للراعي وقلت له: ائتني بعجل سمين فأتاني بولدي المسحور عجلًا فلما رآني صاحب الدكان أخذني ودخل بي بيته فلما رأتني عجلت وقامت إلي بكوز فيه ماء وتكلمت عليه ورشت علي منه.', '2024-01-30 09:23:59', '2024-02-09 09:30:21'),
(198, 0, 'Gerry Swift IV', '8385526726', '+18385526726', 'US', 'My notion was that it was.', NULL, NULL, 1, NULL, NULL, 'Duchess, digging her sharp little chin. \'I\'ve a right to grow up again! Let me see: I\'ll give them a new idea to Alice, and she went in search of her own mind (as well as she ran. \'How surprised.', '2024-01-17 05:41:43', '2024-02-09 09:30:21'),
(199, 1, 'Ofelia Nienow', '6321049988', '+16321049988', 'US', NULL, 13260, 23, 2, NULL, NULL, NULL, '2024-01-08 20:37:34', '2024-02-09 09:30:21'),
(200, 1, 'الآنسة إكرام الأسمري', '0284683619', '+9660284683619', 'SA', NULL, 2152, 874, 3, '2024-01-13 19:11:58', '04:30 PM', NULL, '2024-01-08 19:11:58', '2024-02-09 09:30:21'),
(201, 1, 'عبد الحي الشيباني', '8977646472', '+9668977646472', 'SA', NULL, 13804, 80, 2, NULL, NULL, NULL, '2024-01-18 10:12:19', '2024-02-09 09:30:21'),
(202, 0, 'الآنسة مها عبد الحليم', '5505224369', '+9715505224369', 'AE', NULL, 28222, 2159, 2, NULL, NULL, NULL, '2024-01-07 18:12:17', '2024-02-09 09:30:21'),
(203, 1, 'لمى مجاهد', '2460463431', '+9652460463431', 'KW', NULL, 10034, 2987, 3, '2024-01-17 23:11:46', '01:30 PM', NULL, '2024-01-15 23:11:46', '2024-02-09 09:30:21'),
(204, 0, 'عوني حارث', '2102433688', '+9712102433688', 'AE', 'كانت زوجتي سافرت وغبت عنها.', NULL, NULL, 1, NULL, NULL, 'وقلت له: يا أخي أما أشرت عليك بعدم السفر فبكى وقال: يا أخي أما أشرت عليك بعدم السفر فبكى وقال: يا أخي قدر الله عز وجل علي بهذا ولم يبق لهذا الكلام فائدة ولست أملك شيئًا فأخذته وطلعت به إلى الحمام.', '2024-01-07 16:01:45', '2024-02-09 09:30:21'),
(205, 0, 'أ. يامن السباعي', '1079020395', '+9711079020395', 'AE', 'الجان كل ذلك والجني يتعجب من.', NULL, NULL, 1, NULL, NULL, 'يهن علي أن أذبحه وأمرت الراعي أن يخصني ببقرة سمينة وهي سريتي التي سحرتها تلك الغزالة فشمرت ثيابي وأخذت السكين بيدي وتهيأت لذبحها فصاحت وبكت بكاء شديدًا فقمت عنها وأمرت ذلك الراعي بذبحها وسلخها فلم.', '2024-01-12 17:13:52', '2024-02-09 09:30:21'),
(206, 1, 'زكريا نجيب', '2254333367', '+9712254333367', 'AE', NULL, 25059, 24823, 2, NULL, NULL, NULL, '2024-01-02 00:17:13', '2024-02-09 09:30:21'),
(207, 1, 'د. طه فواز', '3452110879', '+203452110879', 'EG', 'علي وقال: يا أخي إني أحسب.', NULL, NULL, 1, NULL, NULL, 'مقطع فقبلت يدي وقالت: يا سيدي إيه ابنك وحشاشة كبدك فقلت لها: وأين الرجال الأجانب ولماذا بكيت وضحكت فقالت لي أن هذا العجل الذي معك ابن سيدي التاجر ولكنه مسحور وسحرته زوجة أبيه هو وأمه فهذا سبب ضحكي.', '2024-01-11 15:05:56', '2024-02-09 09:30:21'),
(208, 0, 'د. زين عبد الحليم', '9987373965', '+9739987373965', 'BH', NULL, 16082, NULL, 3, '2024-02-03 09:55:17', '11:00 AM', NULL, '2024-01-29 09:55:17', '2024-02-09 09:30:21'),
(209, 1, 'Miguel Heller', '1836415224', '+11836415224', 'US', NULL, 27883, 27549, 3, '2024-01-25 17:03:53', '04:00 PM', NULL, '2024-01-23 17:03:53', '2024-02-09 09:30:21'),
(210, 1, 'الآنسة لينة رسلان', '7201786792', '+9657201786792', 'KW', NULL, 5054088, 5053797, 3, '2024-01-15 23:57:46', '03:30 PM', NULL, '2024-01-13 23:57:46', '2024-02-09 09:30:21'),
(211, 1, 'م. عهد عبد المهيمن', '4869017483', '+9654869017483', 'KW', NULL, 26583, 25704, 3, '2024-01-21 11:35:25', '11:00 AM', NULL, '2024-01-16 11:35:25', '2024-02-09 09:30:21'),
(212, 0, 'صفاء عبد الحميد', '3482721295', '+203482721295', 'EG', NULL, 10827, 4059, 3, '2024-01-11 16:09:46', '02:30 PM', NULL, '2024-01-09 16:09:46', '2024-02-09 09:30:21'),
(213, 0, 'Myron Gislason', '7520068174', '+17520068174', 'US', NULL, 30198, 28079, 2, NULL, NULL, NULL, '2024-02-06 11:34:34', '2024-02-09 09:30:21'),
(214, 0, 'المهندسة أروى السماري', '9565099911', '+9669565099911', 'SA', NULL, 5267, 38, 3, '2024-02-14 11:03:04', '03:00 PM', NULL, '2024-02-08 11:03:04', '2024-02-09 09:30:21'),
(215, 0, 'أ. فارس عبد الهادي', '0799852707', '+9650799852707', 'KW', 'ذبحها حيث لا ينفعني الندم.', NULL, NULL, 1, NULL, NULL, 'عليهما ولا يغرنك حالي. فلما سمعت كلامي قالت: أنا في هذه الليلة أطير إليهم وأغرق مراكبهم وأهلكهم فقلت لها: بالله لا تفعلي فإن صاحب المثل يقول: يا محسنًا لمن أساء كفي المسيء فعله وهم إخوتي على كل حال.', '2024-01-25 03:39:08', '2024-02-09 09:30:21'),
(216, 1, 'Raleigh Wiegand', '7359509198', '+17359509198', 'US', 'Dodo. Then they both cried.', NULL, NULL, 1, NULL, NULL, 'Then followed the Knave of Hearts, who only bowed and smiled in reply. \'Please come back with the glass table and the soldiers did. After these came the royal children, and everybody laughed, \'Let.', '2024-01-10 10:55:32', '2024-02-09 09:30:21'),
(217, 1, 'Mr. Brian Kozey', '2836577179', '+12836577179', 'US', 'However, this bottle does. I.', NULL, NULL, 1, NULL, NULL, 'Don\'t let me hear the Rabbit say, \'A barrowful of WHAT?\' thought Alice to herself. \'I dare say you never tasted an egg!\' \'I HAVE tasted eggs, certainly,\' said Alice, rather alarmed at the mushroom.', '2024-01-16 03:12:32', '2024-02-09 09:30:21'),
(218, 0, 'داوود عبد اللطيف', '3687692011', '+9733687692011', 'BH', NULL, 7335, 185, 3, '2024-02-11 02:54:19', '01:00 PM', NULL, '2024-02-06 02:54:19', '2024-02-09 09:30:21'),
(219, 1, 'زيدان عبد العزيز', '8983413103', '+9738983413103', 'BH', NULL, 9321, 48, 3, '2024-01-26 10:52:54', '10:30 AM', NULL, '2024-01-23 10:52:54', '2024-02-09 09:30:21'),
(220, 0, 'أ.د وائل صدام', '4817965183', '+9734817965183', 'BH', NULL, 20659, NULL, 3, '2024-01-23 09:36:14', '11:30 AM', NULL, '2024-01-21 09:36:14', '2024-02-09 09:30:21'),
(221, 1, 'Selmer Luettgen Sr.', '2256404060', '+12256404060', 'US', NULL, 24151, 23573, 3, '2024-01-12 05:16:56', '04:30 PM', NULL, '2024-01-08 05:16:56', '2024-02-09 09:30:21'),
(222, 0, 'مصطفى كاظم', '7238573667', '+9717238573667', 'AE', 'فوجدتها نائمة فرششت عليها.', NULL, NULL, 1, NULL, NULL, 'وقال له: اعلم يا سيد ملوك الجان كل ذلك جرى وابنة عمي هذه الغزالة ورأيتها عجيبة أتهب لي ثلث دم هذا التاجر قال: نعم. يا أيها العفريت أن هذه الغزالة ورأيتها عجيبة أتهب لي ثلث دم هذا التاجر قال: نعم. يا.', '2024-01-08 20:57:14', '2024-02-09 09:30:21'),
(223, 0, 'زهرة عزيز', '2127153660', '+9732127153660', 'BH', NULL, 27760, 27557, 2, NULL, NULL, NULL, '2024-01-10 22:47:48', '2024-02-09 09:30:21');
INSERT INTO `leads_contact_us` (`id`, `export`, `name`, `phone`, `full_number`, `country`, `subject`, `listing_id`, `project_id`, `request_type`, `meeting_day`, `meeting_time`, `message`, `created_at`, `updated_at`) VALUES
(224, 0, 'Lewis Harris Sr.', '8407675299', '+18407675299', 'US', 'Queen, and in despair she.', NULL, NULL, 1, NULL, NULL, 'I almost wish I hadn\'t gone down that rabbit-hole--and yet--and yet--it\'s rather curious, you know, this sort in her face, and was just in time to hear it say, as it was indeed: she was quite out of.', '2024-01-02 10:52:29', '2024-02-09 09:30:21'),
(225, 1, 'م. حافظ عمران', '5862642708', '+9715862642708', 'AE', NULL, 19668, NULL, 3, '2024-01-17 11:07:40', '11:00 AM', NULL, '2024-01-13 11:07:40', '2024-02-09 09:30:21'),
(226, 0, 'م. مسعد عبد المطلب', '2890000564', '+9712890000564', 'AE', NULL, 16610, 66, 2, NULL, NULL, NULL, '2024-01-12 20:39:27', '2024-02-09 09:30:21'),
(227, 0, 'الدكتورة ساجدة عبد المعطي', '7746114334', '+207746114334', 'EG', 'اخرجي من هذه الصورة إلى صورة.', NULL, NULL, 1, NULL, NULL, 'وهبت لك ثلث دمه فقال ذلك الشيخ الأول: اتعلم يا أيها الشيخ إذا أنت حكيت لي الحكاية ورأيتها عجيبة أتهب لي ثلث دم هذا التاجر قال: نعم. يا أيها الجني كلام هذا الراعي خرجت معه وأنا سكران من غير مدام من.', '2024-01-08 06:20:21', '2024-02-09 09:30:21'),
(228, 0, 'د. حسن طلال', '7479616875', '+9657479616875', 'KW', NULL, 8241, 4047, 3, '2024-01-12 05:20:03', '03:30 PM', NULL, '2024-01-10 05:20:03', '2024-02-09 09:30:21'),
(229, 1, 'ميساء طلال', '7275819621', '+9737275819621', 'BH', 'بتجارته وغاب عنا مدة سنة مع.', NULL, NULL, 1, NULL, NULL, 'كوزًا فيه ماء فتكلمت عليه ورشتني وقالت اخرج من هذه الصورة إلى صورتك الأولى فصرت إلى صورتي الأولى فقبلت يدها وقلت لها: أريد أن تسحري زوجتي كما سحرتني فأعطتني قليلًا من الماء وقالت إذا رأيتها نائمة.', '2024-01-03 20:27:03', '2024-02-09 09:30:21'),
(230, 0, 'الآنسة أمينة كاظم', '2262916666', '+9712262916666', 'AE', NULL, 21613, 20061, 2, NULL, NULL, NULL, '2024-01-01 15:15:49', '2024-02-09 09:30:21'),
(231, 0, 'عفاف جمال الدين', '5708852740', '+9735708852740', 'BH', 'التاجر والجني. قالت حبًا.', NULL, NULL, 1, NULL, NULL, 'سنة كاملة وهم يعرضون علي السفر وأنا لم أرض حتى مضت ست سنوات كوامل. ثم وافقتهم على السفر وقلت لهم: يا أخوتي إننا نحسب ما عندنا من المال فحسبناه فإذا هو ستة آلاف دينار ففتحت دكانًا أبيع فيه وأشتري.', '2024-02-06 09:44:45', '2024-02-09 09:30:21'),
(232, 1, 'Valentine Keeling', '9842162248', '+19842162248', 'US', NULL, 19121, NULL, 2, NULL, NULL, NULL, '2024-01-07 23:42:08', '2024-02-09 09:30:21'),
(233, 0, 'الآنسة دارين عبد الوهاب', '1535562518', '+9651535562518', 'KW', NULL, 26711, 25723, 2, NULL, NULL, NULL, '2024-01-28 09:35:34', '2024-02-09 09:30:21'),
(234, 0, 'م. نورا السعيد', '9240772069', '+9719240772069', 'AE', 'عنها وأمرت ذلك الراعي بذبحها.', NULL, NULL, 1, NULL, NULL, 'أردنا السفر فوجدنا على شاطئ البحر جارية عليها خلق مقطع فقبلت يدي وقالت: يا سيدي هل عندك إحسان ومعروف أجازيك عليهما قلت: نعم إن عندي الإحسان والمعروف ولو لم تجازيني فقالت: يا سيدي تزوجني وخذني إلى.', '2024-01-13 21:06:43', '2024-02-09 09:30:21'),
(235, 1, 'الدكتورة آية عزيز', '2498470415', '+9652498470415', 'KW', 'هذا الحال فرأيت هذا الفتى.', NULL, NULL, 1, NULL, NULL, 'بين البهائم. كل ذلك جرى وابنة عمي هذه الغزالة وجئت إلى هنا فرأيت هؤلاء الجماعة فسألتهم عن حالهم فأخبروني بما جرى له فبكوا وكذلك جميع أهله ونساءه وأولاده وأوصى وقعد عندهم إلى تمام السنة ثم توجه وأخذ.', '2024-01-22 03:42:15', '2024-02-09 09:30:21'),
(236, 1, 'آيات اثير الحسين', '4484891277', '+9664484891277', 'SA', NULL, 10049, 4068, 3, '2024-01-29 10:38:38', '04:30 PM', NULL, '2024-01-25 10:38:38', '2024-02-09 09:30:21'),
(237, 0, 'أ. مروان عبد الرحيم', '5764294270', '+9715764294270', 'AE', 'فلما رآني صاحب الدكان أخذني.', NULL, NULL, 1, NULL, NULL, 'الراعي: أحق ما تقولينه عن ذلك العجل قطع حبله وجاءني وتمرغ علي وولول وبكى فأخذتني الرأفة عليه وقلت للراعي ائتني ببقرة ودع هذا. وأدرك شهرزاد الصباح فسكتت عن الكلام المباح. فقالت لها أختها: يا أختي.', '2024-01-29 22:44:07', '2024-02-09 09:30:21'),
(238, 0, 'د. دعاء عز العرب', '5699881817', '+9655699881817', 'KW', NULL, 1699, 1135, 3, '2024-01-26 22:04:02', '12:00 PM', NULL, '2024-01-23 22:04:02', '2024-02-09 09:30:21'),
(239, 1, 'السيد عزت عزمي', '7857120667', '+9717857120667', 'AE', NULL, 28656, NULL, 2, NULL, NULL, NULL, '2024-01-25 22:02:40', '2024-02-09 09:30:21'),
(240, 0, 'Leatha Goyette MD', '5022781863', '+15022781863', 'US', 'Alice was a little pattering.', NULL, NULL, 1, NULL, NULL, 'Alice very humbly: \'you had got so much contradicted in her own children. \'How should I know?\' said Alice, and she was appealed to by all three to settle the question, and they walked off together.', '2024-01-02 07:01:09', '2024-02-09 09:30:21'),
(241, 1, 'د. هلال عمران', '1791630294', '+201791630294', 'EG', NULL, 6497, 152, 2, NULL, NULL, NULL, '2024-01-26 15:46:32', '2024-02-09 09:30:21'),
(242, 0, 'أ.د شاكر جبر', '6904793813', '+206904793813', 'EG', NULL, 7785, 145, 3, '2024-01-06 07:27:01', '12:30 PM', NULL, '2024-01-01 07:27:01', '2024-02-09 09:30:21'),
(243, 0, 'دانة اياس أنور هوساوي', '1582586411', '+9661582586411', 'SA', NULL, 17885, 108, 2, NULL, NULL, NULL, '2024-01-16 17:48:37', '2024-02-09 09:30:21'),
(244, 0, 'السيد بسام عبد الهادي', '6784890459', '+9656784890459', 'KW', 'بولدي المسحور عجلًا فلما.', NULL, NULL, 1, NULL, NULL, 'قالت: أنا في هذه الليلة أطير إليهم وأغرق مراكبهم وأهلكهم فقلت لها: بالله لا تفعلي فإن صاحب المثل يقول: يا محسنًا لمن أساء كفي المسيء فعله وهم إخوتي على كل حال قالت لا بد من قتلهم فاستعطفتها ثم أنها.', '2024-02-04 12:13:50', '2024-02-09 09:30:21'),
(245, 0, 'الدكتورة مشيرة مهران', '2554023280', '+9652554023280', 'KW', NULL, 14825, 931, 3, '2024-01-10 02:45:29', '02:00 PM', NULL, '2024-01-05 02:45:29', '2024-02-09 09:30:21'),
(246, 1, 'م. سجى عبد العزيز', '3297457586', '+203297457586', 'EG', NULL, 7580, 1040, 3, '2024-02-12 04:04:02', '11:30 AM', NULL, '2024-02-06 04:04:02', '2024-02-09 09:30:21'),
(247, 0, 'أمينة عبد الوهاب', '9843092275', '+9659843092275', 'KW', NULL, 4486, 209, 2, NULL, NULL, NULL, '2024-01-22 03:07:14', '2024-02-09 09:30:21'),
(248, 1, 'عمار عبد الرحيم', '9035771012', '+9739035771012', 'BH', NULL, 18001, 29, 2, NULL, NULL, NULL, '2024-02-06 18:38:48', '2024-02-09 09:30:21'),
(249, 0, 'المهندس لؤي عبد المطلب', '4443004663', '+204443004663', 'EG', NULL, 18737, NULL, 3, '2024-02-14 04:42:35', '01:30 PM', NULL, '2024-02-08 04:42:35', '2024-02-09 09:30:21'),
(250, 1, 'Helga Pagac Jr.', '9310615338', '+19310615338', 'US', NULL, 26740, 25966, 2, NULL, NULL, NULL, '2024-01-15 20:44:38', '2024-02-09 09:30:21'),
(251, 1, 'Wava Keeling I', '7068060402', '+17068060402', 'US', NULL, 2538, 29, 3, '2024-01-28 08:53:37', '03:00 PM', NULL, '2024-01-25 08:53:37', '2024-02-09 09:30:21'),
(252, 1, 'Deon Gibson', '2213041097', '+12213041097', 'US', NULL, 5052550, 5051119, 3, '2024-01-12 04:18:35', '03:30 PM', NULL, '2024-01-10 04:18:35', '2024-02-09 09:30:21'),
(253, 1, 'رغد غانم ربيع السهلي', '2736567492', '+9662736567492', 'SA', NULL, 6372, 1133, 2, NULL, NULL, NULL, '2024-01-30 15:38:56', '2024-02-09 09:30:21'),
(254, 1, 'الأستاذ رزق عبد الله', '6384462252', '+9716384462252', 'AE', 'ما جرى لي معهم من أول الزمان.', NULL, NULL, 1, NULL, NULL, 'عليها فنظرت إليه ابنتي وغطت وجهها وبكت ثم إنها ضحكت وقالت: يا أبي قد خس قدري عندك حتى تدخل علي الرجال الأجانب. فقلت لها: وأين الرجال الأجانب ولماذا بكيت وضحكت فقالت لي أن هذا العجل فإنه سمين فلم يهن.', '2024-01-26 23:53:34', '2024-02-09 09:30:21'),
(255, 1, 'الدكتور نبيل عبد العزيز', '5986341203', '+205986341203', 'EG', NULL, 23446, 20629, 2, NULL, NULL, NULL, '2024-01-07 18:28:48', '2024-02-09 09:30:21'),
(256, 0, 'السيدة فاطمة فواز', '8950428694', '+9718950428694', 'AE', NULL, 24148, NULL, 2, NULL, NULL, NULL, '2024-01-29 05:08:16', '2024-02-09 09:30:21'),
(257, 0, 'ميرال عمران', '2248034352', '+9732248034352', 'BH', NULL, 8720, 2169, 2, NULL, NULL, NULL, '2024-02-04 20:48:05', '2024-02-09 09:30:21'),
(258, 0, 'Miss Zora McKenzie Sr.', '3527677359', '+13527677359', 'US', NULL, 1591, 120, 2, NULL, NULL, NULL, '2024-02-08 09:01:53', '2024-02-09 09:30:21'),
(259, 1, 'زينات عبد ربه العنزي', '9354578257', '+9669354578257', 'SA', 'أن يوجد له ضد أكثر، وكانت.', NULL, NULL, 1, NULL, NULL, 'أسال والإقبال على الدنيا، وحذرهم عنه غاية التحذير، وعلم هو وصاحبه أسال أن تلك الآراء هي الأسرار المضنون بها على غير شكل الكرة لكانت لا محالة قادر عليه وعالم به \"بسم الله الرحمن الرحيم\" أعطى كل شيء.', '2024-01-21 15:33:49', '2024-02-09 09:30:21'),
(260, 0, 'رنين عبد الرزاق', '1777689695', '+201777689695', 'EG', NULL, 25601, 25013, 2, NULL, NULL, NULL, '2024-01-09 21:12:15', '2024-02-09 09:30:21'),
(261, 0, 'معتصم فواز', '0523810297', '+9650523810297', 'KW', NULL, 23036, NULL, 3, '2024-01-22 05:12:36', '02:30 PM', NULL, '2024-01-16 05:12:36', '2024-02-09 09:30:21'),
(262, 1, 'أ. زياد رجائي', '9502648653', '+209502648653', 'EG', NULL, 21743, 21318, 3, '2024-01-16 02:42:16', '01:00 PM', NULL, '2024-01-11 02:42:16', '2024-02-09 09:30:21'),
(263, 0, 'الأستاذ خالد هوساوي', '6910027343', '+9656910027343', 'KW', NULL, 5050827, 5050704, 2, NULL, NULL, NULL, '2024-01-22 15:20:32', '2024-02-09 09:30:21'),
(264, 0, 'أ.د فارس صدام', '8050339116', '+9718050339116', 'AE', NULL, 25032, 24832, 2, NULL, NULL, NULL, '2024-01-07 13:05:45', '2024-02-09 09:30:21'),
(265, 1, 'المهندس اسحاق كاظم', '1514172994', '+9731514172994', 'BH', NULL, 19367, NULL, 2, NULL, NULL, NULL, '2024-01-26 20:21:11', '2024-02-09 09:30:21'),
(266, 0, 'المهندس مامون عبد المعطي', '4974779126', '+9734974779126', 'BH', NULL, 10281, 212, 2, NULL, NULL, NULL, '2024-01-24 15:14:01', '2024-02-09 09:30:21'),
(267, 1, 'أمين السعيد', '0298941607', '+9660298941607', 'SA', NULL, 5442, 4, 2, NULL, NULL, NULL, '2024-01-14 17:03:09', '2024-02-09 09:30:21'),
(268, 1, 'سمعان عبد القادر', '1893717341', '+201893717341', 'EG', NULL, 17886, 868, 3, '2024-01-12 01:25:22', '11:30 AM', NULL, '2024-01-08 01:25:22', '2024-02-09 09:30:21'),
(269, 0, 'م. سجى غانم', '8036060498', '+9738036060498', 'BH', NULL, 28839, 28381, 2, NULL, NULL, NULL, '2024-01-17 19:33:14', '2024-02-09 09:30:21'),
(270, 1, 'روزان السمير', '4454905889', '+9664454905889', 'SA', NULL, 12713, 868, 2, NULL, NULL, NULL, '2024-01-17 00:34:01', '2024-02-09 09:30:21'),
(271, 0, 'رهف عزمي', '3762142766', '+9653762142766', 'KW', 'فلما فرغ من حديثه اهتز الجني.', NULL, NULL, 1, NULL, NULL, 'فيها فلما رأياني قاما إلي وبكيا وتعلقا بي فلم أشعر إلا وزوجتي قالت هؤلاء إخوتك فقلت من فعل بهم هذا الفعل قالت أنا أرسلت إلى أختي ففعلت بهم ذلك وما يتخلصون إلا بعد عشر سنوات فجئت وأنا سائر إليها.', '2024-01-13 04:19:22', '2024-02-09 09:30:21'),
(272, 1, 'السيدة هيلين عبد الفتاح', '3949221366', '+9713949221366', 'AE', NULL, 18558, 97, 3, '2024-01-10 12:49:47', '05:00 PM', NULL, '2024-01-04 12:49:47', '2024-02-09 09:30:21'),
(273, 1, 'د. شادي فواز', '9562178944', '+9719562178944', 'AE', NULL, 16757, 4754, 2, NULL, NULL, NULL, '2024-01-16 11:10:00', '2024-02-09 09:30:21'),
(274, 0, 'Dr. Robbie Kunze', '4865802527', '+14865802527', 'US', NULL, 24540, 23765, 3, '2024-01-14 05:00:47', '04:00 PM', NULL, '2024-01-09 05:00:47', '2024-02-09 09:30:21'),
(275, 1, 'عصام عبد المهيمن', '3989756341', '+9713989756341', 'AE', NULL, 19400, 18782, 2, NULL, NULL, NULL, '2024-01-29 06:45:49', '2024-02-09 09:30:21'),
(276, 0, 'م. رشاد عبد القادر', '4254965371', '+9734254965371', 'BH', NULL, 5051984, 5050837, 2, NULL, NULL, NULL, '2024-02-03 02:14:31', '2024-02-09 09:30:21'),
(277, 0, 'Dr. Myrtis Kozey Jr.', '9660616469', '+19660616469', 'US', NULL, 16973, 161, 3, '2024-02-07 22:45:43', '12:30 PM', NULL, '2024-02-01 22:45:43', '2024-02-09 09:30:21'),
(278, 1, 'Mitchel Jerde', '4650629570', '+14650629570', 'US', NULL, 15127, 84, 3, '2024-01-23 19:41:49', '12:00 PM', NULL, '2024-01-19 19:41:49', '2024-02-09 09:30:21'),
(279, 0, 'رنا الشهيل', '2745291251', '+9662745291251', 'SA', NULL, 19083, NULL, 3, '2024-01-03 00:03:14', '12:00 PM', NULL, '2024-01-01 00:03:14', '2024-02-09 09:30:21'),
(280, 1, 'السيدة اسراء عبد السلام', '6492391003', '+9656492391003', 'KW', 'فقبلت يدي وقالت: يا أبي قد.', NULL, NULL, 1, NULL, NULL, 'جرى وابنة عمي هذه الغزالة ورأيتها عجيبة وهبت لك ثلث دمه فعند ذلك تقدم الشيخ صاحب الكلبتين السلاقيتين وقال له: قم حتى أقتلك مثل ما قتلت ولدي فقال له التاجر: كيف قتلت ولدك قال له: لما أكلت التمرة.', '2024-02-03 00:51:14', '2024-02-09 09:30:21'),
(281, 0, 'أ. إيناس الداوود', '0032119704', '+9710032119704', 'AE', NULL, 17936, 4051, 3, '2024-02-09 22:25:26', '03:30 PM', NULL, '2024-02-03 22:25:26', '2024-02-09 09:30:21'),
(282, 0, 'ميادة كاظم', '6383061044', '+206383061044', 'EG', 'بشرطين: الأول: أن تزوجني به.', NULL, NULL, 1, NULL, NULL, 'وشكرهم هنوه بالسلامة ورجع كل واحد إلى بلده وقضى جميع تعلقاته وأوصل الحقوق إلى أهلها وأعلم زوجته وأولاده بما جرى له مع ذلك العفريت وقال له: يا أيها الشيخ إذا أنت حكيت لي الحكاية ورأيتها عجيبة وهبت لك.', '2024-01-02 12:35:04', '2024-02-09 09:30:21'),
(283, 1, 'السيد عبيدة غانم', '4877385497', '+9734877385497', 'BH', NULL, 5054071, 5053788, 2, NULL, NULL, NULL, '2024-01-18 22:42:13', '2024-02-09 09:30:21'),
(284, 0, 'السيد هلال عمران', '6055713667', '+206055713667', 'EG', 'كنت مسحورًا فعد إلى خلقتك.', NULL, NULL, 1, NULL, NULL, 'ما تريد والله على ما أقول وكيل. فاستوثق منه الجني وأطلقه فرجع إلى بلده وقضى جميع تعلقاته وأوصل الحقوق إلى أهلها وأعلم زوجته وأولاده بما جرى لهذا التاجر فجلست لأنظر ما يكون وهذا حديثي فقال الجني: هذا.', '2024-01-07 16:10:00', '2024-02-09 09:30:21'),
(285, 1, 'الأستاذ زاهي الكفراوي', '6921200713', '+9716921200713', 'AE', NULL, 5052619, 5051125, 2, NULL, NULL, NULL, '2024-02-05 06:55:47', '2024-02-09 09:30:21'),
(286, 0, 'رائف محسن الشهري', '5082915834', '+9665082915834', 'SA', NULL, 9604, 3898, 3, '2024-01-11 02:15:51', '10:00 AM', NULL, '2024-01-05 02:15:51', '2024-02-09 09:30:21'),
(287, 1, 'الدكتور عدنان السعيد', '2473740495', '+202473740495', 'EG', NULL, 7091, 73, 3, '2024-01-08 01:49:15', '02:30 PM', NULL, '2024-01-06 01:49:15', '2024-02-09 09:30:21'),
(288, 0, 'الدكتورة هيفا السعيد', '8825574212', '+9658825574212', 'KW', 'بإذن الله تعالى واعلم أني.', NULL, NULL, 1, NULL, NULL, 'ذهبت به إلى الدكان ثم ذهبت به إلى الحمام وألبسته حلة من الملابس الفاخرة وأكلت أنا وإياه وقلت له: بالله عليك يا بنتي خلصيه فأخذت كوزًا فيه ماء وتكلمت عليه ورشت علي منه قليلًا وقالت: اخرج من هذه.', '2024-01-13 07:50:45', '2024-02-09 09:30:21'),
(289, 0, 'الدكتورة ليان الداوود', '4728725224', '+9714728725224', 'AE', 'عندك حتى تدخل علي الرجال.', NULL, NULL, 1, NULL, NULL, 'كاملة ثم قضيت سفري وجئت إليها في الليل فرأيت عبد أسود راقد معها في الفراش وهما في كلام وغنج وضحك وتقبيل وهراش فلما رأتني بنت الجزار غطت وجهها مني فقالت أتجيء لنا برجل وتدخل علينا به فقال أبوها أين.', '2024-01-23 23:59:16', '2024-02-09 09:30:21'),
(290, 1, 'فدوى حارث', '5579789767', '+9655579789767', 'KW', 'فقال ذلك الشيخ الأول: اتعلم.', NULL, NULL, 1, NULL, NULL, 'الأول: أن تزوجني به والثاني: أن أسر من سحرته وأحبسها وإلا فلست آمن مكرها فلما سمعت حكايتها تعجبت وشكرتها على فعلها وقلت لها أما هلاك إخوتي فلا ينبغي ثم حكيت لها ما جرى لهما فقلت: يا ولدي قد قيض الله.', '2024-01-02 17:16:04', '2024-02-09 09:30:21'),
(291, 0, 'أ.د ريان عبد الرحيم', '0923557013', '+9650923557013', 'KW', 'اقرأو الكتب فالكتب مشوقة و.', NULL, NULL, 1, NULL, NULL, 'زيادة وأما بنت عمي فدمها لك مباح. فلما سمعت أيها الجني كلام هذا الراعي خرجت معه وأنا سكران من غير مدام من كثرة الفرح والسرور والذي حصل لي إلى أن صار ابن خمس عشرة سنة فطرأت لي سفرة إلى بعض المدن.', '2024-02-06 11:54:22', '2024-02-09 09:30:21'),
(292, 0, 'المهندسة إنعام الحميد', '9087371217', '+9669087371217', 'SA', NULL, 26104, 25487, 2, NULL, NULL, NULL, '2024-01-19 09:20:49', '2024-02-09 09:30:21'),
(293, 1, 'د. نسرين الصعيدي', '8122135140', '+9658122135140', 'KW', NULL, 21083, 20631, 3, '2024-02-03 00:44:42', '02:00 PM', NULL, '2024-01-29 00:44:42', '2024-02-09 09:30:21'),
(294, 1, 'سوزان عبد العزيز', '8870143000', '+9718870143000', 'AE', NULL, 11467, 931, 3, '2024-02-09 22:26:02', '11:30 AM', NULL, '2024-02-05 22:26:02', '2024-02-09 09:30:21'),
(295, 0, 'د. مديحة عبد الكريم', '4392777830', '+9734392777830', 'BH', NULL, 14352, 81, 3, '2024-01-09 21:39:27', '01:30 PM', NULL, '2024-01-03 21:39:27', '2024-02-09 09:30:21'),
(296, 1, 'مها عبد الهادي', '2004268451', '+202004268451', 'EG', 'الصباح حتى جئت إليك لأعلمك.', NULL, NULL, 1, NULL, NULL, 'مزججين وأعضاء كاملة فكبر شيئًا فشيئًا إلى أن صار ابن خمس عشرة سنة فطرأت لي سفرة إلى بعض المدن فسافرت بمتجر عظيم وكانت بنت عمي ومن لحمي ودمي وكنت تزوجت بها وهي صغيرة السن وأقمت معها نحو ثلاثين سنة.', '2024-01-20 03:34:23', '2024-02-09 09:30:21'),
(297, 0, 'دينا عبد الرحمن', '1043629250', '+9651043629250', 'KW', 'فيه فتزوجت بي وها أنا قد.', NULL, NULL, 1, NULL, NULL, 'وهذا حديثي فقال الجني: هذا حديث عجيب وقد وهبت لك ثلث دمه فقال ذلك الشيخ الأول: اتعلم يا أيها الجني وتاج ملوك الجن إذا حكيت لك حكايتي مع هذه الغزالة هي بنت عمي ومن لحمي ودمي وكنت تزوجت بها وهي صغيرة.', '2024-01-24 14:40:23', '2024-02-09 09:30:21'),
(298, 0, 'السيدة فايزة حارث', '7646498697', '+9737646498697', 'BH', 'تعالى وإذا به انتفض ثم صار.', NULL, NULL, 1, NULL, NULL, 'فيه وأشتري وسافر أخي بتجارته وغاب عنا مدة سنة مع القوافل ثم أتى وما معه شيء فقلت له: يا أخي أما أشرت عليك بعدم السفر فبكى وقال: يا أخي قدر الله عز وجل علي بهذا ولم يبق لهذا الكلام فائدة ولست أملك.', '2024-01-14 17:14:33', '2024-02-09 09:30:21'),
(299, 0, 'Kyle Koelpin', '4730508944', '+14730508944', 'US', NULL, 17753, 4016, 3, '2024-02-05 19:19:15', '02:00 PM', NULL, '2024-01-31 19:19:15', '2024-02-09 09:30:21'),
(300, 0, 'الدكتورة أصاله عبد القادر', '5908489263', '+9715908489263', 'AE', 'فلما فرغ من حديثه اهتز الجني.', NULL, NULL, 1, NULL, NULL, 'إليها تخلصهم بعد إقامتهم عشر سنوات في هذا المكان وأنت منفرد وهو مأوى الجن فأخبره التاجر بما جرى لهذا التاجر فجلست لأنظر ما يكون وهذا حديثي فقال الجني: هذا حديث عجيب وقد وهبت لك ثلث دمه فعند ذلك تقدم.', '2024-01-25 21:48:20', '2024-02-09 09:30:21'),
(301, 0, 'م. عائشة السباعي', '6414999719', '+9736414999719', 'BH', NULL, 22015, 21363, 2, NULL, NULL, NULL, '2024-01-09 11:47:09', '2024-02-09 09:30:21'),
(302, 0, 'المهندسة عبلة عبد الجليل', '5714961008', '+9735714961008', 'BH', NULL, 5052641, 5051128, 2, NULL, NULL, NULL, '2024-01-28 16:09:31', '2024-02-09 09:30:21'),
(303, 1, 'د. أسعد فواز', '6282850284', '+9736282850284', 'BH', NULL, 224, NULL, 3, '2024-02-09 23:46:06', '02:30 PM', NULL, '2024-02-05 23:46:06', '2024-02-09 09:30:21'),
(304, 0, 'أنس عبد المجيد', '4543642773', '+204543642773', 'EG', 'في الحال كلبًا فطردتني من.', NULL, NULL, 1, NULL, NULL, 'فاستعطفتها ثم أنها عزمت عليها ورشت بها العجل وقالت: إن كان الله خلقك عجلًا فدم على هذه الصفة ولا تتغير وإن كنت مسحورًا فعد إلى خلقتك الأولى بإذن الله تعالى وإذا به انتفض ثم صار إنسانًا فوقعت عليه.', '2024-01-27 06:38:30', '2024-02-09 09:30:21'),
(305, 0, 'أ. هدى عبد السلام', '1133716415', '+201133716415', 'EG', NULL, 19114, NULL, 3, '2024-01-22 13:41:02', '01:30 PM', NULL, '2024-01-19 13:41:02', '2024-02-09 09:30:21'),
(306, 1, 'الأستاذ جمال عبد الله', '6426971183', '+9656426971183', 'KW', 'عنها سنة كاملة وهم يعرضون.', NULL, NULL, 1, NULL, NULL, 'الرجال الأجانب ولماذا بكيت وضحكت فقالت لي أن هذا العجل فإنه سمين فلم يهن علي أن أذبحه وأمرت الراعي أن يخصني ببقرة سمينة وهي سريتي التي سحرتها تلك الغزالة فشمرت ثيابي وأخذت السكين بيدي وتهيأت لذبحها.', '2024-01-02 19:25:39', '2024-02-09 09:30:21'),
(307, 0, 'سهر رافي الصقيه', '2400839871', '+9662400839871', 'SA', NULL, 24516, 23670, 2, NULL, NULL, NULL, '2024-01-12 07:05:50', '2024-02-09 09:30:21'),
(308, 0, 'رقية سقا', '2467395712', '+9662467395712', 'SA', NULL, 24201, 23575, 3, '2024-01-26 10:32:37', '03:30 PM', NULL, '2024-01-22 10:32:37', '2024-02-09 09:30:21'),
(309, 0, 'الأستاذ رياض عبد الله', '8190749330', '+9718190749330', 'AE', NULL, 5051203, NULL, 3, '2024-01-14 14:34:54', '04:30 PM', NULL, '2024-01-08 14:34:54', '2024-02-09 09:30:21'),
(310, 0, 'أ. جميل زين العابدين', '2716336096', '+202716336096', 'EG', NULL, 19364, NULL, 2, NULL, NULL, NULL, '2024-01-05 15:21:12', '2024-02-09 09:30:21'),
(311, 0, 'د. هناء عبد الباسط', '9126707636', '+209126707636', 'EG', NULL, 24730, 24464, 2, NULL, NULL, NULL, '2024-01-20 08:52:38', '2024-02-09 09:30:21'),
(312, 1, 'هيفاء السيف', '5172738775', '+9665172738775', 'SA', 'له ما قد أضر به نقصه، اتخذ.', NULL, NULL, 1, NULL, NULL, 'عنده، وما الذي أوجب بكاءه وتضرعه؛ فزاد في الدنو منه حتى أحس به أسال؛ فاشتد في العدو، واشتد حي بن يقظان أثره لما كان قد عزم عليه من الأولى والثانية وكان دوامه أطول. وما زال يتفكر في تلك الأجمة. فكان.', '2024-01-08 15:58:00', '2024-02-09 09:30:21'),
(313, 0, 'هناء مجاهد', '9595768795', '+209595768795', 'EG', NULL, 7872, 113, 2, NULL, NULL, NULL, '2024-02-05 12:56:56', '2024-02-09 09:30:21'),
(314, 1, 'آية شافع', '1174901528', '+201174901528', 'EG', NULL, 16073, 123, 2, NULL, NULL, NULL, '2024-02-08 19:42:48', '2024-02-08 20:42:31'),
(315, 0, 'ربى مهران', '3457598110', '+203457598110', 'EG', NULL, 23907, NULL, 3, '2024-01-27 15:46:35', '04:30 PM', NULL, '2024-01-25 15:46:35', '2024-02-09 09:30:21'),
(316, 0, 'ناصر الفرحان', '1673224607', '+9661673224607', 'SA', NULL, 764, 185, 2, NULL, NULL, NULL, '2024-01-11 05:48:03', '2024-02-09 09:30:21'),
(317, 1, 'امين عبد الكريم', '6583755520', '+206583755520', 'EG', NULL, 27565, NULL, 3, '2024-01-07 02:27:36', '12:30 PM', NULL, '2024-01-01 02:27:36', '2024-02-09 09:30:21'),
(318, 1, 'أ.د تغريد زين العابدين', '6015523730', '+9716015523730', 'AE', 'أتى وما معه شيء فقلت له: يا.', NULL, NULL, 1, NULL, NULL, 'كثير المال والمعاملات في البلاد قد ركب يومًا وخرج يطالب في بعض البلاد فاشتد عليه الحر فجلس تحت شجرة وحط يده في خرجه وأكل كسرة كانت معه وتمرة فلما فرغ من أكل التمرة رمى النواة وإذا هو بعفريت طويل.', '2024-01-12 07:16:33', '2024-02-09 09:30:21'),
(319, 1, 'أ.د رانيا عز الدين', '8684122954', '+208684122954', 'EG', NULL, 18258, 15986, 3, '2024-01-09 16:46:37', '04:00 PM', NULL, '2024-01-03 16:46:37', '2024-02-09 09:30:21'),
(320, 1, 'روزان داوود نوفان السيف', '0361526241', '+9660361526241', 'SA', NULL, 14047, 69, 3, '2024-01-15 17:19:51', '05:00 PM', NULL, '2024-01-09 17:19:51', '2024-02-09 09:30:21'),
(321, 1, 'Gaylord Metz', '2681576168', '+12681576168', 'US', NULL, 5052154, NULL, 3, '2024-01-13 13:06:53', '11:00 AM', NULL, '2024-01-08 13:06:53', '2024-02-09 09:30:21'),
(322, 1, 'د. زاهي السايس', '6164130643', '+9736164130643', 'BH', NULL, 4604, 118, 2, NULL, NULL, NULL, '2024-02-05 22:49:54', '2024-02-09 09:30:21'),
(323, 1, 'السيد نقولا عبد المجيد', '5091660162', '+9655091660162', 'KW', NULL, 20273, NULL, 3, '2024-01-22 22:26:29', '02:30 PM', NULL, '2024-01-17 22:26:29', '2024-02-09 09:30:21'),
(324, 0, 'الدكتور راكان عز العرب', '7783706648', '+9737783706648', 'BH', 'معه وأنا سكران من غير مدام.', NULL, NULL, 1, NULL, NULL, 'وأطيبه وألذه وأعذبه فقالت: أين هذا مما أحدثكم به الليلة القابلة إن عشت وأبقاني الملك فقال الملك: والله لا أقتلها حتى أسمع بقية حديثها لأنه عجيب ثم باتوا تلك الليلة متعانقين إلى الصباح متعانقين فخرج.', '2024-01-07 12:53:53', '2024-02-09 09:30:21'),
(325, 1, 'الأستاذ غازي غانم', '7556611761', '+9657556611761', 'KW', NULL, 6930, 73, 2, NULL, NULL, NULL, '2024-01-21 06:09:47', '2024-02-09 09:30:21'),
(326, 1, 'حلا الحصين', '0698190496', '+9660698190496', 'SA', NULL, 25125, 24820, 2, NULL, NULL, NULL, '2024-01-28 12:28:47', '2024-02-09 09:30:21'),
(327, 1, 'رشيد مجاهد', '0702040743', '+9730702040743', 'BH', NULL, 4456, 3266, 2, NULL, NULL, NULL, '2024-01-21 06:16:16', '2024-02-09 09:30:21'),
(328, 1, 'م. ورود عبد اللطيف', '0519337581', '+9710519337581', 'AE', NULL, 18934, NULL, 2, NULL, NULL, NULL, '2024-01-05 18:27:33', '2024-02-09 09:30:21'),
(329, 1, 'حسناء عبد اللطيف', '5608073583', '+9715608073583', 'AE', NULL, 5052213, NULL, 2, NULL, NULL, NULL, '2024-01-22 01:01:22', '2024-02-09 09:30:21'),
(330, 0, 'أ. داليا عبد الرزاق', '2249256083', '+202249256083', 'EG', 'فيه ماء فتكلمت عليه ورشتني.', NULL, NULL, 1, NULL, NULL, 'فأخذتني الرأفة عليه وقلت للراعي ائتني ببقرة ودع هذا. وأدرك شهرزاد الصباح فسكتت عن الكلام المباح. فقالت لها أختها: ما أطيب حديثك وألطفه وألذه وأعذبه فقالت: أين هذا مما أحدثكم به الليلة القابلة إن عشت.', '2024-01-21 09:08:33', '2024-02-09 09:30:21'),
(331, 1, 'Mandy Ortiz MD', '4433468107', '+14433468107', 'US', NULL, 19500, 18793, 2, NULL, NULL, NULL, '2024-01-12 03:40:19', '2024-02-09 09:30:21'),
(332, 1, 'الدكتور مسعد عبد المعطي', '7842624094', '+207842624094', 'EG', NULL, 5053367, 5051463, 2, NULL, NULL, NULL, '2024-02-07 06:23:04', '2024-02-09 09:30:21'),
(333, 0, 'مجد عبد العزيز', '7292283340', '+9717292283340', 'AE', 'وقال: أصحيح هذا فهزت رأسها.', NULL, NULL, 1, NULL, NULL, 'السلطان ورئيس الجان إن هذه البغلة كانت زوجتي سافرت وغبت عنها سنة كاملة وهم يعرضون علي السفر وأنا لم أرض حتى مضت ست سنوات كوامل. ثم وافقتهم على السفر وقلت لهم: يا أخوتي إننا نحسب ما عندنا من المال.', '2024-01-30 08:05:18', '2024-02-09 09:30:21'),
(334, 1, 'Whitney Parisian', '2122926708', '+12122926708', 'US', NULL, 21738, 21318, 2, NULL, NULL, NULL, '2024-01-02 16:09:43', '2024-02-09 09:30:21'),
(335, 0, 'م. حبيبة عمران', '9293555362', '+209293555362', 'EG', 'فصاحت وبكت بكاء شديدًا فقمت.', NULL, NULL, 1, NULL, NULL, 'ذلك والجني يتعجب من حكاية ذلك الكلام العجيب ثم قال صاحب الغزالة: يا سيد ملوك الجان كل ذلك جرى وابنة عمي هذه الغزالة هي بنت عمي فحكى لي جميع ما صنعت بك وبأمك بنت عمي ومن لحمي ودمي وكنت تزوجت بها وهي.', '2024-01-22 03:45:57', '2024-02-09 09:30:21'),
(336, 1, 'أ.د سامح نجيب', '7934612554', '+9717934612554', 'AE', NULL, 3411, 2414, 3, '2024-01-04 10:26:21', '03:30 PM', NULL, '2024-01-02 10:26:21', '2024-02-09 09:30:21'),
(337, 1, 'السيدة عبلة الجريد', '9636791788', '+9669636791788', 'SA', 'للعالم فهو لا محالة صادران.', NULL, NULL, 1, NULL, NULL, 'أن جزيرة من جزائر الهند التي تحت خط الاستواء، وهي الجزيرة التي ذكر المسعودي أنها جزيرة الوقواق لان تلك الجزيرة وصيدها ما يسد بها جوعته. وأقام على تلك الحال: يحكي نغمتها بصوته حتى لا تعلق بشيء إلا.', '2024-01-31 04:49:40', '2024-02-09 09:30:21'),
(338, 0, 'م. مصباح عزيز', '7144864487', '+9657144864487', 'KW', NULL, 4703, 57, 2, NULL, NULL, NULL, '2024-01-26 18:43:32', '2024-02-09 09:30:21'),
(339, 0, 'آيات وجيه الفدا', '3685235778', '+9663685235778', 'SA', NULL, 9210, 48, 2, NULL, NULL, NULL, '2024-01-26 08:42:18', '2024-02-09 09:30:21'),
(340, 1, 'السيدة وجدان عبد المطلب', '0557899953', '+9730557899953', 'BH', NULL, 8912, 35, 2, NULL, NULL, NULL, '2024-01-19 08:51:46', '2024-02-09 09:30:21'),
(341, 1, 'Aiyana Kris', '0615635592', '+10615635592', 'US', NULL, 5054502, 5052256, 2, NULL, NULL, NULL, '2024-01-01 17:45:04', '2024-02-09 09:30:21'),
(342, 1, 'رنا عبد المعطي', '7435944128', '+9737435944128', 'BH', 'لها: بالله لا تفعلي فإن صاحب.', NULL, NULL, 1, NULL, NULL, 'يا ولدي قد قيض الله لك من خلصك وخلص حقك ثم إني أيها الجني كلام هذا الراعي خرجت معه وأنا سكران من غير مدام من كثرة الفرح والسرور والذي حصل لي إلى أن وصل إلى ذلك البستان وكان ذلك اليوم أول السنة.', '2024-01-02 01:13:14', '2024-02-09 09:30:21'),
(343, 0, 'السيد مهاب جبر', '2003068238', '+9712003068238', 'AE', NULL, 26556, 25699, 2, NULL, NULL, NULL, '2024-02-08 19:24:59', '2024-02-09 09:30:21'),
(344, 1, 'المهندس رؤوف السعيد', '4337628166', '+204337628166', 'EG', NULL, 26510, NULL, 2, NULL, NULL, NULL, '2024-02-07 21:20:24', '2024-02-09 09:30:21'),
(345, 1, 'نهى الصعيدي', '6198239848', '+9716198239848', 'AE', NULL, 12968, 3786, 2, NULL, NULL, NULL, '2024-01-26 22:24:45', '2024-02-09 09:30:21'),
(346, 0, 'Mr. Xavier Weber I', '3153334436', '+13153334436', 'US', NULL, 19435, NULL, 3, '2024-01-09 10:28:20', '12:30 PM', NULL, '2024-01-07 10:28:20', '2024-02-09 09:30:21'),
(347, 0, 'أ. راية عبد الوهاب', '6454281492', '+9656454281492', 'KW', NULL, 2530, 212, 3, '2024-02-05 16:34:58', '10:30 AM', NULL, '2024-02-02 16:34:58', '2024-02-09 09:30:21'),
(348, 1, 'الدكتور رشاد عبد الرحيم', '1521408812', '+9651521408812', 'KW', NULL, 23133, 22540, 2, NULL, NULL, NULL, '2024-01-15 21:39:08', '2024-02-09 09:30:21'),
(349, 0, 'أ.د ضياء عزمي', '2704897596', '+202704897596', 'EG', 'حكاية ذلك الكلام العجيب ثم.', NULL, NULL, 1, NULL, NULL, 'المال والمعاملات في البلاد قد ركب يومًا وخرج يطالب في بعض البلاد فاشتد عليه الحر فجلس تحت شجرة وحط يده في خرجه وأكل كسرة كانت معه وتمرة فلما فرغ من أكل التمرة رمى النواة وإذا هو بعفريت طويل القامة.', '2024-01-22 21:55:35', '2024-02-09 09:30:21'),
(350, 1, 'شريهان الجهني', '6018523764', '+9666018523764', 'SA', 'كان يتعجب منهما ولا يدري هل.', NULL, NULL, 1, NULL, NULL, 'صار تراباً، والتراب إذا صار ماء، والنبات إذا صار هواء، والهواء إذا صار نباتاً، هذا هو معنى الفساد. وأما الشيء الذي يختص به عضو دون عضو - وقع في نفسه قبل ذلك: لانه كان يعترض سائراً اعضائه كاليد،.', '2024-01-15 12:53:25', '2024-02-09 09:30:21'),
(351, 0, 'نجوى عزمي', '3072191219', '+9653072191219', 'KW', NULL, 23850, 5681, 3, '2024-02-10 16:45:53', '10:00 AM', NULL, '2024-02-07 16:45:53', '2024-02-09 09:30:21'),
(352, 0, 'ملاك عبد الرؤوف', '4741986291', '+9734741986291', 'BH', NULL, 8564, 216, 2, NULL, NULL, NULL, '2024-02-06 06:44:25', '2024-02-09 09:30:21'),
(353, 0, 'ريهام هارون', '0765656538', '+9650765656538', 'KW', NULL, 5052364, NULL, 3, '2024-01-30 13:37:52', '05:00 PM', NULL, '2024-01-26 13:37:52', '2024-02-09 09:30:21'),
(354, 0, 'ليان عبد الجليل', '2712873186', '+9712712873186', 'AE', NULL, 21838, 20172, 3, '2024-01-31 01:49:25', '02:00 PM', NULL, '2024-01-28 01:49:25', '2024-02-09 09:30:21'),
(355, 0, 'غنى ملهم القحطاني', '9434764565', '+9669434764565', 'SA', NULL, 13014, 163, 3, '2024-01-22 23:09:24', '02:30 PM', NULL, '2024-01-17 23:09:24', '2024-02-09 09:30:21'),
(356, 0, 'نسيم الزامل', '0788036354', '+9660788036354', 'SA', NULL, 4253, 74, 2, NULL, NULL, NULL, '2024-01-21 16:44:35', '2024-02-09 09:30:21'),
(357, 1, 'Richie Ward', '4801632467', '+14801632467', 'US', NULL, 11244, 119, 2, NULL, NULL, NULL, '2024-01-22 09:26:38', '2024-02-09 09:30:21'),
(358, 0, 'Newell Hackett', '9661964605', '+19661964605', 'US', 'Hatter. He came in with the.', NULL, NULL, 1, NULL, NULL, 'Lizard, Bill, was in March.\' As she said to the Dormouse, who was gently brushing away some dead leaves that had slipped in like herself. \'Would it be of very little way out of their wits!\' So she.', '2024-01-08 19:12:47', '2024-02-09 09:30:22'),
(359, 1, 'السيدة صبا الكفراوي', '1672509460', '+9711672509460', 'AE', NULL, 7201, 59, 3, '2024-01-16 07:16:53', '03:30 PM', NULL, '2024-01-13 07:16:53', '2024-02-09 09:30:22'),
(360, 0, 'غرام عبد الرزاق', '2899602601', '+9652899602601', 'KW', NULL, 7397, 59, 3, '2024-01-20 09:20:20', '12:30 PM', NULL, '2024-01-18 09:20:20', '2024-02-09 09:30:22'),
(361, 0, 'إخلاص الشهيل', '4333500560', '+9664333500560', 'SA', NULL, 1606, 120, 3, '2024-01-16 08:47:46', '01:00 PM', NULL, '2024-01-13 08:47:46', '2024-02-09 09:30:22'),
(362, 0, 'Al Price', '0815644627', '+10815644627', 'US', NULL, 8606, 202, 3, '2024-01-17 21:04:47', '12:30 PM', NULL, '2024-01-11 21:04:47', '2024-02-09 09:30:22'),
(363, 0, 'أ.د يامن السباعي', '0734258856', '+9730734258856', 'BH', NULL, 13398, 4018, 2, NULL, NULL, NULL, '2024-01-30 11:19:37', '2024-02-09 09:30:22'),
(364, 0, 'ساجدة عبد الوهاب', '8676228075', '+9738676228075', 'BH', NULL, 15824, 1039, 2, NULL, NULL, NULL, '2024-02-03 17:34:47', '2024-02-09 09:30:22'),
(365, 1, 'الأستاذ أشرف الصعيدي', '9227553965', '+9719227553965', 'AE', NULL, 29920, 235, 2, NULL, NULL, NULL, '2024-01-02 03:00:58', '2024-02-09 09:30:22'),
(366, 0, 'م. ساجدة السايس', '7466521043', '+9737466521043', 'BH', NULL, 12462, 79, 3, '2024-01-22 17:52:20', '05:00 PM', NULL, '2024-01-20 17:52:20', '2024-02-09 09:30:22'),
(367, 1, 'محمد  عبد اللطيف', '6436303197', '+9736436303197', 'BH', NULL, 22729, 21734, 3, '2024-02-01 17:43:53', '12:00 PM', NULL, '2024-01-30 17:43:53', '2024-02-09 09:30:22'),
(368, 1, 'Mrs. Lempi Hane', '5194237754', '+15194237754', 'US', NULL, 5051998, 5050837, 2, NULL, NULL, NULL, '2024-01-16 04:25:44', '2024-02-09 09:30:22'),
(369, 1, 'خضر عبد المهيمن', '3162347584', '+203162347584', 'EG', NULL, 9944, 4055, 2, NULL, NULL, NULL, '2024-01-11 22:33:43', '2024-02-09 09:30:22'),
(370, 0, 'المهندسة لميس عبد الهادي', '5899054698', '+9715899054698', 'AE', NULL, 19312, 18779, 3, '2024-01-08 06:17:13', '12:30 PM', NULL, '2024-01-03 06:17:13', '2024-02-09 09:30:22'),
(371, 0, 'اسحاق عز الدين', '1718220483', '+9651718220483', 'KW', NULL, 7722, 80, 2, NULL, NULL, NULL, '2024-02-05 21:02:57', '2024-02-09 09:30:22'),
(372, 0, 'مهند عبد الجليل', '4586130484', '+9714586130484', 'AE', 'بقتلي وأخذ مالي وقالوا: نقتل.', NULL, NULL, 1, NULL, NULL, 'وهو صاحب الغزالة وقبل يد ذلك العفريت وقال له: ما سبب جلوسك في هذا منهم الشيخ الأول وهو صاحب الغزالة وقبل يد ذلك العفريت وقال له: اعلم يا سيد ملوك الجان أن هاتين الكلبتين أخوتي وأنا ثالثهم ومات والدي.', '2024-02-05 16:28:15', '2024-02-09 09:30:22'),
(373, 0, 'Shayne Crooks', '1231994406', '+11231994406', 'US', NULL, 1788, 153, 3, '2024-01-21 23:57:05', '04:30 PM', NULL, '2024-01-15 23:57:05', '2024-02-09 09:30:22'),
(374, 1, 'المهندس رؤوف شافع', '2274219821', '+202274219821', 'EG', NULL, 3331, 2409, 3, '2024-01-21 00:29:46', '10:30 AM', NULL, '2024-01-15 00:29:46', '2024-02-09 09:30:22'),
(375, 0, 'أ. سهير غانم', '9627885234', '+9739627885234', 'BH', 'مسحورًا فعد إلى خلقتك الأولى.', NULL, NULL, 1, NULL, NULL, 'ولو لم تجازيني فقالت: يا سيدي ليس لي رغبة في المال جميعه لنا وزين لهم الشيطان أعمالهم فجاؤوني وأنا نائم بجانب زوجتي ورموني في البحر فلما استيقظت زوجتي انتفضت فصارت عفريتة وحملتني وأطلعتني على جزيرة.', '2024-01-28 15:54:34', '2024-02-09 09:30:22'),
(376, 0, 'فوزية مهران', '7478817585', '+9717478817585', 'AE', 'سمعت أيها الجني كلام بنت.', NULL, NULL, 1, NULL, NULL, 'أذبحه وأمرت الراعي أن يخصني ببقرة سمينة وهي سريتي التي سحرتها تلك الغزالة فشمرت ثيابي وأخذت السكين بيدي وتهيأت لذبحها فصاحت وبكت بكاء شديدًا فقمت عنها وأمرت ذلك الراعي بذبحها وسلخها فلم يجد فيها.', '2024-01-17 17:16:47', '2024-02-09 09:30:22'),
(377, 1, 'بثينة عبد الهادي', '5385248128', '+9735385248128', 'BH', NULL, 13742, 60, 3, '2024-02-11 16:03:17', '02:00 PM', NULL, '2024-02-07 16:03:17', '2024-02-09 09:30:22'),
(378, 0, 'حسناء مامون اوس برماوي', '5168901274', '+9665168901274', 'SA', NULL, 19861, NULL, 2, NULL, NULL, NULL, '2024-01-30 02:03:13', '2024-02-09 09:30:22'),
(379, 0, 'الآنسة نرمين غانم', '3664433183', '+9733664433183', 'BH', NULL, 15715, 4066, 2, NULL, NULL, NULL, '2024-01-16 19:56:47', '2024-02-09 09:30:22'),
(380, 0, 'الآنسة سجى عز العرب', '2612007389', '+9732612007389', 'BH', 'فلما فرغ من حديثه اهتز الجني.', NULL, NULL, 1, NULL, NULL, 'الله تعالى وإذا به انتفض ثم صار إنسانًا فوقعت عليه وقلت له: ائتني بعجل سمين فأتاني بولدي المسحور عجلًا فلما رآني صاحب الدكان أخذني ودخل بي بيته فلما رأتني بنت الجزار غطت وجهها مني فقالت أتجيء لنا.', '2024-01-18 05:21:40', '2024-02-09 09:30:22'),
(381, 1, 'نوال عبد القادر', '6656965789', '+9656656965789', 'KW', 'بنت الراعي قلت : ولك فوق.', NULL, NULL, 1, NULL, NULL, 'فأرسلت إلى الراعي ثم أنها سحرت ابنة عمي هذه الغزالة ورأيتها عجيبة أتهب لي ثلث دم هذا التاجر وحياه وقال له: ما سبب جلوسك في هذا المكان وأنت منفرد وهو مأوى الجن فأخبره التاجر بما جرى له مع ذلك العفريت.', '2024-01-05 20:03:59', '2024-02-09 09:30:22'),
(382, 0, 'المهندسة ولاء كاظم', '2324526262', '+9732324526262', 'BH', 'الجني: هذا حديث عجيب وقد.', NULL, NULL, 1, NULL, NULL, 'عجلًا وسحرت الجارية أمه بقرة وسلمتها إلى الراعي أن يأخذه وتوجه به ففي ثاني يوم وأنا جالس وإذا بالراعي أقبل علي وقال: يا أخي أما أشرت عليك بعدم السفر فبكى وقال: يا سيدي إيه ابنك وحشاشة كبدك فقلت لها.', '2024-01-09 11:32:19', '2024-02-09 09:30:22'),
(383, 1, 'د. سلسبيل عبد المطلب', '6469180185', '+9736469180185', 'BH', 'خلصيه فأخذت كوزًا فيه ماء.', NULL, NULL, 1, NULL, NULL, 'مدة سنة وأنا حزين القلب باكي العين إلى أن وصل إلى ذلك البستان وكان ذلك اليوم أول السنة الجديدة فبينما هو جالس يبكي على ما أقول وكيل. فاستوثق منه الجني وأطلقه فرجع إلى بلده وما هذه بأعجب من حكاية.', '2024-01-23 04:19:37', '2024-02-09 09:30:22'),
(384, 0, 'Miss Maddison Klocko', '0919708428', '+10919708428', 'US', NULL, 5054453, 5052303, 3, '2024-01-07 03:11:14', '01:30 PM', NULL, '2024-01-01 03:11:14', '2024-02-09 09:30:22'),
(385, 1, 'راما طلال', '4842104188', '+9654842104188', 'KW', NULL, 5050880, NULL, 2, NULL, NULL, NULL, '2024-02-08 11:14:19', '2024-02-09 09:30:22'),
(386, 0, 'السيدة دارين مكي', '4466900918', '+9654466900918', 'KW', NULL, 10737, 4039, 2, NULL, NULL, NULL, '2024-01-01 03:11:46', '2024-02-09 09:30:22'),
(387, 1, 'أحلام عبد الرحيم', '0129875912', '+9730129875912', 'BH', NULL, 13951, 109, 3, '2024-02-12 14:16:56', '12:00 PM', NULL, '2024-02-06 14:16:56', '2024-02-09 09:30:22'),
(388, 1, 'Brannon Bernhard I', '8217551209', '+18217551209', 'US', NULL, 4083, 3266, 2, NULL, NULL, NULL, '2024-01-29 10:54:55', '2024-02-09 09:30:22'),
(389, 1, 'دنيا جبر', '4835963827', '+9714835963827', 'AE', NULL, 10007, 2987, 2, NULL, NULL, NULL, '2024-01-15 03:49:19', '2024-02-09 09:30:22'),
(390, 0, 'Prof. Gordon Rice I', '5082051489', '+15082051489', 'US', NULL, 30068, 43, 2, NULL, NULL, NULL, '2024-02-01 19:26:46', '2024-02-09 09:30:22'),
(391, 1, 'أ. باهر عبد الرحمن', '1679077861', '+201679077861', 'EG', 'وقال للراعي: ابق هذا العجل.', NULL, NULL, 1, NULL, NULL, 'نعم الرأي فأخذت المال وقسمته نصفين ودفنت ثلاثة آلاف دينار. وأما الثلاثة آلاف الأخرى فأعطيت كل واحد منا ألف دينار ونتسبب فيها قالوا: نعم الرأي فأخذت المال وقسمته نصفين ودفنت ثلاثة آلاف دينار. وأما.', '2024-02-07 16:15:15', '2024-02-09 09:30:22'),
(392, 1, 'ناجي السعيد', '7354065594', '+9667354065594', 'SA', NULL, 6729, 152, 2, NULL, NULL, NULL, '2024-02-02 03:28:20', '2024-02-09 09:30:22'),
(393, 0, 'أكرم عيدالله الحصين', '2459478978', '+9662459478978', 'SA', 'عنه، فكان يرى النوع بهذا.', NULL, NULL, 1, NULL, NULL, 'إلى ما اتفقت فيه. وكان في تلك المدة حي بن يقظان ذلك كله ولم ير في الوجود كمال، ولا حسن، ولا بهاء، ولا جمال إلا صادر من جهته، وفائض من قبله، فمن فقد إدراك ذلك الشيء ما هو؟ وكيف هو؟ وما الذي ربطه بهذا.', '2024-01-05 15:43:03', '2024-02-09 09:30:22'),
(394, 0, 'السيد مصعب الكفراوي', '8375523312', '+9658375523312', 'KW', NULL, 21195, 20867, 2, NULL, NULL, NULL, '2024-01-12 00:54:53', '2024-02-09 09:30:22'),
(395, 0, 'مجد عبد المهيمن', '9865356869', '+9719865356869', 'AE', 'الراعي أن يخصني ببقرة سمينة.', NULL, NULL, 1, NULL, NULL, 'عندهم إلى تمام السنة ثم توجه وأخذ كفنه تحت إبطه ثم حكم الملك وولي وعزل إلى آخر النهار ولم يخبر الوزير بشيء من ذلك غاية العجب ثم انفض الديوان ودخل الملك شهريار قصره. و في الليلة الثانية قالت دنيازاد.', '2024-01-19 11:21:20', '2024-02-09 09:30:22'),
(396, 0, 'د. رزان مجاهد', '1471121402', '+9711471121402', 'AE', 'امرأة وأنا أقدر على تخليصه.', NULL, NULL, 1, NULL, NULL, 'ذلك العجل قطع حبله وجاءني وتمرغ علي فقلت لابنة الراعي: أحق ما تقولينه عن ذلك العجل قطع حبله وجاءني وتمرغ علي فقلت لابنة الراعي: أحق ما تقولينه عن ذلك العجل فقالت: نعم يا سيدي تزوجني وخذني إلى بلادك.', '2024-01-11 22:39:24', '2024-02-09 09:30:22'),
(397, 1, 'Gwendolyn Cormier', '9250314323', '+19250314323', 'US', NULL, 5053703, 5051696, 2, NULL, NULL, NULL, '2024-01-14 04:18:30', '2024-02-09 09:30:22'),
(398, 1, 'م. نزيه مهران', '7182190533', '+9717182190533', 'AE', 'إننا نحسب ما عندنا من المال.', NULL, NULL, 1, NULL, NULL, 'فكبر شيئًا فشيئًا إلى أن وصل إلى ذلك البستان وكان ذلك اليوم أول السنة الجديدة فبينما هو جالس يبكي على ما يحصل له وإذا بشيخ كبير قد أقبل عليه ومعه غزالة مسلسلة فسلم على هذا التاجر وحياه وقال له: يا.', '2024-01-23 13:00:51', '2024-02-09 09:30:22'),
(399, 0, 'زين عبد المجيد', '9485977346', '+9719485977346', 'AE', NULL, 5054529, 5052300, 3, '2024-01-05 21:09:34', '12:30 PM', NULL, '2024-01-01 21:09:34', '2024-02-09 09:30:22'),
(400, 1, 'سلمى عبد اللطيف', '4193698984', '+9714193698984', 'AE', NULL, 1908, 199, 2, NULL, NULL, NULL, '2024-01-02 04:19:39', '2024-02-09 09:30:22'),
(401, 1, 'سمية عزمي', '9938909482', '+9719938909482', 'AE', 'ائتني ببقرة ودع هذا. وأدرك.', NULL, NULL, 1, NULL, NULL, 'ماتت وابنك هرب ولم أعلم أين راح فجلست مدة سنة وأنا حزين القلب باكي العين إلى أن وصل إلى ذلك البستان وكان ذلك اليوم أول السنة الجديدة فبينما هو جالس يبكي على ما أقول وكيل. فاستوثق منه الجني وأطلقه.', '2024-01-15 21:11:12', '2024-02-09 09:30:22'),
(402, 0, 'خالد نجيب', '1983088810', '+9651983088810', 'KW', 'إلى هنا فرأيت هؤلاء الجماعة.', NULL, NULL, 1, NULL, NULL, 'فقال الجني نعم فقال الشيخ أيها السلطان ورئيس ملوك الجان كل ذلك والجني يتعجب من حكاية ذلك الكلام العجيب ثم قال صاحب الغزالة: يا سيد ملوك الجان أن هاتين الكلبتين أخوتي وأنا ثالثهم ومات والدي وخلف لنا.', '2024-01-17 06:44:16', '2024-02-09 09:30:22'),
(403, 0, 'الدكتور اسحق عبد الله', '3539418668', '+9653539418668', 'KW', NULL, 23598, NULL, 3, '2024-01-11 21:15:03', '10:30 AM', NULL, '2024-01-05 21:15:03', '2024-02-09 09:30:22'),
(404, 1, 'Neal Rempel', '9894661599', '+19894661599', 'US', 'Ugh, Serpent!\' \'But I\'m not.', NULL, NULL, 1, NULL, NULL, 'Alice, quite forgetting her promise. \'Treacle,\' said the Caterpillar. Here was another long passage, and the little golden key and hurried upstairs, in great disgust, and walked off; the Dormouse.', '2024-01-01 08:44:37', '2024-02-09 09:30:22'),
(405, 1, 'أ. مايا السويلم', '4833424557', '+204833424557', 'EG', 'ولدي فقال له التاجر: كيف.', NULL, NULL, 1, NULL, NULL, 'في خرجه وأكل كسرة كانت معه وتمرة فلما فرغ من أكل التمرة رمى النواة وإذا هو بعفريت طويل القامة وبيده سيف فدنا من ذلك غاية العجب وما صدقت بطلوع الصباح حتى جئت إليك لأعلمك فلما سمعت كلامها حن قلبي.', '2024-01-31 18:34:37', '2024-02-09 09:30:22'),
(406, 1, 'Mohammed Bins I', '4969472950', '+14969472950', 'US', NULL, 5053154, 5051295, 2, NULL, NULL, NULL, '2024-01-01 05:38:40', '2024-02-09 09:30:22'),
(407, 1, 'المهندسة سيرين السقا', '6889803537', '+9716889803537', 'AE', NULL, 5050904, NULL, 3, '2024-02-01 12:33:44', '10:30 AM', NULL, '2024-01-29 12:33:44', '2024-02-09 09:30:22'),
(408, 0, 'فايزة جبر', '4616386242', '+204616386242', 'EG', NULL, 8712, 2169, 2, NULL, NULL, NULL, '2024-01-09 05:51:18', '2024-02-09 09:30:22'),
(409, 0, 'آلاء عزيز', '6850409096', '+9736850409096', 'BH', 'ما عندنا من المال فحسبناه.', NULL, NULL, 1, NULL, NULL, 'ضحكت وقالت: يا سيدي هل عندك إحسان ومعروف أجازيك عليهما قلت: نعم إن عندي الإحسان والمعروف ولو لم تجازيني فقالت: يا سيدي هل عندك إحسان ومعروف أجازيك عليهما قلت: نعم إن عندي الإحسان والمعروف ولو لم.', '2024-01-29 15:16:55', '2024-02-09 09:30:22'),
(410, 0, 'بشر مظهر', '8450910424', '+9718450910424', 'AE', NULL, 17194, 57, 3, '2024-02-10 11:16:49', '12:30 PM', NULL, '2024-02-05 11:16:49', '2024-02-09 09:30:22'),
(411, 1, 'خديجة هوساوي', '0209390061', '+9650209390061', 'KW', NULL, 14714, 31, 2, NULL, NULL, NULL, '2024-01-31 04:08:49', '2024-02-09 09:30:22'),
(412, 1, 'شهم عبد العزيز', '6468835681', '+9656468835681', 'KW', 'ووهب له باقي دمه وجنايته.', NULL, NULL, 1, NULL, NULL, 'ذلك البستان وكان ذلك اليوم أول السنة الجديدة فبينما هو جالس يبكي على ما يحصل له وإذا بشيخ كبير قد أقبل عليه ومعه غزالة مسلسلة فسلم على هذا التاجر وحياه وقال له: يا أيها الشيخ إذا أنت حكيت لي الحكاية.', '2024-01-26 04:24:03', '2024-02-09 09:30:22'),
(413, 1, 'راجح عبد الناصر', '9460379076', '+9719460379076', 'AE', NULL, 13494, NULL, 2, NULL, NULL, NULL, '2024-01-04 21:54:29', '2024-02-09 09:30:22'),
(414, 0, 'رواء مدني', '3326321591', '+9663326321591', 'SA', NULL, 330, 8, 3, '2024-01-06 16:06:57', '10:00 AM', NULL, '2024-01-02 16:06:57', '2024-02-09 09:30:22'),
(415, 0, 'م. اسراء رسلان', '4963116439', '+9714963116439', 'AE', NULL, 6359, 172, 2, NULL, NULL, NULL, '2024-01-03 17:32:08', '2024-02-09 09:30:22'),
(416, 1, 'Rozella Terry', '0533525329', '+10533525329', 'US', NULL, 5050950, 5050780, 3, '2024-01-23 00:10:53', '04:30 PM', NULL, '2024-01-20 00:10:53', '2024-02-09 09:30:22'),
(417, 1, 'سلمى مهران', '9673908495', '+9719673908495', 'AE', 'الغزالة وجئت إلى هنا فرأيت.', NULL, NULL, 1, NULL, NULL, 'أحكي لك حكاية أعجب من حكاية ذلك الكلام العجيب ثم قال صاحب الغزالة: يا سيد ملوك الجان كل ذلك والجني يتعجب من حكاية الصياد فقال لها الملك: احكي فقالت: بلغني أيها الملك السعيد أنه كان تاجر من التجار.', '2024-01-27 13:21:21', '2024-02-09 09:30:22'),
(418, 0, 'غيث منصف الفريدي', '5443884796', '+9665443884796', 'SA', NULL, 13459, 3527, 3, '2024-02-01 05:37:16', '01:00 PM', NULL, '2024-01-27 05:37:16', '2024-02-09 09:30:22'),
(419, 1, 'أ. سماح عز الدين', '8435846353', '+9738435846353', 'BH', NULL, 19638, NULL, 3, '2024-01-31 09:01:00', '04:00 PM', NULL, '2024-01-29 09:01:00', '2024-02-09 09:30:22'),
(420, 1, 'ميسر العنزي', '2192444901', '+9662192444901', 'SA', NULL, 17530, 10, 3, '2024-01-12 15:38:28', '01:30 PM', NULL, '2024-01-10 15:38:28', '2024-02-09 09:30:22'),
(421, 0, 'عيد عبد المطلب', '0721524820', '+200721524820', 'EG', NULL, 6200, 68, 3, '2024-02-06 18:30:39', '10:00 AM', NULL, '2024-02-01 18:30:39', '2024-02-09 09:30:22'),
(422, 1, 'المهندسة حلا عبد الله', '5888051226', '+205888051226', 'EG', NULL, 18471, 16109, 3, '2024-02-06 19:24:38', '02:30 PM', NULL, '2024-02-02 19:24:38', '2024-02-09 09:30:22'),
(423, 0, 'نجاة السالم', '6071797100', '+9666071797100', 'SA', NULL, 18744, NULL, 2, NULL, NULL, NULL, '2024-02-08 01:51:55', '2024-02-09 09:30:22'),
(424, 0, 'المهندسة هدى عبد الوهاب', '3870311118', '+9733870311118', 'BH', 'الراعي أن يأخذه وتوجه به ففي.', NULL, NULL, 1, NULL, NULL, 'أن أتيت إلى داره فرحبت بي ابنة الراعي ثم أنها سحرت ابنة عمي هذه الغزالة هي بنت عمي فدمها لك مباح. فلما سمعت كلامي أخذت طاسة وملأتها ماء ثم أنها عزمت عليها ورشت بها العجل وقالت: إن كان الله خلقك.', '2024-01-01 23:21:39', '2024-02-09 09:30:22'),
(425, 0, 'م. عائشة عبد الفتاح', '6706382337', '+206706382337', 'EG', NULL, 21037, NULL, 2, NULL, NULL, NULL, '2024-02-06 08:25:03', '2024-02-09 09:30:22'),
(426, 1, 'السيدة صابرين السقا', '9355245772', '+9719355245772', 'AE', NULL, 22847, 21735, 3, '2024-01-11 19:33:05', '12:00 PM', NULL, '2024-01-09 19:33:05', '2024-02-09 09:30:22'),
(427, 1, 'Abigale Satterfield', '7913206033', '+17913206033', 'US', NULL, 10304, 158, 2, NULL, NULL, NULL, '2024-02-07 06:29:23', '2024-02-09 09:30:22'),
(428, 0, 'أ.د علي صدام', '5652169672', '+205652169672', 'EG', 'فأعطيت كل واحد منا ألف دينار.', NULL, NULL, 1, NULL, NULL, 'فقالت لي جاريتك ماتت وابنك هرب ولم أعلم أين راح فجلست مدة سنة مع القوافل ثم أتى وما معه شيء فقلت له: يا أخي إني أحسب ربح دكاني من السنة إلى السنة ثم أقسمه دون رأس المال بيني وبينك ثم إني عملت حساب.', '2024-01-22 18:00:30', '2024-02-09 09:30:22'),
(429, 1, 'الدكتور ريان عبد الله', '4849097456', '+9734849097456', 'BH', 'فأرسلت إلى الراعي ثم أنها.', NULL, NULL, 1, NULL, NULL, 'ماء وتكلمت عليه ورشت علي منه قليلًا وقالت: اخرج من هذه الصورة إلى صورة كلب فصرت في الحال بغلة وهي هذه التي تنظرها بعينك أيها السلطان ورئيس الجان إن هذه البغلة كانت زوجتي سافرت وغبت عنها سنة كاملة.', '2024-01-13 00:56:43', '2024-02-09 09:30:22'),
(430, 0, 'مالك عبد الفتاح', '1017502911', '+201017502911', 'EG', NULL, 19891, NULL, 3, '2024-02-01 16:58:37', '11:00 AM', NULL, '2024-01-28 16:58:37', '2024-02-09 09:30:22'),
(431, 1, 'Destiney Bruen', '8932767679', '+18932767679', 'US', 'It was so ordered about by.', NULL, NULL, 1, NULL, NULL, 'Alice the moment how large she had hoped) a fan and gloves--that is, if I shall ever see you any more!\' And here poor Alice in a tone of the same year for such a thing before, and he wasn\'t one?\'.', '2024-01-31 16:08:29', '2024-02-09 09:30:22'),
(432, 0, 'ملاك رجائي', '9581727519', '+9659581727519', 'KW', 'وطارت فوضعتني على سطح داري.', NULL, NULL, 1, NULL, NULL, 'التاجر إن لي بنتًا كانت تعلمت السحر والكهانة من صغرها فسحرت ذلك الولد عجلًا وسحرت الجارية أمه بقرة وسلمتها إلى الراعي أن يخصني ببقرة سمينة وهي سريتي التي سحرتها تلك الغزالة فشمرت ثيابي وأخذت السكين.', '2024-01-09 12:26:32', '2024-02-09 09:30:22'),
(433, 1, 'د. ضياء عبد المعطي', '5528943683', '+9735528943683', 'BH', NULL, 3973, 150, 2, NULL, NULL, NULL, '2024-01-02 11:21:21', '2024-02-09 09:30:22'),
(434, 1, 'مديحة هوساوي', '5635244656', '+9665635244656', 'SA', NULL, 5053943, 5053845, 3, '2024-01-06 02:53:33', '12:00 PM', NULL, '2024-01-02 02:53:33', '2024-02-09 09:30:22'),
(435, 1, 'Adrian Bogan', '4115040246', '+14115040246', 'US', NULL, 1229, 16, 2, NULL, NULL, NULL, '2024-02-08 12:58:56', '2024-02-09 09:30:22'),
(436, 1, 'طاهر عزام', '5450299294', '+9735450299294', 'BH', NULL, 7460, 22, 3, '2024-01-10 08:30:05', '04:00 PM', NULL, '2024-01-08 08:30:05', '2024-02-09 09:30:22'),
(437, 0, 'نسيمة عبد الوهاب', '3939262270', '+9713939262270', 'AE', NULL, 16014, 9755, 2, NULL, NULL, NULL, '2024-01-12 14:31:46', '2024-02-09 09:30:22'),
(438, 0, 'أ.د ندى الصعيدي', '4755085253', '+9734755085253', 'BH', NULL, 1089, 224, 3, '2024-02-09 09:34:12', '10:00 AM', NULL, '2024-02-04 09:34:12', '2024-02-09 09:30:22'),
(439, 0, 'م. لين طلال', '0332991890', '+9650332991890', 'KW', NULL, 7762, 58, 2, NULL, NULL, NULL, '2024-01-18 02:45:53', '2024-02-09 09:30:22'),
(440, 0, 'اسلام عزمي', '2727193223', '+9652727193223', 'KW', 'نعم. يا أيها الجني وتاج ملوك.', NULL, NULL, 1, NULL, NULL, 'لي إلى أن جاء عيد الضحية فأرسلت إلى الراعي أن يأخذه وتوجه به ففي ثاني يوم وأنا جالس وإذا بالراعي أقبل علي وقال: يا أخي إني أحسب ربح دكاني من السنة إلى السنة ثم توجه وأخذ كفنه تحت إبطه وودع أهله.', '2024-01-29 02:20:40', '2024-02-09 09:30:22'),
(441, 0, 'اسامة شافع', '8922139480', '+9718922139480', 'AE', NULL, 5052848, 5051144, 2, NULL, NULL, NULL, '2024-01-06 01:03:48', '2024-02-09 09:30:22'),
(442, 0, 'طه رسلان', '3739973237', '+9733739973237', 'BH', NULL, 17096, 14, 3, '2024-01-09 22:32:51', '12:30 PM', NULL, '2024-01-06 22:32:51', '2024-02-09 09:30:22'),
(443, 0, 'قمر ورد عبدالكريم السعيد', '8378268319', '+9668378268319', 'SA', NULL, 3487, 120, 2, NULL, NULL, NULL, '2024-01-31 07:39:49', '2024-02-09 09:30:22'),
(444, 1, 'المهندسة سحر عبد الفتاح', '9842804129', '+9719842804129', 'AE', NULL, 21524, 20718, 2, NULL, NULL, NULL, '2024-02-01 15:42:35', '2024-02-09 09:30:22'),
(445, 0, 'Lucile Schiller', '2004813983', '+12004813983', 'US', NULL, 204, NULL, 2, NULL, NULL, NULL, '2024-01-31 06:33:25', '2024-02-09 09:30:22'),
(446, 1, 'المهندسة غادة حارث', '7558296325', '+9657558296325', 'KW', NULL, 5054353, NULL, 3, '2024-01-31 19:03:27', '11:30 AM', NULL, '2024-01-28 19:03:27', '2024-02-09 09:30:22'),
(447, 0, 'المهندسة مشيرة عبد العزيز', '8821074339', '+208821074339', 'EG', 'ثلث دم هذا التاجر قال: نعم.', NULL, NULL, 1, NULL, NULL, 'وغبت عنها سنة كاملة وهم يعرضون علي السفر وأنا لم أرض حتى مضت ست سنوات كوامل. ثم وافقتهم على السفر وقلت لهم: أي شيء كسبتم من سفركم حتى أكسب أنا فألحوا علي ولم أطعهم بل أقمنا في دكاكيننا نبيع ونشتري.', '2024-01-31 10:33:13', '2024-02-09 09:30:22'),
(448, 0, 'المهندس زمام عبد الناصر', '0545446538', '+200545446538', 'EG', NULL, 16165, 77, 2, NULL, NULL, NULL, '2024-01-12 18:58:20', '2024-02-09 09:30:22'),
(449, 1, 'سهى عمران', '8682239106', '+9738682239106', 'BH', 'وأشتري وسافر أخي بتجارته.', NULL, NULL, 1, NULL, NULL, 'سنة وأنا حزين القلب باكي العين إلى أن دخلنا مدينة وبعنا بضائعنا فربحنا في الدينار عشرة دنانير ثم أردنا السفر فوجدنا على شاطئ البحر جارية عليها خلق مقطع فقبلت يدي وقالت: يا سيدي ليس لي رغبة في المال.', '2024-01-05 19:23:09', '2024-02-09 09:30:22');
INSERT INTO `leads_contact_us` (`id`, `export`, `name`, `phone`, `full_number`, `country`, `subject`, `listing_id`, `project_id`, `request_type`, `meeting_day`, `meeting_time`, `message`, `created_at`, `updated_at`) VALUES
(450, 1, 'الدكتورة نرمين عبد الرحمن', '8634665476', '+9738634665476', 'BH', 'يا أخوتي إننا نحسب ما عندنا.', NULL, NULL, 1, NULL, NULL, 'الغزالة وقبل يد ذلك العفريت وقال له: اعلم يا سيد ملوك الجان كل ذلك جرى وابنة عمي هذه الغزالة تعلمت السحر والكهانة من صغرها فسحرت ذلك الولد عجلًا وسحرت الجارية أمه بقرة وسلمتها إلى الراعي ثم أنها.', '2024-02-04 09:49:46', '2024-02-09 09:30:22'),
(451, 0, 'رغد عز العرب', '2034253988', '+9712034253988', 'AE', NULL, 12812, 31, 3, '2024-01-10 11:39:26', '03:00 PM', NULL, '2024-01-06 11:39:26', '2024-02-09 09:30:22'),
(452, 0, 'السيدة دنيا عبد الرحيم', '2669457663', '+9652669457663', 'KW', NULL, 14551, 4027, 3, '2024-01-31 23:11:37', '12:00 PM', NULL, '2024-01-26 23:11:37', '2024-02-09 09:30:22'),
(453, 0, 'رانيا غانم', '5634157249', '+9735634157249', 'BH', NULL, 26789, 25736, 3, '2024-01-27 23:46:03', '12:30 PM', NULL, '2024-01-25 23:46:03', '2024-02-09 09:30:22'),
(454, 1, 'المهندس راشد فواز', '0467661414', '+9710467661414', 'AE', NULL, 28403, 28060, 2, NULL, NULL, NULL, '2024-01-19 06:50:06', '2024-02-09 09:30:22'),
(455, 0, 'الدكتور مؤمن عبد الرزاق', '4024141328', '+9654024141328', 'KW', NULL, 1114, 877, 2, NULL, NULL, NULL, '2024-02-04 18:51:09', '2024-02-09 09:30:22'),
(456, 1, 'Mr. Linwood Gulgowski V', '8484151613', '+18484151613', 'US', NULL, 10712, 4067, 3, '2024-01-04 14:41:01', '04:30 PM', NULL, '2024-01-02 14:41:01', '2024-02-09 09:30:22'),
(457, 0, 'سمية سقا', '4615689130', '+9664615689130', 'SA', NULL, 5054332, NULL, 2, NULL, NULL, NULL, '2024-01-17 16:17:49', '2024-02-09 09:30:22'),
(458, 1, 'المهندسة وسيم الكفراوي', '1469432209', '+9711469432209', 'AE', NULL, 18840, NULL, 3, '2024-02-13 18:03:53', '03:00 PM', NULL, '2024-02-07 18:03:53', '2024-02-09 09:30:22'),
(459, 0, 'أ. وئام عز الدين', '1368737518', '+9651368737518', 'KW', 'ضحكي وأما سبب بكائي فمن أجل.', NULL, NULL, 1, NULL, NULL, 'كانت تعلمت السحر في صغرها من امرأة عجوز كانت عندنا فلما كنا بالأمس وأعطيتني العجل دخلت به عليها فنظرت إليه ابنتي وغطت وجهها وبكت ثم إنها ضحكت وقالت: يا سيدي تزوجني وخذني إلى بلادك فإني قد وهبتك نفسي.', '2024-01-08 04:47:52', '2024-02-09 09:30:22'),
(460, 0, 'غادة عبد العزيز', '2307504870', '+9732307504870', 'BH', NULL, 21982, 20160, 3, '2024-02-03 17:37:04', '11:30 AM', NULL, '2024-01-28 17:37:04', '2024-02-09 09:30:22'),
(461, 0, 'المهندسة تالة عبد الله', '0398222758', '+200398222758', 'EG', NULL, 5051148, NULL, 2, NULL, NULL, NULL, '2024-01-31 09:07:10', '2024-02-09 09:30:22'),
(462, 0, 'Prof. Dante Ferry', '1667908524', '+11667908524', 'US', 'This of course, to begin at.', NULL, NULL, 1, NULL, NULL, 'Which shall sing?\' \'Oh, YOU sing,\' said the Dodo, \'the best way you have to ask his neighbour to tell them something more. \'You promised to tell me the truth: did you begin?\' The Hatter was the.', '2024-01-23 01:14:33', '2024-02-09 09:30:22'),
(463, 1, 'المهندس مهدي عبد الحميد', '7039382868', '+9717039382868', 'AE', 'السلطان ورئيس ملوك الجان ثم.', NULL, NULL, 1, NULL, NULL, 'عليه الوزير والعسكر واحتبك الديوان فحكم الملك وولى وعزل ونهى وأمر إلى آخر النهار ثم انفض الديوان ودخل الملك شهريار قصره. و في الليلة الثانية قالت دنيازاد لأختها شهرزاد: يا أختي ما أحلى حديثك وأطيبه.', '2024-01-16 17:39:00', '2024-02-09 09:30:22'),
(464, 0, 'Prof. Kasandra Buckridge', '8398695152', '+18398695152', 'US', 'Nile On every golden scale!.', NULL, NULL, 1, NULL, NULL, 'What made you so awfully clever?\' \'I have answered three questions, and that is rather a handsome pig, I think.\' And she thought it had VERY long claws and a scroll of parchment in the pool, \'and.', '2024-02-04 07:52:08', '2024-02-09 09:30:22'),
(465, 0, 'المهندسة فيفيان عبد الرحيم', '9639151172', '+9739639151172', 'BH', NULL, 29052, 28436, 2, NULL, NULL, NULL, '2024-01-15 05:32:51', '2024-02-09 09:30:22'),
(466, 0, 'فريد الصعيدي', '5775114261', '+9655775114261', 'KW', NULL, 5050407, NULL, 3, '2024-01-11 09:47:39', '12:30 PM', NULL, '2024-01-09 09:47:39', '2024-02-09 09:30:22'),
(467, 1, 'فادي الشهري', '2226250298', '+9662226250298', 'SA', 'بضرب ما من العظم في حال شبيه.', NULL, NULL, 1, NULL, NULL, 'نفسه لولا أن تداركه الله برحمته وتلافاه بهدايته، فعلم إن الشبهة انما ثارت عنده من سرعة العدو وقوة البطش، وما لها من فاعل. ثم نظر إلى جميع أعضاء الظاهرة ولم ير فيها آفة ظاهرة - وكان يرى البحر قد أحدق.', '2024-01-02 04:55:13', '2024-02-09 09:30:22'),
(468, 0, 'علا جمال الدين', '4705481326', '+9654705481326', 'KW', 'فهذا سبب ضحكي وأما سبب بكائي.', NULL, NULL, 1, NULL, NULL, 'إليها لأمر يريده الله عز وجل فأخذتها وكسوتها وفرشت لها في المركب فرشًا حسنًا وأقبلت عليها وأكرمتها ثم سافرنا وقد أحبها قلبي محبة عظيمة وصرت لا أفارقها ليلًا ولا نهارًا أو اشتغلت بها عن إخوتي فغاروا.', '2024-01-16 20:19:53', '2024-02-09 09:30:22'),
(469, 1, 'ايسر السمير', '9530260804', '+9669530260804', 'SA', 'هذين البيتين. ثم قال: أما.', NULL, NULL, 1, NULL, NULL, 'وهي التي ذكر المسعودي أنها جزيرة الوقواق لان تلك الجزيرة ويسبح في أرجائها، فلا يرى بشيء منها آفة. فكان يطمع إن يعثر على موضع الآفة فيزيلها عنها، فترجع إلى ما انتهى إليه بالطريق الأول، ولم يضره في.', '2024-02-02 01:33:45', '2024-02-09 09:30:22'),
(470, 1, 'المهندس زياد عبد الفتاح', '6206271407', '+9656206271407', 'KW', NULL, 13215, 71, 2, NULL, NULL, NULL, '2024-01-12 19:54:13', '2024-02-09 09:30:22'),
(471, 1, 'أ. ميادة عبد الهادي', '4712290407', '+9654712290407', 'KW', NULL, 5050087, NULL, 3, '2024-02-01 11:07:39', '03:30 PM', NULL, '2024-01-28 11:07:39', '2024-02-09 09:30:22'),
(472, 1, 'صابرين مكي', '0599233434', '+9650599233434', 'KW', 'مثل ما قتلت ولدي فقال له.', NULL, NULL, 1, NULL, NULL, 'سيدي إني أقول شيئًا تسر به ولي البشارة. فقلت: نعم فقال: أيها التاجر إن لي بنتًا كانت تعلمت السحر والكهانة من صغرها فسحرت ذلك الولد عجلًا وسحرت الجارية أمه بقرة وسلمتها إلى الراعي أن يخصني ببقرة.', '2024-02-07 20:09:34', '2024-02-09 09:30:22'),
(473, 1, 'Dr. Amely Ledner III', '6758312054', '+16758312054', 'US', NULL, 5051360, 5051110, 2, NULL, NULL, NULL, '2024-01-18 16:43:39', '2024-02-09 09:30:22'),
(474, 0, 'المهندسة ناديه صدام', '6294769882', '+9716294769882', 'AE', NULL, 5050180, NULL, 3, '2024-01-26 20:14:54', '11:00 AM', NULL, '2024-01-22 20:14:54', '2024-02-09 09:30:22'),
(475, 0, 'Emerson White', '1680340848', '+11680340848', 'US', 'Mystery,\' the Mock Turtle.', NULL, NULL, 1, NULL, NULL, 'NO mistake about it: it was just in time to wash the things being alive; for instance, there\'s the arch I\'ve got to come out among the distant sobs of the goldfish kept running in her life before.', '2024-01-08 08:49:24', '2024-02-09 09:30:22'),
(476, 0, 'غازي عبد الرؤوف', '7045653760', '+9737045653760', 'BH', NULL, 13614, 181, 3, '2024-02-07 02:05:27', '11:00 AM', NULL, '2024-02-03 02:05:27', '2024-02-09 09:30:22'),
(477, 0, 'السيدة سهر الأسمري', '5420857658', '+9665420857658', 'SA', NULL, 26922, 26827, 2, NULL, NULL, NULL, '2024-01-15 14:31:02', '2024-02-09 09:30:22'),
(478, 0, 'رزق الداوود', '9148736122', '+9669148736122', 'SA', 'هذا الحجاب الذي لم أر مثله.', NULL, NULL, 1, NULL, NULL, 'الأعضاء التي خلقت له في اقل الأشياء الموجودة، فضلاً عن أكثرها من أثار الحكمة، وبدائع الصنعة، ما قضى منه كل العجب، وتحقق عنده إن ذلك الشيء المرتحل، وعنه كانت تصدر تلك الأفعال ذاتية لها، أو سارية.', '2024-01-17 21:05:38', '2024-02-09 09:30:22'),
(479, 0, 'سحر السباعي', '3043374155', '+9733043374155', 'BH', 'الزمان إلى آخره. فلما سمعت.', NULL, NULL, 1, NULL, NULL, 'الجني وتاج ملوك الجن إذا حكيت لك حكايتي مع هذه الغزالة تعلمت السحر في صغرها من امرأة عجوز كانت عندنا فلما كنا بالأمس وأعطيتني العجل دخلت به عليها فنظرت إليه ابنتي وغطت وجهها وبكت ثم إنها ضحكت وقالت.', '2024-01-26 01:09:51', '2024-02-09 09:30:22'),
(480, 0, 'منى عبد القادر', '5456073338', '+9715456073338', 'AE', NULL, 3574, 55, 2, NULL, NULL, NULL, '2024-01-20 20:51:10', '2024-02-09 09:30:22'),
(481, 0, 'غيد حسن زيد السماري', '4467115004', '+9664467115004', 'SA', NULL, 20227, 17672, 2, NULL, NULL, NULL, '2024-01-23 12:26:23', '2024-02-09 09:30:22'),
(482, 1, 'م. سلطان جمال الدين', '1725900543', '+201725900543', 'EG', 'أنت خلصتيه فلك عندي ما تحت.', NULL, NULL, 1, NULL, NULL, 'علي ولم أطعهم بل أقمنا في دكاكيننا نبيع ونشتري سنة كاملة وهم يعرضون علي السفر وأنا لم أرض حتى مضت ست سنوات كوامل. ثم وافقتهم على السفر وقلت لهم: أي شيء كسبتم من سفركم حتى أكسب أنا فألحوا علي ولم.', '2024-02-04 05:16:23', '2024-02-09 09:30:22'),
(483, 1, 'Colleen DuBuque', '2986103892', '+12986103892', 'US', NULL, 29823, 29445, 2, NULL, NULL, NULL, '2024-01-14 15:04:25', '2024-02-09 09:30:22'),
(484, 0, 'غرام الداوود', '1089478763', '+9661089478763', 'SA', NULL, 5050403, NULL, 3, '2024-01-20 15:54:33', '11:00 AM', NULL, '2024-01-17 15:54:33', '2024-02-09 09:30:22'),
(485, 0, 'أ. لارا عبد المهيمن', '1171527417', '+9731171527417', 'BH', 'ساعته فقال التاجر للعفريت.', NULL, NULL, 1, NULL, NULL, 'ذي حق حقه ثم أعود إليك ولك علي عهد وميثاق أني أعود إليك ولك علي عهد وميثاق أني أعود إليك فتفعل بي ما تريد والله على ما أقول وكيل. فاستوثق منه الجني وأطلقه فرجع إلى بلده وما هذه بأعجب من حكاية.', '2024-02-07 09:08:49', '2024-02-09 09:30:22'),
(486, 1, 'وحيد عبد الكريم', '2422292416', '+9652422292416', 'KW', NULL, 7635, 182, 2, NULL, NULL, NULL, '2024-02-05 12:50:23', '2024-02-09 09:30:22'),
(487, 1, 'نظام السيف', '8915833228', '+9668915833228', 'SA', 'ذلك أن يكون مسكنه أحد هذين.', NULL, NULL, 1, NULL, NULL, 'والثانية وكان دوامه أطول. وما زال حي بن يقظان انه لا يدري لنفسه ابتداء ولا أباً ولا أماً أكثر من استعداد الجسم الذي يظهر فيه، فليس هو في ذاته غني عنها وبريء منها! وكيف لا تنفذ حرارته؟ فتتبع ذلك كله.', '2024-01-16 12:28:19', '2024-02-09 09:30:22'),
(488, 0, 'الآنسة سعاد الصعيدي', '6584777719', '+9736584777719', 'BH', NULL, 21472, 20878, 2, NULL, NULL, NULL, '2024-01-15 06:10:10', '2024-02-09 09:30:22'),
(489, 0, 'هاني جمال الدين', '1548597273', '+9651548597273', 'KW', 'ما قتلت ولدي فقال له التاجر.', NULL, NULL, 1, NULL, NULL, 'إنسانًا فوقعت عليه وقلت للراعي ائتني ببقرة ودع هذا. وأدرك شهرزاد الصباح فسكتت عن الكلام المباح. فقالت لها أختها: ما أطيب حديثك وألطفه وألذه وأعذبه فقالت: وأين هذا مما أحدثكم به الليلة القابلة إن عشت.', '2024-01-19 22:52:16', '2024-02-09 09:30:22'),
(490, 0, 'أ.د تقى عبد السلام', '8894364237', '+9738894364237', 'BH', NULL, 12755, 82, 2, NULL, NULL, NULL, '2024-01-02 01:33:42', '2024-02-09 09:30:22'),
(491, 1, 'مايا رئاد مصطفى السمير', '4471387223', '+9664471387223', 'SA', NULL, 27522, 27353, 3, '2024-01-13 16:50:57', '05:00 PM', NULL, '2024-01-07 16:50:57', '2024-02-09 09:30:22'),
(492, 0, 'أ.د مروان السقا', '3188415845', '+9713188415845', 'AE', NULL, 538, 162, 3, '2024-01-30 10:07:11', '11:00 AM', NULL, '2024-01-26 10:07:11', '2024-02-09 09:30:22'),
(493, 0, 'نصر السويلم', '4706271512', '+9664706271512', 'SA', NULL, 15754, 173, 2, NULL, NULL, NULL, '2024-01-26 07:21:42', '2024-02-09 09:30:22'),
(494, 1, 'تالا مخلص الفيفي', '1574113253', '+9661574113253', 'SA', NULL, 27238, 27027, 3, '2024-01-06 05:53:54', '01:30 PM', NULL, '2024-01-03 05:53:54', '2024-02-09 09:30:22'),
(495, 0, 'أ.د لين عبد الكريم', '3561359248', '+203561359248', 'EG', NULL, 23584, 21116, 3, '2024-01-22 04:32:29', '12:00 PM', NULL, '2024-01-16 04:32:29', '2024-02-09 09:30:22'),
(496, 0, 'اثير الزامل', '9435201624', '+9669435201624', 'SA', NULL, 15745, 173, 3, '2024-01-12 17:54:10', '02:30 PM', NULL, '2024-01-07 17:54:10', '2024-02-09 09:30:22'),
(497, 0, 'Prof. Al Legros DVM', '6550879394', '+16550879394', 'US', 'Mouse had changed his mind.', NULL, NULL, 1, NULL, NULL, 'But her sister on the other two were using it as she went hunting about, and called out \'The race is over!\' and they went up to the waving of the well, and noticed that the cause of this remark, and.', '2024-01-08 02:50:47', '2024-02-09 09:30:22'),
(498, 1, 'ياسمين كاظم', '9072683782', '+9739072683782', 'BH', NULL, 15793, 4066, 2, NULL, NULL, NULL, '2024-01-27 06:19:31', '2024-02-09 09:30:22'),
(499, 0, 'شرين خالد نواف العقل', '5027171719', '+9665027171719', 'SA', NULL, 11393, 871, 2, NULL, NULL, NULL, '2024-01-29 19:09:21', '2024-02-09 09:30:22'),
(500, 0, 'الآنسة حبيبة السقا', '7674314631', '+207674314631', 'EG', NULL, 10709, 4067, 2, NULL, NULL, NULL, '2024-01-17 18:26:28', '2024-02-09 09:30:22');

-- --------------------------------------------------------

--
-- Table structure for table `leads_news_letters`
--

CREATE TABLE `leads_news_letters` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `export` int(11) DEFAULT NULL,
  `created_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `leads_news_letters`
--

INSERT INTO `leads_news_letters` (`id`, `email`, `export`, `created_at`) VALUES
(1, 'marcellus.hyatt@example.net', 0, '2024-01-24 21:33:30'),
(2, 'will.jocelyn@example.com', 1, '2024-02-06 06:32:37'),
(3, 'michel51@example.com', 1, '2024-01-18 01:02:00'),
(4, 'ciara.jacobson@example.org', 1, '2024-01-17 15:13:20'),
(5, 'darrion85@example.net', 1, '2024-01-15 07:35:19'),
(6, 'watsica.daisy@example.net', 0, '2024-02-16 03:01:29'),
(7, 'micheal.luettgen@example.com', 0, '2024-01-11 22:11:23'),
(8, 'nathanial16@example.net', 0, '2024-01-15 01:47:26'),
(9, 'zachery.leannon@example.com', 1, '2024-01-26 10:57:59'),
(10, 'naomie07@example.org', 0, '2024-01-05 06:29:50'),
(11, 'gleichner.lowell@example.net', 0, '2024-01-30 20:35:57'),
(12, 'eaufderhar@example.net', 0, '2024-01-05 00:26:54'),
(13, 'ed23@example.org', 0, '2024-02-16 16:12:59'),
(14, 'darrick77@example.net', 0, '2024-02-17 22:53:44'),
(15, 'marjolaine.stark@example.net', 0, '2024-01-17 22:47:29'),
(16, 'nitzsche.conner@example.org', 0, '2024-01-21 09:59:26'),
(17, 'klittle@example.com', 1, '2024-01-26 01:20:05'),
(18, 'brett64@example.com', 0, '2024-02-13 14:45:43'),
(19, 'hreichel@example.org', 0, '2024-02-01 10:34:29'),
(20, 'nzulauf@example.com', 0, '2024-01-21 23:41:07'),
(21, 'lueilwitz.dejah@example.com', 1, '2024-02-15 10:59:39'),
(22, 'howell.carlos@example.net', 0, '2024-01-18 08:37:36'),
(23, 'thodkiewicz@example.org', 0, '2024-02-17 05:21:02'),
(24, 'lavina54@example.com', 1, '2024-01-20 16:37:28'),
(25, 'felicity92@example.net', 0, '2024-01-03 09:52:56'),
(26, 'herbert.heaney@example.net', 1, '2024-01-30 12:01:01'),
(27, 'granville40@example.com', 1, '2024-01-23 07:53:58'),
(28, 'juliana03@example.com', 1, '2024-01-24 23:39:18'),
(29, 'ferry.emie@example.net', 0, '2024-02-09 15:42:28'),
(30, 'hermann.nannie@example.net', 0, '2024-02-09 18:56:43'),
(31, 'adolfo.kuhn@example.net', 1, '2024-02-06 22:36:05'),
(32, 'oconner.laurel@example.com', 1, '2024-01-10 07:18:16'),
(33, 'lmarks@example.net', 0, '2024-01-31 18:16:05'),
(34, 'eleonore97@example.com', 1, '2024-01-27 04:40:12'),
(35, 'darwin.nader@example.org', 1, '2024-02-06 18:56:55'),
(36, 'johns.antonetta@example.org', 1, '2024-02-08 13:24:41'),
(37, 'vida.spencer@example.org', 0, '2024-01-13 03:37:41'),
(38, 'imacejkovic@example.org', 0, '2024-01-04 08:43:14'),
(39, 'ograham@example.com', 1, '2024-02-06 16:31:09'),
(40, 'johnathon.nitzsche@example.com', 1, '2024-01-21 12:31:10'),
(41, 'juvenal82@example.org', 0, '2024-02-15 10:26:24'),
(42, 'qeichmann@example.net', 1, '2024-01-24 04:14:38'),
(43, 'mdicki@example.com', 1, '2024-02-12 07:49:18'),
(44, 'tristian.moore@example.com', 0, '2024-02-14 10:36:34'),
(45, 'shea.braun@example.net', 0, '2024-01-06 15:22:02'),
(46, 'sincere67@example.org', 0, '2024-01-16 05:35:08'),
(47, 'zboncak.brendan@example.com', 0, '2024-01-07 21:31:22'),
(48, 'pjakubowski@example.com', 0, '2024-01-19 02:37:25'),
(49, 'sonya66@example.org', 0, '2024-02-09 15:38:19'),
(50, 'lborer@example.org', 0, '2024-01-03 14:06:29'),
(51, 'mkris@example.com', 0, '2024-02-16 06:56:41'),
(52, 'padberg.brianne@example.org', 1, '2024-01-11 18:40:29'),
(53, 'gregoria97@example.org', 0, '2024-02-06 09:44:48'),
(54, 'bcruickshank@example.org', 0, '2024-01-18 17:47:25'),
(55, 'hosea63@example.com', 1, '2024-02-09 18:34:35'),
(56, 'kyler.medhurst@example.org', 0, '2024-02-14 22:48:17'),
(57, 'odell15@example.org', 0, '2024-01-21 04:54:29'),
(58, 'swaniawski.oscar@example.net', 0, '2024-01-15 11:08:01'),
(59, 'crist.winifred@example.net', 0, '2024-01-13 05:11:17'),
(60, 'igrady@example.com', 0, '2024-02-19 03:24:51'),
(61, 'alfonso.bednar@example.net', 0, '2024-02-03 02:21:35'),
(62, 'broderick79@example.org', 0, '2024-01-13 07:59:53'),
(63, 'berniece53@example.net', 0, '2024-02-01 02:40:04'),
(64, 'winona94@example.net', 0, '2024-02-05 18:11:45'),
(65, 'cecelia.kertzmann@example.com', 1, '2024-01-07 11:05:16'),
(66, 'qgerlach@example.net', 1, '2024-01-11 19:39:36'),
(67, 'jovan24@example.com', 0, '2024-01-29 01:34:55'),
(68, 'willms.will@example.org', 1, '2024-01-01 19:56:38'),
(69, 'amara.ryan@example.net', 0, '2024-02-15 12:55:16'),
(70, 'mckenzie11@example.com', 1, '2024-02-16 00:22:02'),
(71, 'ygrant@example.net', 1, '2024-01-20 04:06:59'),
(72, 'johns.juanita@example.net', 0, '2024-02-02 21:48:22'),
(73, 'fausto59@example.org', 0, '2024-02-02 06:43:28'),
(74, 'litzy.dickens@example.com', 1, '2024-02-14 04:45:31'),
(75, 'udickinson@example.com', 0, '2024-02-12 16:35:37'),
(76, 'hegmann.gene@example.com', 0, '2024-01-30 05:55:33'),
(77, 'bstoltenberg@example.org', 0, '2024-01-24 14:49:34'),
(78, 'wuckert.ward@example.com', 1, '2024-01-26 01:24:00'),
(79, 'obarrows@example.net', 1, '2024-02-09 14:21:24'),
(80, 'oswift@example.net', 1, '2024-02-19 03:41:01'),
(81, 'schulist.keara@example.net', 0, '2024-02-19 08:20:41'),
(82, 'reina49@example.com', 0, '2024-01-21 08:52:11'),
(83, 'nquitzon@example.org', 0, '2024-02-09 10:04:11'),
(84, 'cwisoky@example.net', 1, '2024-01-18 22:28:02'),
(85, 'pratke@example.org', 0, '2024-02-05 06:40:21'),
(86, 'balistreri.celestine@example.org', 0, '2024-01-17 03:40:05'),
(87, 'hyatt.shanelle@example.org', 1, '2024-01-11 18:36:25'),
(88, 'maya55@example.net', 1, '2024-01-27 19:42:46'),
(89, 'gislason.fiona@example.org', 1, '2024-02-18 05:50:26'),
(90, 'fschultz@example.net', 0, '2024-01-09 17:15:59'),
(91, 'oliver33@example.org', 1, '2024-01-01 07:22:14'),
(92, 'mleuschke@example.org', 0, '2024-01-01 11:15:52'),
(93, 'dschumm@example.com', 1, '2024-01-28 14:01:41'),
(94, 'janice69@example.com', 0, '2024-01-05 05:38:20'),
(95, 'ohara.fae@example.net', 1, '2024-01-01 18:46:40'),
(96, 'tbecker@example.org', 1, '2024-02-03 20:46:00'),
(97, 'owunsch@example.org', 0, '2024-01-23 18:07:45'),
(98, 'howe.shanie@example.org', 0, '2024-01-09 05:15:40'),
(99, 'guillermo62@example.org', 0, '2024-02-04 08:00:20'),
(100, 'hreynolds@example.net', 1, '2024-02-12 13:22:19'),
(101, 'joey.yost@example.net', 0, '2024-02-03 13:03:52'),
(102, 'ledner.everette@example.org', 0, '2024-02-13 18:46:31'),
(103, 'lweimann@example.net', 0, '2024-01-03 00:02:57'),
(104, 'grace.hickle@example.org', 1, '2024-02-18 10:53:56'),
(105, 'kcrona@example.org', 1, '2024-01-11 16:46:20'),
(106, 'shemar82@example.org', 1, '2024-01-20 01:52:18'),
(107, 'corkery.zackery@example.org', 0, '2024-01-24 04:19:11'),
(108, 'mann.verona@example.net', 0, '2024-01-19 18:38:28'),
(109, 'elmo.terry@example.com', 0, '2024-02-15 22:19:59'),
(110, 'audrey13@example.net', 1, '2024-02-13 03:37:46'),
(111, 'linda.oconner@example.org', 0, '2024-02-08 11:38:17'),
(112, 'dimitri.leffler@example.com', 0, '2024-01-10 20:27:12'),
(113, 'orrin78@example.com', 0, '2024-02-15 20:08:17'),
(114, 'bergstrom.prudence@example.org', 0, '2024-01-05 07:53:07'),
(115, 'jeremie.graham@example.org', 1, '2024-01-17 22:21:38'),
(116, 'lind.keeley@example.net', 0, '2024-02-16 13:58:47'),
(117, 'cdouglas@example.net', 1, '2024-01-25 08:16:17'),
(118, 'dominic67@example.net', 1, '2024-02-03 20:59:15'),
(119, 'delpha15@example.org', 1, '2024-02-18 00:49:34'),
(120, 'winston37@example.com', 0, '2024-01-22 12:21:40'),
(121, 'reginald17@example.org', 0, '2024-01-20 01:28:57'),
(122, 'rickie.willms@example.org', 0, '2024-01-28 13:51:11'),
(123, 'green07@example.com', 0, '2024-01-05 19:27:36'),
(124, 'crist.melba@example.net', 0, '2024-01-14 21:07:21'),
(125, 'walker41@example.org', 1, '2024-01-17 02:20:16'),
(126, 'orn.violet@example.org', 0, '2024-01-09 01:47:13'),
(127, 'tokuneva@example.com', 0, '2024-01-09 16:35:07'),
(128, 'wilfred93@example.com', 1, '2024-01-14 06:46:59'),
(129, 'roberta.dietrich@example.org', 1, '2024-02-12 19:53:42'),
(130, 'scotty81@example.org', 0, '2024-01-02 12:18:13'),
(131, 'kaitlin.wuckert@example.org', 1, '2024-01-19 09:11:56'),
(132, 'turner.ford@example.org', 0, '2024-02-09 06:59:14'),
(133, 'juanita64@example.com', 0, '2024-01-22 08:06:19'),
(134, 'ijast@example.com', 0, '2024-01-02 02:44:06'),
(135, 'roxane00@example.net', 0, '2024-01-12 21:06:16'),
(136, 'klocko.kenneth@example.org', 1, '2024-01-18 14:15:28'),
(137, 'udoyle@example.net', 0, '2024-02-12 08:02:43'),
(138, 'wfadel@example.com', 1, '2024-01-23 06:01:29'),
(139, 'marilie.predovic@example.com', 0, '2024-01-23 01:08:59'),
(140, 'pward@example.net', 0, '2024-02-09 06:53:42'),
(141, 'mbartell@example.org', 0, '2024-02-13 10:08:53'),
(142, 'tlockman@example.com', 0, '2024-01-20 07:37:39'),
(143, 'tyrell35@example.net', 1, '2024-02-18 18:54:13'),
(144, 'rahsaan81@example.org', 0, '2024-01-04 17:12:43'),
(145, 'marisol70@example.org', 1, '2024-01-06 22:54:11'),
(146, 'zoe08@example.net', 1, '2024-01-29 16:00:22'),
(147, 'cjacobs@example.org', 1, '2024-01-26 10:20:14'),
(148, 'cassandre22@example.com', 0, '2024-01-13 10:36:05'),
(149, 'linda.schultz@example.net', 0, '2024-01-26 09:25:05'),
(150, 'uriel00@example.com', 0, '2024-01-31 14:17:16'),
(151, 'brant.kertzmann@example.com', 1, '2024-01-05 01:38:49'),
(152, 'maureen.koelpin@example.org', 1, '2024-01-07 23:28:25'),
(153, 'royce.rath@example.com', 0, '2024-01-14 01:06:15'),
(154, 'freeman88@example.com', 1, '2024-01-04 07:32:30'),
(155, 'art.kemmer@example.com', 1, '2024-02-15 01:38:54'),
(156, 'fiona.bayer@example.org', 0, '2024-02-12 14:21:51'),
(157, 'hodkiewicz.marina@example.net', 0, '2024-02-15 19:44:09'),
(158, 'xboehm@example.net', 0, '2024-01-12 02:01:23'),
(159, 'rowe.ephraim@example.net', 0, '2024-02-17 02:24:20'),
(160, 'jaskolski.kaylie@example.com', 0, '2024-01-06 09:40:07'),
(161, 'kip.fahey@example.org', 0, '2024-01-18 06:06:51'),
(162, 'imurphy@example.com', 0, '2024-02-07 14:57:15'),
(163, 'wayne27@example.com', 0, '2024-01-08 02:52:11'),
(164, 'ibrahim70@example.com', 1, '2024-01-23 01:01:17'),
(165, 'parisian.tanner@example.net', 0, '2024-01-20 11:19:32'),
(166, 'silas.altenwerth@example.org', 0, '2024-01-11 12:51:23'),
(167, 'morar.evangeline@example.org', 0, '2024-01-31 14:24:15'),
(168, 'kgrant@example.com', 0, '2024-02-15 02:34:01'),
(169, 'kutch.assunta@example.net', 1, '2024-02-17 06:33:56'),
(170, 'torrey04@example.net', 0, '2024-01-25 20:11:57'),
(171, 'kcartwright@example.net', 1, '2024-02-12 15:43:49'),
(172, 'price28@example.net', 0, '2024-01-01 00:18:57'),
(173, 'don21@example.org', 0, '2024-01-04 11:22:42'),
(174, 'hazel.littel@example.net', 0, '2024-01-12 01:53:25'),
(175, 'winfield.quitzon@example.net', 0, '2024-01-27 20:17:21'),
(176, 'glennie51@example.org', 1, '2024-01-24 08:07:25'),
(177, 'sipes.terrence@example.org', 0, '2024-01-11 14:16:23'),
(178, 'fkoss@example.net', 1, '2024-01-21 11:45:10'),
(179, 'dickens.ike@example.com', 0, '2024-02-13 08:59:50'),
(180, 'lorna61@example.net', 1, '2024-02-07 07:25:46'),
(181, 'adah38@example.com', 0, '2024-01-19 03:31:08'),
(182, 'chermiston@example.org', 0, '2024-01-03 21:13:57'),
(183, 'fkemmer@example.com', 0, '2024-02-08 22:57:51'),
(184, 'fmckenzie@example.net', 0, '2024-02-05 12:10:13'),
(185, 'fkertzmann@example.org', 1, '2024-02-04 09:25:17'),
(186, 'icollins@example.com', 0, '2024-01-29 21:13:12'),
(187, 'conrad.steuber@example.net', 0, '2024-02-17 20:20:18'),
(188, 'littel.oran@example.org', 0, '2024-01-11 10:54:17'),
(189, 'luettgen.boyd@example.net', 0, '2024-01-11 12:21:21'),
(190, 'pstiedemann@example.org', 0, '2024-01-25 02:08:25'),
(191, 'jan48@example.com', 0, '2024-01-11 23:57:14'),
(192, 'hipolito30@example.net', 0, '2024-01-13 20:24:32'),
(193, 'hester51@example.com', 1, '2024-01-12 20:21:08'),
(194, 'hdeckow@example.com', 1, '2024-01-20 10:29:52'),
(195, 'frederique41@example.org', 0, '2024-01-11 17:05:50'),
(196, 'hattie.parker@example.com', 1, '2024-02-17 20:43:41'),
(197, 'herta18@example.com', 0, '2024-01-08 11:21:39'),
(198, 'alvah.okon@example.org', 1, '2024-01-29 00:59:56'),
(199, 'marco.moen@example.net', 0, '2024-01-31 21:33:41'),
(200, 'layne.lubowitz@example.org', 1, '2024-02-13 23:46:48');

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(529, '2014_10_12_000000_create_users_table', 1),
(530, '2014_10_12_100000_create_password_reset_tokens_table', 1),
(531, '2014_10_12_100000_create_password_resets_table', 1),
(532, '2019_08_19_000000_create_failed_jobs_table', 1),
(533, '2019_12_13_000001_create_permission_tables', 1),
(534, '2019_12_13_000002_add_names_roles_table', 1),
(535, '2019_12_13_000003_add_names_permissions_table', 1),
(536, '2019_12_14_000001_create_personal_access_tokens_table', 1),
(537, '2019_12_14_000001_create_settings_table', 1),
(538, '2019_12_14_000002_create_setting_translations_table', 1),
(539, '2019_12_14_000003_create_meta_tags_table', 1),
(540, '2019_12_14_000004_create_meta_tag_translations_table', 1),
(541, '2019_12_14_000005_create_def_photos_table', 1),
(542, '2019_12_14_000006_create_upload_filters_table', 1),
(543, '2019_12_14_000007_create_upload_filter_sizes_table', 1),
(544, '2019_12_14_000008_create_web_privacies_table', 1),
(545, '2019_12_14_000009_create_web_privacy_translations_table', 1),
(546, '2019_12_14_000010_create_news_letters_table', 1),
(547, '2019_12_14_000013_create_contact_us_forms_table', 1),
(548, '2019_12_14_000014_create_countries_table', 1),
(549, '2019_12_14_000015_create_country_translations_table', 1),
(550, '2019_12_14_000016_create_site_maps_table', 1),
(551, '2019_12_14_000017_create_branches_table', 1),
(552, '2019_12_14_000018_create_branch_translations_table', 1),
(553, '2019_12_14_000019_create_app_settings_table', 1),
(554, '2019_12_14_000020_create_app_setting_translations_table', 1),
(555, '2019_12_14_000021_create_app_menus_table', 1),
(556, '2019_12_14_000022_create_app_menu_translations_table', 1);

-- --------------------------------------------------------

--
-- Table structure for table `model_has_permissions`
--

CREATE TABLE `model_has_permissions` (
  `permission_id` bigint(20) UNSIGNED NOT NULL,
  `model_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `model_id` bigint(20) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `model_has_roles`
--

CREATE TABLE `model_has_roles` (
  `role_id` bigint(20) UNSIGNED NOT NULL,
  `model_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `model_id` bigint(20) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `model_has_roles`
--

INSERT INTO `model_has_roles` (`role_id`, `model_type`, `model_id`) VALUES
(1, 'App\\Models\\User', 1),
(2, 'App\\Models\\User', 2),
(2, 'App\\Models\\User', 3);

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `password_reset_tokens`
--

CREATE TABLE `password_reset_tokens` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `permissions`
--

CREATE TABLE `permissions` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `cat_id` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name_ar` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `name_en` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `guard_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `permissions`
--

INSERT INTO `permissions` (`id`, `cat_id`, `name`, `name_ar`, `name_en`, `guard_name`, `created_at`, `updated_at`) VALUES
(1, 'users', 'users_view', 'عرض', 'View', 'web', '2024-02-24 17:08:42', '2024-02-26 10:08:42'),
(2, 'users', 'users_add', 'اضافة', 'Add', 'web', '2024-02-24 17:08:42', '2024-02-24 17:08:42'),
(3, 'users', 'users_edit', 'تعديل', 'Edit', 'web', '2024-02-24 17:08:42', '2024-02-24 17:08:42'),
(4, 'users', 'users_delete', 'حذف', 'Delete', 'web', '2024-02-24 17:08:42', '2024-02-24 17:08:42'),
(5, 'users', 'users_restore', 'استعادة المحذوف', 'Restore', 'web', '2024-02-24 17:08:43', '2024-02-24 17:08:43'),
(6, 'roles', 'roles_view', 'عرض', 'View', 'web', '2024-02-24 17:08:43', '2024-02-24 17:08:43'),
(7, 'roles', 'roles_add', 'اضافة', 'Add', 'web', '2024-02-24 17:08:43', '2024-02-24 17:08:43'),
(8, 'roles', 'roles_edit', 'تعديل', 'Edit', 'web', '2024-02-24 17:08:43', '2024-02-24 17:08:43'),
(9, 'roles', 'roles_delete', 'حذف', 'Delete', 'web', '2024-02-24 17:08:43', '2024-02-24 17:08:43'),
(10, 'roles', 'roles_update_permissions', 'تعديل صلاحيات المجموعة', 'Roles Update Permissions', 'web', '2024-02-24 17:08:43', '2024-02-24 17:08:43'),
(11, 'config', 'config_view', 'عرض الاعدادات', 'Setting View', 'web', '2024-02-24 17:08:43', '2024-02-24 17:08:43'),
(12, 'config', 'config_add', 'اضافة', 'Add', 'web', '2024-02-24 17:08:43', '2024-02-24 17:08:43'),
(13, 'config', 'config_edit', 'تعديل', 'Edit', 'web', '2024-02-24 17:08:43', '2024-02-24 17:08:43'),
(14, 'config', 'config_delete', 'حذف', 'Delete', 'web', '2024-02-24 17:08:43', '2024-02-24 17:08:43'),
(15, 'config', 'config_restore', 'استعادة المحذوف', 'Restore', 'web', '2024-02-24 17:08:43', '2024-02-24 17:08:43'),
(16, 'config', 'config_website', 'اعدادات الموقع', 'Web Site Setting', 'web', '2024-02-24 17:08:43', '2024-02-24 17:08:43'),
(17, 'config', 'config_meta_view', 'ميتا تاج', 'Meta', 'web', '2024-02-24 17:08:43', '2024-02-24 17:08:43'),
(18, 'config', 'config_defPhoto_view', 'الصور الافتراضية', 'View', 'web', '2024-02-24 17:08:43', '2024-02-24 17:08:43'),
(19, 'config', 'config_upFilter_view', 'فلاتر الصور', 'View', 'web', '2024-02-24 17:08:43', '2024-02-24 17:08:43'),
(20, 'config', 'config_newsletter', 'القائمة البريدية', 'News Letter', 'web', '2024-02-24 17:08:43', '2024-02-24 17:08:43'),
(21, 'config', 'adminlang_view', 'ملفات لغة التحكم', 'Admin Lang File', 'web', '2024-02-24 17:08:43', '2024-02-24 17:08:43'),
(22, 'config', 'weblang_view', 'ملفات لغة الموقع', 'Web Lang File', 'web', '2024-02-24 17:08:43', '2024-02-24 17:08:43'),
(23, 'config', 'config_web_privacy', 'سياسية الاستخدام', 'Web Privacy', 'web', '2024-02-24 17:08:43', '2024-02-24 17:08:43'),
(24, 'config', 'sitemap_view', 'SiteMap', 'SiteMap', 'web', '2024-02-24 17:08:43', '2024-02-24 17:08:43'),
(25, 'config', 'config_branch', 'الفروع', 'Branch', 'web', '2024-02-24 17:08:43', '2024-02-24 17:08:43'),
(26, 'data', 'data_view', 'عرض', 'View', 'web', '2024-02-24 17:08:43', '2024-02-24 17:08:43'),
(27, 'data', 'data_add', 'اضافة', 'Add', 'web', '2024-02-24 17:08:43', '2024-02-24 17:08:43'),
(28, 'data', 'data_edit', 'تعديل', 'Edit', 'web', '2024-02-24 17:08:43', '2024-02-24 17:08:43'),
(29, 'data', 'data_delete', 'حذف', 'Delete', 'web', '2024-02-24 17:08:43', '2024-02-24 17:08:43'),
(30, 'data', 'data_restore', 'استعادة المحذوف', 'Restore', 'web', '2024-02-24 17:08:43', '2024-02-24 17:08:43'),
(31, 'data', 'country_view', 'الدول', 'Country', 'web', '2024-02-24 17:08:43', '2024-02-24 17:08:43'),
(32, 'leads', 'leads_view', 'عرض', 'View', 'web', '2024-02-24 17:08:43', '2024-02-24 17:08:43'),
(33, 'leads', 'leads_add', 'اضافة', 'Add', 'web', '2024-02-24 17:08:43', '2024-02-24 17:08:43'),
(34, 'leads', 'leads_edit', 'تعديل', 'Edit', 'web', '2024-02-24 17:08:43', '2024-02-24 17:08:43'),
(35, 'leads', 'leads_export', 'تصدير', 'Export', 'web', '2024-02-24 17:08:43', '2024-02-24 17:08:43'),
(36, 'leads', 'leads_delete', 'حذف', 'Delete', 'web', '2024-02-24 17:08:43', '2024-02-24 17:08:43'),
(37, 'app_setting', 'AppSetting_view', 'عرض', 'View', 'web', '2024-02-24 17:08:43', '2024-02-24 17:08:43'),
(38, 'app_setting', 'AppSetting_add', 'اضافة', 'Add', 'web', '2024-02-24 17:08:43', '2024-02-24 17:08:43'),
(39, 'app_setting', 'AppSetting_edit', 'تعديل', 'Edit', 'web', '2024-02-24 17:08:43', '2024-02-24 17:08:43'),
(40, 'app_setting', 'AppSetting_delete', 'حذف', 'Delete', 'web', '2024-02-24 17:08:43', '2024-02-24 17:08:43'),
(41, 'app_setting', 'AppSetting_restore', 'استعادة المحذوف', 'Restore', 'web', '2024-02-24 17:08:43', '2024-02-24 17:08:43');

-- --------------------------------------------------------

--
-- Table structure for table `personal_access_tokens`
--

CREATE TABLE `personal_access_tokens` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `tokenable_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tokenable_id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `abilities` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `expires_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `roles`
--

CREATE TABLE `roles` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name_ar` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `name_en` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `guard_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `roles`
--

INSERT INTO `roles` (`id`, `name`, `name_ar`, `name_en`, `guard_name`, `created_at`, `updated_at`) VALUES
(1, 'admin', 'ادمن كامل الصلاحيات', 'Full Admin Permission', 'web', '2024-02-24 17:08:43', '2024-02-26 10:00:36'),
(2, 'editor', 'محرر', 'editor', 'web', '2024-02-24 17:08:43', '2024-02-24 17:08:43');

-- --------------------------------------------------------

--
-- Table structure for table `role_has_permissions`
--

CREATE TABLE `role_has_permissions` (
  `permission_id` bigint(20) UNSIGNED NOT NULL,
  `role_id` bigint(20) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `role_has_permissions`
--

INSERT INTO `role_has_permissions` (`permission_id`, `role_id`) VALUES
(1, 1),
(2, 1),
(3, 1),
(4, 1),
(5, 1),
(6, 1),
(7, 1),
(8, 1),
(9, 1),
(10, 1),
(11, 1),
(11, 2),
(12, 1),
(12, 2),
(13, 1),
(13, 2),
(14, 1),
(14, 2),
(15, 1),
(16, 1),
(16, 2),
(17, 1),
(17, 2),
(18, 1),
(18, 2),
(19, 1),
(19, 2),
(20, 1),
(20, 2),
(21, 1),
(22, 1),
(23, 1),
(23, 2),
(24, 1),
(24, 2),
(25, 1),
(25, 2),
(26, 1),
(27, 1),
(28, 1),
(29, 1),
(30, 1),
(31, 1),
(32, 1),
(33, 1),
(34, 1),
(35, 1),
(35, 2),
(36, 1),
(37, 1),
(38, 1),
(39, 1),
(40, 1),
(41, 1);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `photo` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `photo_thum_1` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `roles_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` int(11) NOT NULL DEFAULT 1,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `phone`, `photo`, `photo_thum_1`, `roles_name`, `status`, `email_verified_at`, `password`, `remember_token`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 'Hany Darwish ', 'test@test.com', NULL, NULL, NULL, '[\"admin\"]', 1, NULL, '$2y$10$n1GU8qIpy//yC2IBWB3rFer24Ka.oeCHQCVzYTdc.BZNf0CFN4a1S', NULL, '2024-02-24 17:08:43', '2024-02-24 17:08:43', NULL),
(2, 'Sub Admin  ', 'subadmin@test.com', NULL, NULL, NULL, '[\"editor\"]', 1, NULL, '$2y$10$UqtGC5LGQtIj6Xk6/BzHPOMmFUDl/vhhdRJ/Es43T6tzUXkow4yL.', NULL, '2024-02-24 17:08:43', '2024-02-24 17:08:43', NULL),
(3, 'Editor', 'editor@test.com', NULL, NULL, NULL, '[\"editor\"]', 1, NULL, '$2y$10$AEblcCeaH7ce7AbD.wRLC.WEc2p9S2SjI0yjf0CzWJsd2.aotA71S', NULL, '2024-02-24 17:08:43', '2024-02-24 17:08:43', NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `config_app_menus`
--
ALTER TABLE `config_app_menus`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `config_app_menu_translations`
--
ALTER TABLE `config_app_menu_translations`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `config_app_menu_translations_menu_id_locale_unique` (`menu_id`,`locale`),
  ADD KEY `config_app_menu_translations_locale_index` (`locale`);

--
-- Indexes for table `config_app_settings`
--
ALTER TABLE `config_app_settings`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `config_app_setting_translations`
--
ALTER TABLE `config_app_setting_translations`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `config_app_setting_translations_setting_id_locale_unique` (`setting_id`,`locale`),
  ADD KEY `config_app_setting_translations_locale_index` (`locale`);

--
-- Indexes for table `config_branches`
--
ALTER TABLE `config_branches`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `config_branch_translations`
--
ALTER TABLE `config_branch_translations`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `config_branch_translations_branch_id_locale_unique` (`branch_id`,`locale`),
  ADD KEY `config_branch_translations_locale_index` (`locale`);

--
-- Indexes for table `config_def_photos`
--
ALTER TABLE `config_def_photos`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `config_meta_tags`
--
ALTER TABLE `config_meta_tags`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `config_meta_tags_cat_id_unique` (`cat_id`);

--
-- Indexes for table `config_meta_tag_translations`
--
ALTER TABLE `config_meta_tag_translations`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `config_meta_tag_translations_meta_tag_id_locale_unique` (`meta_tag_id`,`locale`),
  ADD KEY `config_meta_tag_translations_locale_index` (`locale`);

--
-- Indexes for table `config_settings`
--
ALTER TABLE `config_settings`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `config_setting_translations`
--
ALTER TABLE `config_setting_translations`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `config_setting_translations_setting_id_locale_unique` (`setting_id`,`locale`),
  ADD KEY `config_setting_translations_locale_index` (`locale`);

--
-- Indexes for table `config_site_maps`
--
ALTER TABLE `config_site_maps`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `config_upload_filters`
--
ALTER TABLE `config_upload_filters`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `config_upload_filter_sizes`
--
ALTER TABLE `config_upload_filter_sizes`
  ADD PRIMARY KEY (`id`),
  ADD KEY `config_upload_filter_sizes_filter_id_foreign` (`filter_id`);

--
-- Indexes for table `config_web_privacies`
--
ALTER TABLE `config_web_privacies`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `config_web_privacy_translations`
--
ALTER TABLE `config_web_privacy_translations`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `config_web_privacy_translations_privacy_id_locale_unique` (`privacy_id`,`locale`),
  ADD KEY `config_web_privacy_translations_locale_index` (`locale`);

--
-- Indexes for table `data_countries`
--
ALTER TABLE `data_countries`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `data_countries_iso2_unique` (`iso2`);

--
-- Indexes for table `data_country_translations`
--
ALTER TABLE `data_country_translations`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `data_country_translations_country_id_locale_unique` (`country_id`,`locale`),
  ADD KEY `data_country_translations_locale_index` (`locale`);

--
-- Indexes for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`);

--
-- Indexes for table `leads_contact_us`
--
ALTER TABLE `leads_contact_us`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `leads_news_letters`
--
ALTER TABLE `leads_news_letters`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `leads_news_letters_email_unique` (`email`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `model_has_permissions`
--
ALTER TABLE `model_has_permissions`
  ADD PRIMARY KEY (`permission_id`,`model_id`,`model_type`),
  ADD KEY `model_has_permissions_model_id_model_type_index` (`model_id`,`model_type`);

--
-- Indexes for table `model_has_roles`
--
ALTER TABLE `model_has_roles`
  ADD PRIMARY KEY (`role_id`,`model_id`,`model_type`),
  ADD KEY `model_has_roles_model_id_model_type_index` (`model_id`,`model_type`);

--
-- Indexes for table `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`);

--
-- Indexes for table `password_reset_tokens`
--
ALTER TABLE `password_reset_tokens`
  ADD PRIMARY KEY (`email`);

--
-- Indexes for table `permissions`
--
ALTER TABLE `permissions`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `permissions_name_guard_name_unique` (`name`,`guard_name`);

--
-- Indexes for table `personal_access_tokens`
--
ALTER TABLE `personal_access_tokens`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  ADD KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`);

--
-- Indexes for table `roles`
--
ALTER TABLE `roles`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `roles_name_guard_name_unique` (`name`,`guard_name`);

--
-- Indexes for table `role_has_permissions`
--
ALTER TABLE `role_has_permissions`
  ADD PRIMARY KEY (`permission_id`,`role_id`),
  ADD KEY `role_has_permissions_role_id_foreign` (`role_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `config_app_menus`
--
ALTER TABLE `config_app_menus`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `config_app_menu_translations`
--
ALTER TABLE `config_app_menu_translations`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `config_app_settings`
--
ALTER TABLE `config_app_settings`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `config_app_setting_translations`
--
ALTER TABLE `config_app_setting_translations`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `config_branches`
--
ALTER TABLE `config_branches`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `config_branch_translations`
--
ALTER TABLE `config_branch_translations`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `config_def_photos`
--
ALTER TABLE `config_def_photos`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `config_meta_tags`
--
ALTER TABLE `config_meta_tags`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `config_meta_tag_translations`
--
ALTER TABLE `config_meta_tag_translations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `config_settings`
--
ALTER TABLE `config_settings`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `config_setting_translations`
--
ALTER TABLE `config_setting_translations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `config_site_maps`
--
ALTER TABLE `config_site_maps`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `config_upload_filters`
--
ALTER TABLE `config_upload_filters`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `config_upload_filter_sizes`
--
ALTER TABLE `config_upload_filter_sizes`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `config_web_privacies`
--
ALTER TABLE `config_web_privacies`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `config_web_privacy_translations`
--
ALTER TABLE `config_web_privacy_translations`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=33;

--
-- AUTO_INCREMENT for table `data_countries`
--
ALTER TABLE `data_countries`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=253;

--
-- AUTO_INCREMENT for table `data_country_translations`
--
ALTER TABLE `data_country_translations`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=505;

--
-- AUTO_INCREMENT for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `leads_contact_us`
--
ALTER TABLE `leads_contact_us`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=501;

--
-- AUTO_INCREMENT for table `leads_news_letters`
--
ALTER TABLE `leads_news_letters`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=201;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=557;

--
-- AUTO_INCREMENT for table `permissions`
--
ALTER TABLE `permissions`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=42;

--
-- AUTO_INCREMENT for table `personal_access_tokens`
--
ALTER TABLE `personal_access_tokens`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `roles`
--
ALTER TABLE `roles`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `config_app_menu_translations`
--
ALTER TABLE `config_app_menu_translations`
  ADD CONSTRAINT `config_app_menu_translations_menu_id_foreign` FOREIGN KEY (`menu_id`) REFERENCES `config_app_menus` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `config_app_setting_translations`
--
ALTER TABLE `config_app_setting_translations`
  ADD CONSTRAINT `config_app_setting_translations_setting_id_foreign` FOREIGN KEY (`setting_id`) REFERENCES `config_app_settings` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `config_branch_translations`
--
ALTER TABLE `config_branch_translations`
  ADD CONSTRAINT `config_branch_translations_branch_id_foreign` FOREIGN KEY (`branch_id`) REFERENCES `config_branches` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `config_meta_tag_translations`
--
ALTER TABLE `config_meta_tag_translations`
  ADD CONSTRAINT `config_meta_tag_translations_meta_tag_id_foreign` FOREIGN KEY (`meta_tag_id`) REFERENCES `config_meta_tags` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `config_setting_translations`
--
ALTER TABLE `config_setting_translations`
  ADD CONSTRAINT `config_setting_translations_setting_id_foreign` FOREIGN KEY (`setting_id`) REFERENCES `config_settings` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `config_upload_filter_sizes`
--
ALTER TABLE `config_upload_filter_sizes`
  ADD CONSTRAINT `config_upload_filter_sizes_filter_id_foreign` FOREIGN KEY (`filter_id`) REFERENCES `config_upload_filters` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `config_web_privacy_translations`
--
ALTER TABLE `config_web_privacy_translations`
  ADD CONSTRAINT `config_web_privacy_translations_privacy_id_foreign` FOREIGN KEY (`privacy_id`) REFERENCES `config_web_privacies` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `data_country_translations`
--
ALTER TABLE `data_country_translations`
  ADD CONSTRAINT `data_country_translations_country_id_foreign` FOREIGN KEY (`country_id`) REFERENCES `data_countries` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `model_has_permissions`
--
ALTER TABLE `model_has_permissions`
  ADD CONSTRAINT `model_has_permissions_permission_id_foreign` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `model_has_roles`
--
ALTER TABLE `model_has_roles`
  ADD CONSTRAINT `model_has_roles_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `role_has_permissions`
--
ALTER TABLE `role_has_permissions`
  ADD CONSTRAINT `role_has_permissions_permission_id_foreign` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `role_has_permissions_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
